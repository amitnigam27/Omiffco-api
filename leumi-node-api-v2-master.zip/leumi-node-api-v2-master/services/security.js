const axiosClient = require('../lib/axios');
const https = require('https');
const { ESB_BASE_URL, ESB_TIMEOUT_PERIOD } = require('../config/config');
const AUTHENTICATE_URL = ESB_BASE_URL+"/security/authenticate";
const VALIDATE_OTP = ESB_BASE_URL+"/security/validatePaymentOTP";
const { defaultLogger, errorLogger } = require('../lib/logging');

class SecurityService {

    /**
     * authenticate service is responsible for checking the authenticity of user
     * by validating the userid, password and OTP. 
     * 
     * @param {*} body - holds the data that needs to be validate.
     */
    async authenticate(body,params) {
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Entering into authenticate()");
        defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Request: "+AUTHENTICATE_URL);
        try{            
            let data= await axiosClient.post(AUTHENTICATE_URL, body, {timeout : ESB_TIMEOUT_PERIOD,httpsAgent:new https.Agent({ rejectUnauthorized: false})});
            data = data.data;
            defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Response: "+JSON.stringify(data,null,2));
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Exiting from authenticate()");
            return data;
        }
        catch(err) {
            errorLogger.info("["+params.userid+"]-["+params.requestid+"]-Error occured in service ("+AUTHENTICATE_URL+"): "+err);            
			if(err.response == null || err.response.status == null || err.response.data == null) {
				let msg = "Backend Error - " + err;
				let error = {};
				let response = {};
				response.data 	= 'An unexpected error has occured.';
				response.status 	= 500;								
				error["response"] = response;
				error.message = msg;
				errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(error,null,2));
				throw error;
			}else{
				errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(err,null,2));
				throw err;
			}
        }
    }

    /**
     * validatePaymentOTP service is responsible to validate the OTP for the payment.
     * 
     * @param {*} body - holds the data that needs to be validate.
     */
    async validatePaymentOTP(body,params) {
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Entering into validatePaymentOTP()");
        defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Request: "+VALIDATE_OTP);
        defaultLogger.debug(body);
        try{
            let data = await axiosClient.post(VALIDATE_OTP, body, {timeout : ESB_TIMEOUT_PERIOD,httpsAgent:new https.Agent({ rejectUnauthorized: false})});
            data= data.data;
            defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Response: "+JSON.stringify(data,null,2));
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Exiting from validatePaymentOTP()");
            return data;
        }
        catch(err) {
            errorLogger.info("["+params.userid+"]-["+params.requestid+"]-Error occured in service ("+VALIDATE_OTP+"): ");
            if(err.response == null || err.response.status == null || err.response.data == null) {
				let msg = "Backend Error - " + err;
				let error = {};
				let response = {};
				response.data 	= 'An unexpected error has occured.';
				response.status 	= 500;								
				error["response"] = response;
				error.message = msg;
				errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(error,null,2));
				throw error;
            }else{
                errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(err,null,2));
                throw err;
            }
        }
    }
}

module.exports = SecurityService;
