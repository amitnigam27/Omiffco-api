const axiosClient = require('../lib/axios');
const base64url = require('base64-url')
const { TESTING_LOCALLY, ALGO, EXPIRY_TIME, MEMBER_ID, KEY_ID, TOKEN_ENDPOINT, BANK_ID } = require('../config/config');
const { defaultLogger, errorLogger } = require('../lib/logging');
const { TOKEN_PROTOCOL,BL_PRIVATE_KEY,BL_PUBLIC_KEY,LIFE_TIME_AMNT,TOKEN_TIMEOUT_PERIOD} = require('../config/config');
 
let current_time = new Date().getTime();
let exp = current_time+EXPIRY_TIME;

const { sign, bufferKey } = require('../lib/util');

const privateKey = BL_PRIVATE_KEY;
const publicKey = BL_PUBLIC_KEY;

const keys = {
    privateKey: bufferKey(privateKey),
    publicKey: bufferKey(publicKey)
}

//JWT Header
let jwtHeader = {
    "alg": ALGO ,
    "exp": exp ,
    "mid" : MEMBER_ID ,
    "kid": KEY_ID ,
    "method": "" ,
    "host": TOKEN_ENDPOINT,
    "path": "" ,
    "query": ""
}

class TokenService { 
    /**
     * getConstents service is responsible for fetching the Consent Request Object
     * to further extract details like tppCallbackUrl, tppName and requestType etc based on requestId.
     * 
     * @param  requestId - request Id will get from the url when third-party will call landing page.
     *
     */
    async getConsent(requestId,params) {
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Entering into TokenService.getConsents()");
        jwtHeader.method= "GET";
        jwtHeader.path = "/banks/"+BANK_ID+"/consent-requests/"+requestId
        const encodedHeader = base64url.encode(JSON.stringify(jwtHeader));
        const encodedPayload = base64url.encode('');
        let signingInput = encodedHeader + "." + encodedPayload;
        let signature = sign(signingInput, keys); 
        //console.log("Sign EDDSA: "+signature);
        let endPoint = TOKEN_PROTOCOL+TOKEN_ENDPOINT+requestId+".json";
        if(!TESTING_LOCALLY){
            endPoint = TOKEN_PROTOCOL+TOKEN_ENDPOINT+"/banks/"+BANK_ID+"/consent-requests/"+requestId;
        }

        let jwtToken = encodedHeader + ".." + signature;
        //console.log(jwtToken);
        try {
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Endpoint: "+endPoint);
            let data =  await axiosClient.get(endPoint,{headers: { 'Authorization': `Bearer ${jwtToken}` }}, {timeout : TOKEN_TIMEOUT_PERIOD});
            data = data.data;
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Response:\n");
            defaultLogger.debug(JSON.stringify(data,null,2));
            let consentRequest = data.consentRequest;
            //console.log("*****Consent*****");
            
            let accArr = ['ACCOUNTS', 'BALANCES', 'TRANSACTIONS'];
            let payArr = ['TRANSFER_DESTINATIONS', 'STANDING_ORDERS'];
            if(consentRequest.resourceTypeList!=null && consentRequest.resourceTypeList.resources!=null){
                // For Account Information  
                if(accArr.some(item => consentRequest.resourceTypeList.resources.includes(item))){
                    data.consentRequest.requestType="accountInfo";
                }else if(payArr.some(item => consentRequest.resourceTypeList.resources.includes(item))){
                    // For Payment
                    data.consentRequest.requestType="payment";
                }else if(consentRequest.resourceTypeList.resources.includes("FUNDS_CONFIRMATIONS")){
                    // For CBPII
                    data.consentRequest.requestType="cbpii";
                }
            }

            if(consentRequest.tppName==null){
                errorLogger.info("["+params.userid+"]-["+params.requestid+"]-tppName is missing in request, setting it to default value: NotProvided");
                data.consentRequest.tppName="NotProvided";
            }

            if( data.consentRequest.requestType == null && consentRequest.accountResourceList!=null){
                let resources = consentRequest.accountResourceList.resources;
                if(resources!=null && Array.isArray(resources) && resources.length > 0 ){
                    let item;
                    for (item in resources) {
                        let resource = resources[item];
                            //for AISP
                        if(resource.type === "ACCOUNT_INFO" || resource.type === "ACCOUNT_BALANCE" || resource.type === "ACCOUNT_TRANSACTIONS"){
                            data.consentRequest.requestType="accountInfo";
                            break;
                        }else if(resource.type === "ACCOUNT_TRANSFER_DESTINATIONS" || resource.type === "ACCOUNT_STANDING_ORDERS"){
                            //for PISP
                            data.consentRequest.requestType="payment";
                            break;
                        }else if(resource.type === "ACCOUNT_FUNDS_CONFIRMATION"){
                            //for CBPII
                            data.consentRequest.requestType="cbpii";
                            break;
                        }
                    }
                }
            }
            
            // If payment type is either TransferBody or StandingOrder.
            if(consentRequest.transferBody!=null || consentRequest.standingOrderBody!= null){
                data.consentRequest.requestType="payment";
                if(consentRequest.transferBody!=null){
                    if(consentRequest.transferBody.executionDate==null){
                        errorLogger.info("["+params.userid+"]-["+params.requestid+"]-executionDate is missing in request setting it to current date: "+new Date());
                        consentRequest.transferBody.executionDate = new Date();
                    }
                    if(LIFE_TIME_AMNT && consentRequest.transferBody.amount==null){ 
                        consentRequest.transferBody.amount = consentRequest.transferBody.lifetimeAmount;
                    }
                    if(consentRequest.transferBody.startDate == null && consentRequest.transferBody.endDate == null && consentRequest.transferBody.frequency == null){
                        errorLogger.info("["+params.userid+"]-["+params.requestid+"]-This is Transfer Body and the recurrence data is missing in Consent Object received from Token." );  
                    }
                } else {
                    if(consentRequest.standingOrderBody.startDate == null && consentRequest.standingOrderBody.endDate == null && consentRequest.standingOrderBody.frequency == null){
                        errorLogger.info("["+params.userid+"]-["+params.requestid+"]-This is Standing Order Body and the recurrence data is missing in Consent Object received from Token." );  
                    }
                }
            }
            if(data.consentRequest!=null){
                defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Request Type -> "+data.consentRequest.requestType);
            }
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Exiting from TokenService.getConsents()");
            return data;
        } catch(err) {
            errorLogger.info("["+params.userid+"]-["+params.requestid+"]-Error occured in service ("+endPoint+") ");
            if(err.response == null || err.response.status == null || err.response.data == null) {
				let msg = "Backend Error - " + err;
				let error = {};
				let response = {};
				response.data 	= 'An unexpected error has occured.';
				response.status 	= 500;								
				error["response"] = response;
				error.message = msg;
				errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(error,null,2));
				throw error;
            }else{
                errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(err,null,2));
                throw err;
            }
        }
    }

    /**
     * postUsers Service is responsible for generating new tokenUserId if it's missing
     * in the response of authentication service call.
     * 
     * @param {*} body 
     */
    async postUsers(body,params){
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Entering into TokenService.postUsers()");
        jwtHeader.method= "POST";
        jwtHeader.path ="/banks/"+BANK_ID+"/users"
        const encodedHeader = base64url.encode(JSON.stringify(jwtHeader));
        const encodedPayload = base64url.encode(JSON.stringify(body));
        let signingInput = encodedHeader + "." + encodedPayload;
        let signature = sign(signingInput, keys); 
        let jwtToken = encodedHeader + ".." + signature;
        let endPoint = TOKEN_PROTOCOL+TOKEN_ENDPOINT+"users.json";
        if(!TESTING_LOCALLY){
            endPoint = TOKEN_PROTOCOL+TOKEN_ENDPOINT+"/banks/"+BANK_ID+"/users";
        }
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Endpoint: "+endPoint);
        try {
            let data = await axiosClient.post(endPoint,body,{headers: { 'Authorization': `Bearer ${jwtToken}` }}, {timeout : TOKEN_TIMEOUT_PERIOD});
            data = data.data;
            defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Response:\n");
            defaultLogger.debug(JSON.stringify(data,null,2));
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Exiting from TokenService.postUsers()");
            return data;
        } catch (err) {
            errorLogger.info("["+params.userid+"]-["+params.requestid+"]-Error occured in service ("+endPoint+") ");
            if(err.response == null || err.response.status == null || err.response.data == null) {
				let msg = "Backend Error - " + err;
				let error = {};
				let response = {};
				response.data 	= 'An unexpected error has occured.';
				response.status 	= 500;								
				error["response"] = response;
				error.message = msg;
				errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(error,null,2));
				throw error;
            }else{
                errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(err,null,2));
                throw err;
            }
        }
    }

    /**
     * postConsents Service is responsible to create a consent at Token.
     * 
     * @param {*} body - holds the neccessary details to create a consent.
     */
    async postConsents(body,params){
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Entering into TokenService.postConsents()");
        jwtHeader.method= "POST";
        jwtHeader.path ="/banks/"+BANK_ID+"/consents";
        const encodedHeader = base64url.encode(JSON.stringify(jwtHeader));
        const encodedPayload = base64url.encode(JSON.stringify(body));
        let signingInput = encodedHeader + "." + encodedPayload;

        let signature = sign(signingInput, keys); 
        //console.log("Sign EDDSA: "+signature);
        let endPoint = TOKEN_PROTOCOL+TOKEN_ENDPOINT+"consents.json";
        if(!TESTING_LOCALLY){
            endPoint = TOKEN_PROTOCOL+TOKEN_ENDPOINT+"/banks/"+BANK_ID+"/consents";
        }
        // Detached JWT
        let jwtToken = encodedHeader + ".." + signature;
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Endpoint: "+endPoint);
        defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Request: "+JSON.stringify(body,null,2));
        try {
            let data = await axiosClient.post(endPoint,body,{headers: { 'Authorization': `Bearer ${jwtToken}` }}, {timeout : TOKEN_TIMEOUT_PERIOD});
            if( data != null && data.data != null){
                data = data.data;
                defaultLogger.debug(JSON.stringify(data,null,2));
                defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Exiting from TokenService.postConsents()");                
                return data;
            } else {
                defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(data,null,2)); 
                defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Response is not correct"); 
                return {};
            }
        } catch(err) {
            errorLogger.info("["+params.userid+"]-["+params.requestid+"]-Error occured in service ("+endPoint+") ");
            if(err.response == null || err.response.status == null || err.response.data == null) {
				let msg = "Backend Error - " + err;
				let error = {};
				let response = {};
				response.data 	= 'An unexpected error has occured.';
				response.status 	= 500;								
				error["response"] = response;
				error.message = msg;
				errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(error,null,2));
				throw error;
            }else{
                errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(err,null,2));
                throw err;
            }
        }
    }
}

module.exports = TokenService;
