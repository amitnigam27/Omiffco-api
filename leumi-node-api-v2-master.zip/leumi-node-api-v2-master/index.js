const express = require('express');
const bodyParser = require('body-parser');
const swaggerUi = require('swagger-ui-express');
var fs = require('fs');
//const http = require('http');
const https = require('https');
const sqlinjection = require('./lib/sql-injection');
const swaggerDocument = require('./swagger_docs/swagger.json');
const { defaultLogger } = require('./lib/logging');
const {  SSL_KEY_PATH, SSL_CERT_PATH } = require('./config/config');
const privateKey  = fs.readFileSync(SSL_KEY_PATH, 'utf8');
const certificate = fs.readFileSync(SSL_CERT_PATH, 'utf8');
const credentials = {key: privateKey, cert: certificate};
const app = express();

const https_port = process.env.HTTPS_PORT || 9445;


/**
 * Enable CORS
 */
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", '*'); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization, authorization"
    );
    next();
});


/**
 * Get the different routes in variable
 */
const { accountRouter, securityRouter, tokenRouter, configRouter, paymentRouter } = require('./routes');

/**
 * Middleware - parse json body from request.
 */
app.use(bodyParser.json());

/**
 * This middleware prevents any sql injections.
 */
app.use(sqlinjection);

/**
 * Middleware- log incoming requests
 */
app.use((req, res, next) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-"+`${req.method}: ${req.url} called `);
    next();
});

/**
 * Routes integration
 */
app.use('/account', accountRouter);
app.use('/security', securityRouter);
app.use('/token', tokenRouter);
app.use('/payment', paymentRouter);
app.use('/config', configRouter);

/**
 * @GET API- to check health of the application
 */
app.get('/health-check', (req, res) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-GET: health-check api called");
    res.send({
        message: "App is running"
    })
})

/**
 * swagger UI api
 */
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));


const httpsServer = https.createServer(credentials, app);

/**
 * APP binding
 */
httpsServer.listen(https_port, () => console.log('Https Server is running on ',https_port));