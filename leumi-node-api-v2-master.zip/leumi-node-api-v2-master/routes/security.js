const express = require('express');
const router = express.Router();
const { defaultLogger, errorLogger } = require('../lib/logging');
const SecurityService = require('../services/security');
const jwt = require('jsonwebtoken');
var verifyToken = require('../lib/util');
const { WEB_API_SECRET_KEY, WEB_API_EXPIRY_TIME } = require('../config/config');

const securityService = new SecurityService();

/**	
 * This route is to call authenticate service for checking the authenticity of user
 * by validating the userid, password and OTP.
 * 
 */

router.post('/authenticate', async (req, res) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering into Security: /authenticate");
    var params = req.headers;
    const body = req.body;
    defaultLogger.debug("["+userid+"]-["+reqid+"]-Logging as " + body.userid + " with password = ******  and OTP = ****** ");
    try {
        const data = await securityService.authenticate(body,params);
        //send data with appropriate http status code based on responseCode recieved.
        if (data[0].responseCode != 0 || data[0].sessionId == null) {
            defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Security: /authenticate with responseCode: " + data[0].responseCode);
            res.status(401).send(data);
        } else {
            // Generating token signature
            jwt.sign({ body: data[0].sessionId }, WEB_API_SECRET_KEY, { expiresIn: WEB_API_EXPIRY_TIME }, (err, token) => {
                data[0].token = token;
                defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Security: /authenticate with responseCode: " + data[0].responseCode);
                res.status(200).send(data);
            });
        }

    }
    catch (err) {
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/authenticate):");
        errorLogger.error("["+userid+"]-["+reqid+"]-"+JSON.stringify(err, null, 2));
        if (err.message.indexOf('timeout') > -1) {
            res.status(500).send(err.message);
        } else {
            res.status(err.response.status).send(err.response.data);
        }

    }
});

/**
 * This route is to call validatePaymentOTP service to validate the payment OTP
 */
router.post('/validatePaymentOTP', verifyToken.verifyToken, async (req, res) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering into Security: /validatePaymentOTP ");
    const body = req.body;
    var params = req.headers;
    try {
        const data = await securityService.validatePaymentOTP(body,params)
        //send data with appropriate http status code based on responseCode recieved.
        if (data[0].responseCode != 0) {
            defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Security: /validatePaymentOTP with responseCode: " + data[0].responseCode);
            res.status(401).send(data);
        } else {
            defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Security: /validatePaymentOTP with responseCode: " + data[0].responseCode);
            res.status(200).send(data);
        }
    }
    catch (err) {
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/validatePaymentOTP):");
        errorLogger.error("["+userid+"]-["+reqid+"]-"+JSON.stringify(err, null, 2));
        if (err.message.indexOf('timeout') > -1) {
            res.status(500).send(err.message);
        } else {
            if (err.response != null) {
                res.status(err.response.status).send(err.response.data);
            } else {
                errorLogger.error(err);
                res.status(500).send(err);
            }
        }
    }
});

module.exports = router;
