const accountRouter = require('./account');
const configRouter = require('./config');
const tokenRouter = require('./token');
const securityRouter = require('./security');
const paymentRouter= require('./payment');

/**
 * Exports make these variables accessible globally using require(...).
 */
module.exports = {
    accountRouter: accountRouter,
    configRouter: configRouter,
    tokenRouter: tokenRouter,
    securityRouter: securityRouter,
    paymentRouter: paymentRouter
}
