const express = require('express');
const router = express.Router();
const { defaultLogger, errorLogger} = require('../lib/logging');
const AccountService = require('../services/account');
var verifyToken = require('../lib/util');
const accountService = new AccountService();

/**This route is to call getAccountList service which fetches list of corporate accounts using authId.
 * @param authId - authId gets generated on successfull authentication.
 */
router.get('/list/:authId',verifyToken.verifyToken ,async (req, res) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering into Account: /list/"+req.params.authId);
    var params = req.headers;
    const id = req.params.authId;
    const accountType = req.query.accountType;
    const currencyCode = req.query.currencyCode;      
    try {
        const data = await accountService.getListByAuthId(id,accountType,currencyCode,params);
        defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Account: /list/"+req.params.authId);
        res.send(data);
    }
    catch(err) {
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/list/"+id+"): ");
        errorLogger.error("["+userid+"]-["+reqid+"]-"+JSON.stringify(err,null,2));
        if(err.message.indexOf('timeout') > -1){
            res.status(500).send(err.message);
        }else{
            res.status(err.response.status).send(err.response.data);
        }
    }
});

/**	
 * This route is to call saveAccountList service i.e. to save account selected for which user gave its consent.
 * @param authId - authId gets generated on successfull authentication.
 */
router.post('/saveAccountList/:authId',verifyToken.verifyToken ,async (req, res) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering into Account: /saveAccountList/"+req.params.authId);
    var params = req.headers;
    const body = req.body;
    const authId = req.params.authId;
    //manipulating request body to send previouslyUsedAccount as null or in other words removing it
    //from object itself.
    var accountList = body.accountList;
    accountList.forEach(element => {
        var accountPermissions = element.account.accountPermissions;
        delete accountPermissions["previouslyUsedAccount"];
    });
   
    try {
        const data = await accountService.saveAccountList(authId,body,params);
        //send data with appropriate http status code based on responseCode recieved.
        if(data[0].responseCode != 0){
            
            defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Account: /saveAccountList/"+authId+" with responseCode: "+data[0].responseCode);
            res.status(400).send(data);
        }else{
            
            defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Account: /saveAccountList/"+authId+" with responseCode: "+data[0].responseCode);
            res.status(200).send(data);
        }
    }
    catch(err) {
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/saveAccountList/"+authId+"): ");
        errorLogger.error("["+userid+"]-["+reqid+"]-"+JSON.stringify(err,null,2));
        if(err.message.indexOf('timeout') > -1){
            res.status(500).send(err.message);
        }else{
            res.status(err.response.status).send(err.response.data);
        }
    }
})

module.exports = router;
