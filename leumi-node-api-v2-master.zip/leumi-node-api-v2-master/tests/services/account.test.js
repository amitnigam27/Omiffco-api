const { expect } = require('chai');
describe('Account Service', () => {
    // TBD
    it('true is true', () => {
        expect(true).to.eql(true);
    });
    it('false is false', () => {
        expect(false).to.eql(false);
    });
});
