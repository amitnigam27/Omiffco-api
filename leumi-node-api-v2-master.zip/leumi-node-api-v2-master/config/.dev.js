module.exports = {
    //Sets env. profile
    NODE_ENV: 'dev',
    //Sets env. port 
    PORT: 8090,
    //Sets base url for ESB Service calls
    ESB_BASE_URL: 'http://52.15.122.80:8090/leumiResponseAPI',
    //Username needs to be send in ESB header as basic authentication
    ESB_USERNAME : 'user',
    //Password needs to be send in ESB header as basic authentication
    ESB_PASSWORD: '2213905b3bf22ce99779416734bb47d9:5d0629a23dc410bf7b6bcc1b6ca8f9e8',
    //Flag whose value depends on ESB_PASSWORD property
    IS_PASSWORD_ENCRYPTED: false,
    //Ideal screen display timeout
    SCREEN_DISPLAY_TIMEOUT: 60,
    //Redirect timeout
    REDIRECT_PAGE_DISPLAY_TIMEOUT: 15,
    //Bank Id registered with Token
    BANK_ID: 'leumi-dev',
    //web protocol for token REST API calls
    TOKEN_PROTOCOL: 'https://',
    //Path to SSL key
    SSL_KEY_PATH:'certs/domain.key',
    //Path to SSL certificate
    SSL_CERT_PATH:'certs/domain.crt',
    //Bank Leumi sort code
    BL_SORT_CODE:'405259',
    //Private signing Key
    BL_PRIVATE_KEY:'gkwFlIZVgvo0anWBMuMsa20DH007plm_Y7IaA6XrxWGkZ6Eo3ny0CJIHaQMkXv4HYktuSd09nf4TrOjw4wxROA',
    //Public signing Key
    BL_PUBLIC_KEY:'pGehKN58tAiSB2kDJF7-B2JLbkndPZ3-E6zo8OMMUTg',
    //Global timeout for ESB requests
    ESB_TIMEOUT_PERIOD: 30000, //30 sec = 30*1000 (milliseconds)
    //Global timeout for Token requests
    TOKEN_TIMEOUT_PERIOD: 30000, //30 sec = 30*1000 (milliseconds)
    //Decides which callback url we need to redirect to
    USE_CONSENT_CALLBACK: true,

    //Flag to decide if tester is testing it locally with dummy data for token REST API calls
    TESTING_LOCALLY:false,
    //For payment transactions, flag to consider lifeTimeAmount or not.
    LIFE_TIME_AMNT: true,

    //JWT Header info
    //Algorithm to sign payload
    ALGO: 'EDDSA',
    //Minimum expiry time in ms that gets added to current time.
    EXPIRY_TIME: 60000, // 1min = 60*1000 (milliseconds)
    //Member Id
    MEMBER_ID:'m:3dVV2bK6YVYJRnUa8rprQsw4yWjU:5zKtXEAq',
    //Key Id generated based on Public and Private keys.
    KEY_ID: 'cIKS69UL4R6wR-1Y',
    //Endpoint for token REST API calls
    TOKEN_ENDPOINT: 'api.sandbox.token.io',

     //Secret Key for JWT token creation in Web Api
     WEB_API_SECRET_KEY: 'secretkey@2020',

     //Flag to determine if JWT is needed in Web Api
     WEB_API_USE_JWT: true,
 
     //Expiry Period of JWT token in web Api
     WEB_API_EXPIRY_TIME: '1200s'
}