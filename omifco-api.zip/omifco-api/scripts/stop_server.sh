#!/bin/bash
/home/ec2-user/apache-tomcat-9.0.8/bin/shutdown.sh
rm -rf /home/ec2-user/apache-tomcat-9.0.8/webapps/om*
