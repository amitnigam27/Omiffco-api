#!/bin/bash
/home/ec2-user/apache-tomcat-9.0.8/bin/startup.sh

