#!/bin/bash
echo In Install Dependencies...
ls /home/ec2-user/apache-tomcat-9.0.8/webapps/
rm -rf /home/ec2-user/apache-tomcat-9.0.8/webapps/om*