# Iffco API

**Iffco API** is intended to host API for all REST Services of the application.