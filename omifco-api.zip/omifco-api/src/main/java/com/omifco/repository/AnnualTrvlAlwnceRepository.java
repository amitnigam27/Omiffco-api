/**
 * 
 */
package com.omifco.repository;

import com.omifco.dto.AnnualTrvlAlwnceDTO;

/**
 * @author Prolifics
 *
 */
public interface AnnualTrvlAlwnceRepository {

	public void insertAnnualTravelAllowanceDetails(AnnualTrvlAlwnceDTO annualTrvlAlwnce);

	public void updateAnnualTravelAllowanceDetails(AnnualTrvlAlwnceDTO annualTrvlAlwnce);

	public double getEligibilityAmountByEmployeeId(String employeeId);

	public AnnualTrvlAlwnceDTO getAnnualTravelAllowanceDetails(String identifier);

}
