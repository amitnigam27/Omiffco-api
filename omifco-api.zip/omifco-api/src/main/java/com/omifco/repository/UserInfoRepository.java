package com.omifco.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.omifco.dto.ChangePasswordDTO;
import com.omifco.dto.DeviceTokenDTO;
import com.omifco.entity.DependentDetailsEntity;
import com.omifco.entity.EmployeeRoleEntity;
import com.omifco.entity.LineManagerEntity;
import com.omifco.entity.UserEntity;

@Repository
public interface UserInfoRepository {
	
	/**
	 * Retrieves Employee role based on his employee id.
	 * 
	 * @param employeeId
	 */
	public EmployeeRoleEntity getEmployeeRole(String employeeId);
	
	/**
	 * Retrieves Employee details based on his employee id.
	 * 
	 * @param employeeId
	 */
	public UserEntity getEmployeeDetails(String employeeId);
	
	/**
	 *Retrieves direct line managers of an employee based on his employee id.
	 *
	 *@param employeeId
	 */
	public List<LineManagerEntity> getLineManagers(String employeeId);
	
	/**
	 *updateEmployeeProfile updates the profile information on an employee.
	 *
	 *@param userEntity
	 */
	public void updateUserProfile(UserEntity userEntity);

	/**
	 * updateProfilePassword updates the profile password of user.
	 * 
	 * @param changePassword
	 * @param isForgotPassword
	 * @return
	 */
	public void updateProfilePassword(ChangePasswordDTO changePassword, boolean isForgotPassword);
	
	/**
	 * updateDeviceToken updates the device token for push notifications.
	 * 
	 * @param deviceTokenDto
	 * @return
	 */
	public void updateDeviceToken(DeviceTokenDTO deviceTokenDto);
	
	/**
	 *Retrieves direct dependents of an employee based on his employee id.
	 *
	 *@param employeeId
	 */
	public List<DependentDetailsEntity> getDependentDetails(String employeeId);

	public void getUserInfoByProcedure(String email);
}
