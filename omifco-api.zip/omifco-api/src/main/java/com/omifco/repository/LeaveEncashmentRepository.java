package com.omifco.repository;

import com.omifco.dto.LeaveEncashmentDTO;

public interface LeaveEncashmentRepository {
	
	/**
	 *insertEncashmentDetails is responsible to insert the leave encashment data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolledback.
	 *
	 *@param leaveEncashmentDTO
	 */
	public void insertEncashmentDetails(LeaveEncashmentDTO leaveEncashmentDTO);

	public LeaveEncashmentDTO getEncashmentDetails(String metaInfo);

	public void updateEncashmentDetails(LeaveEncashmentDTO leaveEncashmentDTO);

}
