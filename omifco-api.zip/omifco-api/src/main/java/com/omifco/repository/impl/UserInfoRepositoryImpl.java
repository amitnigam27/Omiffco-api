package com.omifco.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.omifco.dto.ChangePasswordDTO;
import com.omifco.dto.DeviceTokenDTO;
import com.omifco.entity.DependentDetailsEntity;
import com.omifco.entity.EmployeeRoleEntity;
import com.omifco.entity.LineManagerEntity;
import com.omifco.entity.UserEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.UserInfoRepository;
import com.omifco.util.OmifcoGeneralUtils;



/**
 * UtilRepositoryImpl : Implementation class of UtilRepository.
 * 
 * @author Prolifics
 *
 */
@Repository
public class UserInfoRepositoryImpl implements UserInfoRepository, MessageConstants {
	
	/**
	 * EntityManager instance is injected by Spring Framework.
	 * 
	 * This is used to manage all the Persistent entities
	 * defined in the System.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	/**
	 * Retrieves Employee role based on his employee id.
	 * 
	 * @param employeeId
	 */
	@Override
	public EmployeeRoleEntity getEmployeeRole(String employeeId) {
		EmployeeRoleEntity roleEntity = new EmployeeRoleEntity();
		UserEntity entity = getUserDetails(employeeId);
		roleEntity = entity.getRole();
		return roleEntity;
	}

	/**
	 * Retrieves Employee details based on his employee id.
	 * 
	 * @param employeeId
	 */
	@Override
	public UserEntity getEmployeeDetails(String employeeId) {		
		return getUserDetails(employeeId);
	}

	/**
	 * Retrieves Employee details based on his employee id.
	 * 
	 * @param employeeId
	 */
	private UserEntity getUserDetails(String employeeId) {
		UserEntity entity = new UserEntity();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {
			entity = entityManager.find(UserEntity.class,employeeId);
		} catch (RuntimeException e) {
		    throw new OMIFCOBusinessException(NO_USER_EXIST, NO_USER_EXIST_MSG);
		} finally {
			entityManager.clear();
			entityManager.close();
		}
		return entity;
	}

	/**
	 *Retrieves direct line managers of an employee based on his employee id.
	 *
	 *@param employeeId
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<LineManagerEntity> getLineManagers(String employeeId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "FROM LineManagerEntity where EMPLOYEE_ID ='"+employeeId+"'";
		List<LineManagerEntity> lineManagers = entityManager.createQuery(query).getResultList();
		entityManager.clear();
		entityManager.close();
		return lineManagers;
	}
	
	/**
	 *Retrieves direct dependents of an employee based on his employee id.
	 *
	 *@param employeeId
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DependentDetailsEntity> getDependentDetails(String employeeId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "FROM DependentDetailsEntity where PERSONAL_NO ='"+employeeId+"'";
		List<DependentDetailsEntity> dependentsList = entityManager.createQuery(query).getResultList();
		entityManager.clear();
		entityManager.close();
		return dependentsList;
	}

	/**
	 *updateUserProfile updates the profile information on an employee.
	 *
	 *@param newUserEntity
	 */
	@Override
	public void updateUserProfile(UserEntity newUserEntity) {
		UserEntity updatedUserEntity = updateUserEntity(newUserEntity);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		try {
			//Start of transaction
			entityTransaction.begin();
			//merge method is used to update entities into their DB table.
			entityManager.merge(updatedUserEntity);
			entityTransaction.commit();
		}catch(RuntimeException e) {
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		}finally {
			entityManager.clear();
			entityManager.close();
		}
	}

	/**
	 *updateUserEntity updates the entity information on an employee.
	 *
	 *@param newUserEntity
	 */
	private UserEntity updateUserEntity(UserEntity newUserEntity) {
		UserEntity oldUserEntity = new UserEntity();
		if(null != newUserEntity && !newUserEntity.getEmployeeID().isEmpty()) {
			oldUserEntity = getUserDetails(newUserEntity.getEmployeeID());
			if(null != newUserEntity.getContact() && !newUserEntity.getContact().isEmpty()) {
				oldUserEntity.setContact(newUserEntity.getContact());
			}
			if(null != newUserEntity.getDob()) {
				oldUserEntity.setDob(newUserEntity.getDob());
			}
			if(null != newUserEntity.getMartialStatus() && !newUserEntity.getMartialStatus().isEmpty()) {
				oldUserEntity.setMartialStatus(newUserEntity.getMartialStatus());
			}
		}else {
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		}
		return oldUserEntity;
	}

	/**
	 * updateProfilePassword updates the profile password of user.
	 * 
	 * @param changePassword
	 * @return
	 */
	@Override
	public void updateProfilePassword(ChangePasswordDTO changePassword, boolean isForgotPassword) {
		UserEntity userEntity = getUserDetails(changePassword.getEmployeeId());
		String oldEncryptedPassword ="";
		String newEncryptedPassword ="";
		if(null!=changePassword.getOldPassword() && !changePassword.getOldPassword().isEmpty()){
			oldEncryptedPassword = OmifcoGeneralUtils.getEncryptedText(changePassword.getOldPassword());
		}
		if(null!=changePassword.getNewPassword() && !changePassword.getNewPassword().isEmpty()){
			newEncryptedPassword = OmifcoGeneralUtils.getEncryptedText(changePassword.getNewPassword());
		}
		
		if(!isForgotPassword && userEntity.getPassword().equals(oldEncryptedPassword) && !newEncryptedPassword.isEmpty()) {
			updatePassword(userEntity, newEncryptedPassword);
		}else if(isForgotPassword && null!=userEntity){
			updatePassword(userEntity, newEncryptedPassword);
		}else {
			throw new OMIFCOBusinessException(INVALID_OLD_PASS_CODE, INVALID_OLD_PASS_MSG);
		}	
	}

	/**
	 * @param userEntity
	 * @param newEncryptedPassword
	 */
	private void updatePassword(UserEntity userEntity, String newEncryptedPassword) {
		userEntity.setPassword(newEncryptedPassword);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		try {
			//Start of transaction
			entityTransaction.begin();
			//merge method is used to update entities into their DB table.
			entityManager.merge(userEntity);
			entityTransaction.commit();
		}catch(RuntimeException e) {
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		}finally {
			entityManager.clear();
			entityManager.close();
		}
	}

	/**
	 * updateDeviceToken updates the device token for push notifications.
	 * 
	 * @param deviceTokenDto
	 * @return
	 */
	@Override
	public void updateDeviceToken(DeviceTokenDTO deviceTokenDto) {
		
		String updateUserInfoQuery = "FROM UserEntity where EMPLOYEE_ID = '"+deviceTokenDto.getUserId()+"'";
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		try {
			UserEntity userEntity = (UserEntity) entityManager.createQuery(updateUserInfoQuery).getResultList().get(0);
			userEntity.setDevice(deviceTokenDto.getDeviceType());
			userEntity.setDeviceToken(deviceTokenDto.getDevicetoken());
			//Start of transaction
			entityTransaction.begin();
			//merge method is used to update entities into their DB table.
			entityManager.merge(userEntity);
			entityTransaction.commit();
		}catch(RuntimeException e) {
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		}finally {
			entityManager.clear();
			entityManager.close();
		}
	}

	@Override
	public void getUserInfoByProcedure(String email) {
		// TODO Auto-generated method stub\
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		StoredProcedureQuery getUserData = entityManager.createNamedStoredProcedureQuery("GetUserByEmailAddress");
		getUserData.setParameter("emailAddress", email);
		
		Object getUserDetails = (Object) getUserData.getSingleResult();
		logger.info(getUserDetails.toString());
	}
	
	
	

}
