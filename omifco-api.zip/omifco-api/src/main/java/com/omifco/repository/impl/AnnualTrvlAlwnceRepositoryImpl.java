/**
 * 
 */
package com.omifco.repository.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceUnit;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.omifco.compositeids.PrsnlAnnualTrvlAlwnceId;
import com.omifco.compositeids.WorkflowLeaveHeaderId;
import com.omifco.dto.AnnualTrvlAlwnceDTO;
import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.entity.PrsnlAnnualTrvlAlwnceEntity;
import com.omifco.entity.UserEntity;
import com.omifco.entity.WorkflowPrsnlAnnualTrvlAlwnceEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.AnnualTrvlAlwnceRepository;
import com.omifco.repository.UserInfoRepository;
import com.omifco.service.LookupService;

/**
 * @author Anigam
 *
 */
@Repository
public class AnnualTrvlAlwnceRepositoryImpl implements AnnualTrvlAlwnceRepository, MessageConstants {

	/**
	 * EntityManager instance is injected by Spring Framework.
	 * 
	 * This is used to manage all the Persistent entities
	 * defined in the System.
	 */
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	private UserInfoRepository userInfoRepository;
	
	@Autowired
	private LookupService lookupService;

	private final int UNIT_CODE = 1010;
	private final int DOC_CODE = 1;
	private final double ELIGIBILITY_AMOUNT = 100000.00;

	@Override
	public void insertAnnualTravelAllowanceDetails(AnnualTrvlAlwnceDTO annualTrvlAlwnce){

		boolean hasValidAmount = checkClaimedAmount(annualTrvlAlwnce);
		if(hasValidAmount){

			EntityManager entityManager = entityManagerFactory.createEntityManager();
			WorkflowPrsnlAnnualTrvlAlwnceEntity workflowPrsnlAnnualTrvlAlwnceEntity= new WorkflowPrsnlAnnualTrvlAlwnceEntity();
			workflowPrsnlAnnualTrvlAlwnceEntity = updateWorkflowPrsnlAnnualTrvlAlwnceEntity(annualTrvlAlwnce, workflowPrsnlAnnualTrvlAlwnceEntity);
			PrsnlAnnualTrvlAlwnceEntity prsnlAnnualTrvlAlwnceEntity=new PrsnlAnnualTrvlAlwnceEntity();
			prsnlAnnualTrvlAlwnceEntity = updatePrsnlAnnualTrvlAlwnceEntity(annualTrvlAlwnce, prsnlAnnualTrvlAlwnceEntity);
			
			NotificationEntity notificationEntity = new NotificationEntity();
			notificationEntity = updateNotificationEntity(annualTrvlAlwnce,notificationEntity);
			ApplicationEntity applicationEntity = new ApplicationEntity(); 
			applicationEntity = updateApplicationEntity(annualTrvlAlwnce,applicationEntity);
			EntityTransaction entityTransaction = entityManager.getTransaction();
			
			try {
				//Start of transaction
				entityTransaction.begin();
				//persist method is used to do insertion of entities into their DB table.
				entityManager.persist(workflowPrsnlAnnualTrvlAlwnceEntity);
				entityManager.persist(prsnlAnnualTrvlAlwnceEntity);
				entityManager.persist(notificationEntity);
				entityManager.persist(applicationEntity);
				//commit will actually make this transaction persist in DB.
				entityTransaction.commit();
			} catch (RuntimeException e) {
				if (entityTransaction.isActive()) {
					entityTransaction.rollback();
				}
				e.printStackTrace();
				throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG,SOMETHING_WENT_WRONG_MSG);
			} finally {
				entityManager.clear();
				entityManager.close();
			}
		}		
	}

	@Override
	public void updateAnnualTravelAllowanceDetails(AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO){
		String notificationQuery;
		if(annualTrvlAlwnceDTO.getOperation().equals("Cancel")) {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Annual Travel Allowance' and META_INFO = "+annualTrvlAlwnceDTO.getDocumentSerialNo();
		}else {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Annual Travel Allowance' and META_INFO = "+annualTrvlAlwnceDTO.getDocumentSerialNo()+" and EMPLOYEE_ID='"+annualTrvlAlwnceDTO.getRequestorId()+"'";
		}
		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Annual Travel Allowance' and META_INFO = "+annualTrvlAlwnceDTO.getDocumentSerialNo();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		
		try {
			//Start of transaction

			entityTransaction.begin();
			
			WorkflowLeaveHeaderId workflowLeaveHeaderId = new WorkflowLeaveHeaderId(UNIT_CODE,DOC_CODE,annualTrvlAlwnceDTO.getDocumentSerialNo());
			PrsnlAnnualTrvlAlwnceId prsnlAnnualTrvlAlwnceId = new PrsnlAnnualTrvlAlwnceId(UNIT_CODE,annualTrvlAlwnceDTO.getDocumentSerialNo());
			
			WorkflowPrsnlAnnualTrvlAlwnceEntity workflowPrsnlAnnualTrvlAlwnceEntity = entityManager.find(WorkflowPrsnlAnnualTrvlAlwnceEntity.class,workflowLeaveHeaderId);
			workflowPrsnlAnnualTrvlAlwnceEntity = updateWorkflowPrsnlAnnualTrvlAlwnceEntity(annualTrvlAlwnceDTO ,workflowPrsnlAnnualTrvlAlwnceEntity);
			
			PrsnlAnnualTrvlAlwnceEntity prsnlAnnualTrvlAlwnceEntity= entityManager.find(PrsnlAnnualTrvlAlwnceEntity.class,prsnlAnnualTrvlAlwnceId);
			prsnlAnnualTrvlAlwnceEntity = updatePrsnlAnnualTrvlAlwnceEntity(annualTrvlAlwnceDTO, prsnlAnnualTrvlAlwnceEntity);
		
			NotificationEntity notificationEntityUpdate = (NotificationEntity) entityManager.createQuery(notificationQuery).getResultList().get(0);
			notificationEntityUpdate.setActionTaken(true);

			NotificationEntity notificationEntityInsert = new NotificationEntity();
			notificationEntityInsert = updateNotificationEntity(annualTrvlAlwnceDTO, notificationEntityInsert);
			
			ApplicationEntity applicationEntityUpdate = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
			applicationEntityUpdate = updateApplicationEntity(annualTrvlAlwnceDTO,applicationEntityUpdate);
			
			entityManager.merge(workflowPrsnlAnnualTrvlAlwnceEntity);
			entityManager.merge(prsnlAnnualTrvlAlwnceEntity);
			entityManager.merge(notificationEntityUpdate); 
			entityManager.merge(applicationEntityUpdate);
			entityManager.persist(notificationEntityInsert);
			entityTransaction.commit();
			//END of transaction
		} catch (RuntimeException e) {
			if (entityTransaction.isActive()) {
				entityTransaction.rollback();
			}
			e.printStackTrace();
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		} finally {
			entityManager.clear();
			entityManager.close();
		}
	}

	@Override
	public double getEligibilityAmountByEmployeeId(String employeeId){
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("GetUserByEmailAddress");
			query.registerStoredProcedureParameter("emailAddress", String.class , ParameterMode.IN);
			query.registerStoredProcedureParameter("name", String.class , ParameterMode.OUT);
			query.setParameter("emailAddress", "hassan.ali@omifco.com");
			query.execute();
		String getUserData =(String) query.getOutputParameterValue("name");
		
//		for (Object[] objects : getUserData) {
//			for (Object object : objects) {
//				System.out.println(object);
//			}	
//			System.out.println("*******");
//		}
		
//		getUserData.setParameter("emailAddress", "hassan.ali@omifco.com");
//		Object getUserDetails = (Object) getUserData.getSingleResult();
//		logger.info(getUserDetails.toString());
//		String query = "Call GetUserByEmailAddress('hassan.ali@omifco.com')";
//		Object getUserDetails = (Object) entityManager.createStoredProcedureQuery("GetUserByEmailAddress").registerStoredProcedureParameter("emailAddress", String.class , ParameterMode.IN);
		logger.info(getUserData);;
		return ELIGIBILITY_AMOUNT;
	}


	@Override
	public AnnualTrvlAlwnceDTO getAnnualTravelAllowanceDetails(String identifier){
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Annual Travel Allowance' and META_INFO = "+identifier;
		ApplicationEntity getApplicatioDetails = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
		AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO = new AnnualTrvlAlwnceDTO();
		
		WorkflowLeaveHeaderId workflowLeaveHeaderId = new WorkflowLeaveHeaderId(UNIT_CODE,DOC_CODE,Integer.parseInt(identifier));	
		WorkflowPrsnlAnnualTrvlAlwnceEntity workflowPrsnlAnnualTrvlAlwnceEntity = entityManager.find(WorkflowPrsnlAnnualTrvlAlwnceEntity.class,workflowLeaveHeaderId);
		
		annualTrvlAlwnceDTO.setClaimCode(workflowPrsnlAnnualTrvlAlwnceEntity.getClaimCode());
		annualTrvlAlwnceDTO.setClaimYear(workflowPrsnlAnnualTrvlAlwnceEntity.getClaimYear());
		annualTrvlAlwnceDTO.setClaimAmount(workflowPrsnlAnnualTrvlAlwnceEntity.getClaimAmount());
		annualTrvlAlwnceDTO.setApprovedAmount(workflowPrsnlAnnualTrvlAlwnceEntity.getApprovedAmount());
		annualTrvlAlwnceDTO.setEligibilityAmount(ELIGIBILITY_AMOUNT);
		annualTrvlAlwnceDTO.setDocumentSerialNo(Integer.parseInt(identifier));
		annualTrvlAlwnceDTO.setEmployeeId(workflowPrsnlAnnualTrvlAlwnceEntity.getEmployeeId());
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(annualTrvlAlwnceDTO.getEmployeeId());
		annualTrvlAlwnceDTO.setEmployeeName(empDetails.getEmployeeName());
//		for ( LookupMasterEntity appStatus : lookupService.getLookupsByType("AppStatus")) {
//			if(appStatus.getLookupName().equalsIgnoreCase(getApplicatioDetails.getAppStatus())){
//				annualTrvlAlwnceDTO.setStatus(appStatus.getLookupCode());
//			}
//		}
		switch(getApplicatioDetails.getAppStatus()){
		case "Applied":
			annualTrvlAlwnceDTO.setStatus("P");
			break;
		case "Recommended":
			annualTrvlAlwnceDTO.setStatus("R");
			break;
		case "Accepted":
			annualTrvlAlwnceDTO.setStatus("C");
			break;
		case "Rejected":
			annualTrvlAlwnceDTO.setStatus("T");
			break;		
		}
		
		return annualTrvlAlwnceDTO;
	}

	private boolean checkClaimedAmount(AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO){
		if(annualTrvlAlwnceDTO.getClaimAmount() <= ELIGIBILITY_AMOUNT)
			return true;
		else{
			throw new OMIFCOBusinessException(ANNUAL_TRVL_AMOUNT_ERROR_CODE,ANNUAL_TRVL_AMOUNT_ERROR_MSG);
		}
	}

	private WorkflowPrsnlAnnualTrvlAlwnceEntity updateWorkflowPrsnlAnnualTrvlAlwnceEntity(AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO, WorkflowPrsnlAnnualTrvlAlwnceEntity entity){
		switch(annualTrvlAlwnceDTO.getOperation()){
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentCode(DOC_CODE);
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
			entity.setEmployeeId(annualTrvlAlwnceDTO.getEmployeeId());
			entity.setClaimCode(annualTrvlAlwnceDTO.getClaimCode());
			entity.setClaimYear(annualTrvlAlwnceDTO.getClaimYear());
			entity.setClaimDate(new Date());
			entity.setClaimAmount(annualTrvlAlwnceDTO.getClaimAmount());
			entity.setEligibilityAmount(ELIGIBILITY_AMOUNT);
			entity.setApplicationType("N");
			entity.setApplicationDate(new Date());
			break;
	//	case "Recommend":
	//		break;
		case "Accept":
			entity.setApprovedAmount(annualTrvlAlwnceDTO.getApprovedAmount());
			entity.setApplicationType("C");
			break;
		case "Reject":
			entity.setApplicationType("C");
			break;
		}
		return entity;
	}

	private PrsnlAnnualTrvlAlwnceEntity updatePrsnlAnnualTrvlAlwnceEntity(AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO, PrsnlAnnualTrvlAlwnceEntity entity){
		switch(annualTrvlAlwnceDTO.getOperation()){
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setHrmsSeqNo(getMaxDocumentNo()+1);
			entity.setEmployeeId(annualTrvlAlwnceDTO.getEmployeeId());
			entity.setClaimYear(annualTrvlAlwnceDTO.getClaimYear());
			entity.setClaimDate(new Date());
			entity.setClaimAmount(annualTrvlAlwnceDTO.getClaimAmount());
			entity.setEligibleAmount(ELIGIBILITY_AMOUNT);
			entity.setCreatedBy(annualTrvlAlwnceDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			break;
		case "Recommend":
			entity.setRecommendBy(annualTrvlAlwnceDTO.getRequestorId());
			entity.setRecommendDate(new Date());
			break;
		case "Accept":
			entity.setApprovedAmount(annualTrvlAlwnceDTO.getApprovedAmount());
			entity.setApprovedBy(annualTrvlAlwnceDTO.getRequestorId());
			entity.setApprovedDate(new Date());
			break;
	//	case "Reject":
	//		break;
		}
		return entity;
	}
	
	/**
	 * updateNotificationEntity updates NotificationEntity using AnnualTrvlAlwnceDTO
	 * 
	 * @param annualTrvlAlwnceDTO
	 * @param entity
	 * @return
	 */
	private NotificationEntity updateNotificationEntity(AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO, NotificationEntity entity) {
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(annualTrvlAlwnceDTO.getEmployeeId());
		entity.setActionTaken(false);
		entity.setEmployeeId(annualTrvlAlwnceDTO.getSendTo());
		entity.setNotificationDate(new Date());
		entity.setAppType("Annual Travel Allowance");
		entity.setDeleted(false);
		switch (annualTrvlAlwnceDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(Integer.toString(getMaxDocumentNo()+1));
			entity.setNotification("Annual Travel Allowance Request : "+annualTrvlAlwnceDTO.getEmployeeId()+" - "+empDetails.getEmployeeName());
			break;
		case "Recommend":
			entity.setNotification("Annual Travel Allowance Recommended : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(annualTrvlAlwnceDTO.getDocumentSerialNo()));
			break;
		case "Accept":
			entity.setEmployeeId(annualTrvlAlwnceDTO.getEmployeeId());
			entity.setNotification("Annual Travel Allowance Accepted : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(annualTrvlAlwnceDTO.getDocumentSerialNo()));
			break;
		case "Reject":
			entity.setEmployeeId(annualTrvlAlwnceDTO.getEmployeeId());
			entity.setNotification("Annual Travel Allowance Rejected : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(annualTrvlAlwnceDTO.getDocumentSerialNo()));
			break;
		}
		return entity;
	}
	
	/**
	 * updateApplicationEntity updates Application Entity using AnnualTrvlAlwnceDTO
	 * 
	 * @param annualTrvlAlwnceDTO
	 * @param entity
	 * @return
	 */
	private ApplicationEntity updateApplicationEntity(AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO, ApplicationEntity entity) {
		entity.setEmployeeId(annualTrvlAlwnceDTO.getEmployeeId());
		entity.setAppType("Annual Travel Allowance");
		entity.setRequestedDate(new Date());
		switch (annualTrvlAlwnceDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(getMaxDocumentNo()+1);
			entity.setAppStatus("Applied");
			break;
		case "Recommend":
			entity.setAppStatus("Recommended");
			break;
		case "Accept":
			entity.setAppStatus("Accepted");
			break;
		case "Reject":
			entity.setAppStatus("Rejected");
			break;
		}
		return entity;
	}

	/**
	 * getMaxDocumentNo is a temporary method which is used to generate documentNumber.
	 *
	 */
	public int getMaxDocumentNo() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "SELECT COALESCE(MAX(metaInfo),100) FROM ApplicationEntity";
		int maxNumber = (int) entityManager.createQuery(query).getResultList().get(0);
		entityManager.clear();
		entityManager.close();

		return maxNumber;
	}
}
