package com.omifco.repository.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.omifco.compositeids.TimeLeaveDetailsId;
import com.omifco.dto.LeaveEncashmentDTO;
import com.omifco.dto.LeaveSummaryDTO;
import com.omifco.dto.RemarksDTO;
import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.LeaveBalanceSummaryEntity;
import com.omifco.entity.LeaveEncashmentEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.entity.UserEntity;
import com.omifco.entity.WorkflowLeaveEncashmentEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.LeaveApplicationRepository;
import com.omifco.repository.LeaveEncashmentRepository;
import com.omifco.repository.UserInfoRepository;

/**
 * UtilRepositoryImpl : Implementation class of UtilRepository.
 * 
 * @author Prolifics
 *
 */
@Repository
public class LeaveEncashmentRepositoryImpl implements LeaveEncashmentRepository, MessageConstants {
	
	/**
	 * EntityManager instance is injected by Spring Framework.
	 * 
	 * This is used to manage all the Persistent entities
	 * defined in the System.
	 */
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	
	@Autowired
	private LeaveApplicationRepository leaveApplicationRepository;
	
	@Autowired
	private UserInfoRepository userInfoRepository;
	
	private final int UNIT_CODE = 1010;
	private final int DOC_CODE = 1;
	
	/**
	 *insertEncashmentDetails is responsible to insert the leave encashment data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolled back.
	 *
	 *@param leaveEncashmentDTO
	 */
	@Override
	public void insertEncashmentDetails(LeaveEncashmentDTO leaveEncashmentDTO) {
		boolean hasSufficientBalance = checkLeaveEncashmentBalance(leaveEncashmentDTO);
		//proceed further to process leave encashment only if employee has sufficient balance.
		if(hasSufficientBalance) {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			LeaveEncashmentEntity leaveEncashmentEntity = new LeaveEncashmentEntity();
			leaveEncashmentEntity = updateLeaveEncashmentEntity(leaveEncashmentDTO,leaveEncashmentEntity);
			WorkflowLeaveEncashmentEntity wflLeaveEncashEntity = new WorkflowLeaveEncashmentEntity();
			wflLeaveEncashEntity = updateWflLeaveEncashmentEntity(leaveEncashmentDTO,wflLeaveEncashEntity);
			NotificationEntity notificationEntity = new NotificationEntity();
			notificationEntity = updateNotificationEntity(leaveEncashmentDTO,notificationEntity);
			ApplicationEntity applicationEntity = new ApplicationEntity(); 
			applicationEntity = updateApplicationEntity(leaveEncashmentDTO,applicationEntity);
			//Query to get leave balance so that as soon as employee apply a leave his balance gets deducted.
			String leaveBalanceQuery = "FROM LeaveBalanceSummaryEntity where LV_TYPE_CODE = '"+leaveEncashmentDTO.getLeaveType()
			+"' and PERSONAL_NO ='"+leaveEncashmentDTO.getEmployeeId()+"' and LV_PAY_FLAG=1";
			EntityTransaction entityTransaction = entityManager.getTransaction();
			try {
				//Start of transaction
				entityTransaction.begin();
				LeaveBalanceSummaryEntity leaveBalanceEntity = (LeaveBalanceSummaryEntity) entityManager.createQuery(leaveBalanceQuery).getResultList().get(0);
				//deducting encashed leaves from Balance (as of now deduction only happens from Annual Leave Balance)
				leaveBalanceEntity.setBalanceDays(leaveBalanceEntity.getBalanceDays()-leaveEncashmentDTO.getEncashmentDays());
				leaveBalanceEntity.setModifiedBy(leaveEncashmentDTO.getEmployeeId());
				leaveBalanceEntity.setDateOfModification(new Date());
				//merge method is used to update entities into their DB table.
				entityManager.merge(leaveBalanceEntity);
				//persist method is used to do insertion of entities into their DB table.
				entityManager.persist(leaveEncashmentEntity);
				entityManager.persist(wflLeaveEncashEntity);
				entityManager.persist(notificationEntity);
				entityManager.persist(applicationEntity);
				//commit will actually make this transaction persist in DB.
				entityTransaction.commit();
			} catch (RuntimeException e) {
			    if (entityTransaction.isActive()) {
			        entityTransaction.rollback();
			    }
			    e.printStackTrace();
			    throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG,SOMETHING_WENT_WRONG_MSG);
			} finally {
				entityManager.clear();
			    entityManager.close();
			}
		}else {
			throw new OMIFCOBusinessException(INSUFFICENT_LEAVE_CODE,INSUFFICENT_LEAVE_MSG);
		}
		
	}
	
	/**
	 *updateEncashmentDetails is responsible to update the leave encashment data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolled back.
	 *
	 *@param leaveEncashmentDTO
	 */
	@Override
	public void updateEncashmentDetails(LeaveEncashmentDTO leaveEncashmentDTO) {
		TimeLeaveDetailsId timLeaveDtlsId = new TimeLeaveDetailsId(UNIT_CODE,Integer.parseInt(leaveEncashmentDTO.getDocNumber()));
		String notificationQuery;
		if(leaveEncashmentDTO.getOperation().equals("Cancel")) {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Leave Encashment' and META_INFO = '"+leaveEncashmentDTO.getDocNumber()+"'";
		}else {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Leave Encashment' and META_INFO = '"+leaveEncashmentDTO.getDocNumber()+"' and EMPLOYEE_ID='"+leaveEncashmentDTO.getRequestorId()+"'";
		}
		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Leave Encashment' and META_INFO = '"+leaveEncashmentDTO.getDocNumber()+"'";
		String leaveBalanceQuery = "FROM LeaveBalanceSummaryEntity where LV_TYPE_CODE = '"+leaveEncashmentDTO.getLeaveType()
		+"' and PERSONAL_NO ='"+leaveEncashmentDTO.getEmployeeId()+"' and LV_PAY_FLAG=1";
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		try {
			//Start of transaction
			entityTransaction.begin();
			//updating respective entity objects to insert data to their respective tables using LeaveDTO
			LeaveEncashmentEntity leaveEncashmentEntity = entityManager.find(LeaveEncashmentEntity.class,timLeaveDtlsId);
			leaveEncashmentEntity = updateLeaveEncashmentEntity(leaveEncashmentDTO,leaveEncashmentEntity);		
			NotificationEntity notificationEntityUpdate = (NotificationEntity) entityManager.createQuery(notificationQuery).getResultList().get(0);
			notificationEntityUpdate = updateNotificationEntity(leaveEncashmentDTO,notificationEntityUpdate);
			notificationEntityUpdate.setActionTaken(true);
			NotificationEntity notificationEntityInsert = new NotificationEntity();
			notificationEntityInsert = updateNotificationEntity(leaveEncashmentDTO,notificationEntityInsert);
			//Overriding empId and actionTaken
			notificationEntityUpdate.setEmployeeId(leaveEncashmentDTO.getRequestorId());
			notificationEntityInsert.setActionTaken(false);
			entityManager.persist(notificationEntityInsert);
			ApplicationEntity applicationEntityUpdate = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
			applicationEntityUpdate = updateApplicationEntity(leaveEncashmentDTO,applicationEntityUpdate);
			//If encashment request gets rejected, increase his/her leave balance by same amount.
			if(leaveEncashmentDTO.getOperation().equals("Reject")) {
				LeaveBalanceSummaryEntity leaveBalanceEntity = (LeaveBalanceSummaryEntity) entityManager.createQuery(leaveBalanceQuery).getResultList().get(0);
				leaveBalanceEntity.setBalanceDays(leaveBalanceEntity.getBalanceDays()+leaveEncashmentEntity.getDaysEncashed());
				entityManager.merge(leaveBalanceEntity);
			}
			entityManager.merge(leaveEncashmentEntity);
			entityManager.merge(notificationEntityUpdate);
			entityManager.merge(applicationEntityUpdate);
			entityTransaction.commit();
			//END of transaction
		} catch (RuntimeException e) {
		    if (entityTransaction.isActive()) {
		        entityTransaction.rollback();
		    }
		    e.printStackTrace();
		    throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		} finally {
			entityManager.clear();
		    entityManager.close();
		}
	}
	/**
	 * getEncashmentDetails returns the leave encashment request details based on document number 
	 * generated during the time of submitting request.
	 * 
	 *@param docNumber
	 */
	@Override
	public LeaveEncashmentDTO getEncashmentDetails(String docNumber) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String encashmentDetailquery = "FROM LeaveEncashmentEntity where UNIT_CODE = "+UNIT_CODE+" and DOCCUMENT_NO ="+docNumber;
		LeaveEncashmentEntity leaveEncashmentEntity = (LeaveEncashmentEntity) entityManager.createQuery(encashmentDetailquery).getResultList().get(0);
		LeaveEncashmentDTO response = new LeaveEncashmentDTO();
		if(null != leaveEncashmentEntity) {
			UserEntity empDetails = userInfoRepository.getEmployeeDetails(leaveEncashmentEntity.getEmployeeId());
			response.setDocNumber(docNumber);
			response.setEmployeeId(leaveEncashmentEntity.getEmployeeId());
			response.setEncashmentAmount(leaveEncashmentEntity.getAmount());
			response.setEncashmentDays(leaveEncashmentEntity.getDaysEncashed());
			response.setEncashmentNo(Integer.toString(leaveEncashmentEntity.getEncashmentNo()));
			response.setLeaveEncashmentStatus(leaveEncashmentEntity.getEncashStatus());
			response.setLeaveType(leaveEncashmentEntity.getLeaveTypeCode());
			response.setPaymentDate(leaveEncashmentEntity.getPaymentDate());
			response.setPaymentMode(leaveEncashmentEntity.getPaymentMode());
			response.setSalaryMonth(leaveEncashmentEntity.getSalaryMonth());
			response.setSalaryProcessed(leaveEncashmentEntity.isSalaryProcessed());
			response.setEmployeeName(empDetails.getEmployeeName());
			List<RemarksDTO> listOfRemarks = new ArrayList<RemarksDTO>();
			String approverRemarks = leaveEncashmentEntity.getRemarks();
			//Logic to distinguish remarks of all approvers.
			try {
				if(null!=approverRemarks && approverRemarks.contains(":")) {
					String[] remarksArray = approverRemarks.split(":");
					for (String remark : remarksArray) {
						if(remark.contains(" - ")) {
							RemarksDTO remarksDTO = new RemarksDTO();
							remarksDTO.setApproverName(remark.split(" - ",2)[0]);
							remarksDTO.setApproverRemarks(remark.split(" - ",2)[1]);
							listOfRemarks.add(remarksDTO);
						}
					}
				}else if(null!=approverRemarks && !approverRemarks.isEmpty()){
					if(approverRemarks.contains(" - ")) {
						RemarksDTO remarksDTO = new RemarksDTO();
						remarksDTO.setApproverName(approverRemarks.split(" - ",2)[0]);
						remarksDTO.setApproverRemarks(approverRemarks.split(" - ",2)[1]);
						listOfRemarks.add(remarksDTO);
					}
				}
				response.setApproverRemarks(listOfRemarks);
			}catch(Exception e) {
				throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
			}
		}
		return response;
	}

	/**
	 * updateApplicationEntity updates Application Entity using LeaveEncashmentDTO
	 * 
	 * @param LeaveEncashmentDTO
	 * @param entity
	 * @return
	 */
	private ApplicationEntity updateApplicationEntity(LeaveEncashmentDTO leaveEncashmentDTO, ApplicationEntity entity) {
		entity.setEmployeeId(leaveEncashmentDTO.getEmployeeId());
		entity.setAppType("Leave Encashment");
		entity.setRequestedDate(new Date());
		switch (leaveEncashmentDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(getMaxDocumentNo()+1);
			entity.setAppStatus("Applied");
			break;
		case "Recommend":
			entity.setAppStatus("Recommended");
			break;
		case "Accept":
			entity.setAppStatus("Accepted");
			break;
		case "Reject":
			entity.setAppStatus("Rejected");
			break;
		}
		return entity;
	}

	/**
	 * updateNotificationEntity updates NotificationEntity using LeaveEncashmentDTO
	 * 
	 * @param LeaveEncashmentDTO
	 * @param entity
	 * @return
	 */
	private NotificationEntity updateNotificationEntity(LeaveEncashmentDTO leaveEncashmentDTO, NotificationEntity entity) {
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(leaveEncashmentDTO.getEmployeeId());
		entity.setActionTaken(false);
		entity.setEmployeeId(leaveEncashmentDTO.getSendTo());
		entity.setNotificationDate(new Date());
		entity.setAppType("Leave Encashment");
		entity.setDeleted(false);
		switch (leaveEncashmentDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(Integer.toString(getMaxDocumentNo()+1));
			entity.setNotification("Leave Encashment Request : "+leaveEncashmentDTO.getEmployeeId()+" - "+empDetails.getEmployeeName());
			break;
		case "Recommend":
			entity.setNotification("Leave Encashment Recommended : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(leaveEncashmentDTO.getDocNumber());
			break;
		case "Accept":
			entity.setEmployeeId(leaveEncashmentDTO.getEmployeeId());
			entity.setNotification("Leave Encashment Accepted : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(leaveEncashmentDTO.getDocNumber());
			break;
		case "Reject":
			entity.setEmployeeId(leaveEncashmentDTO.getEmployeeId());
			entity.setNotification("Leave Encashment Rejected : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(leaveEncashmentDTO.getDocNumber());
			break;
		}
		return entity;
	}
	
	

	private WorkflowLeaveEncashmentEntity updateWflLeaveEncashmentEntity(LeaveEncashmentDTO leaveEncashmentDTO,	WorkflowLeaveEncashmentEntity entity) {
		
		entity.setApplicationDate(new Date());
		entity.setApplicationType("N");
		entity.setDaysEncashed(leaveEncashmentDTO.getEncashmentDays());
		entity.setDocumentCode(DOC_CODE);
		entity.setDocumentSerialNo(getMaxDocumentNo()+1);
		entity.setEmployeeId(leaveEncashmentDTO.getEmployeeId());
		entity.setLeaveTypeCode(leaveEncashmentDTO.getLeaveType());
		entity.setUnitCode(UNIT_CODE);
		
		return entity;
	}

	private LeaveEncashmentEntity updateLeaveEncashmentEntity(LeaveEncashmentDTO leaveEncashmentDTO,LeaveEncashmentEntity entity) {
		double amountPerLeave = 125;
		double amount = 0;
		//amount per leave will be different against different employee roles
		if(leaveEncashmentDTO.getEmployeeRole().equalsIgnoreCase("USER")) {
			amount = amountPerLeave * leaveEncashmentDTO.getEncashmentDays();
		}else if(leaveEncashmentDTO.getEmployeeRole().equalsIgnoreCase("RECOMMENDER")) {
			amountPerLeave = amountPerLeave + 100;
			amount = amountPerLeave * leaveEncashmentDTO.getEncashmentDays();
		}else if(leaveEncashmentDTO.getEmployeeRole().equalsIgnoreCase("APPROVER")) {
			amountPerLeave = amountPerLeave + 200;
			amount = amountPerLeave * leaveEncashmentDTO.getEncashmentDays();
		}else if(leaveEncashmentDTO.getEmployeeRole().equalsIgnoreCase("TIMEOFFICE")) {
			amountPerLeave = amountPerLeave + 300;
			amount = amountPerLeave * leaveEncashmentDTO.getEncashmentDays();	
		}
		UserEntity currentUserDetails = userInfoRepository.getEmployeeDetails(leaveEncashmentDTO.getRequestorId());
		switch (leaveEncashmentDTO.getOperation()) {
		case "Apply":
			entity.setApplicationDate(new Date());
			entity.setArrear(0);
			entity.setCreatedBy(leaveEncashmentDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			entity.setDaysEncashed(leaveEncashmentDTO.getEncashmentDays());
			entity.setDocumentNumber(getMaxDocumentNo()+1);
			entity.setEmployeeId(leaveEncashmentDTO.getEmployeeId());
			entity.setEncashmentNo(getMaxDocumentNo()+10);
			entity.setEncashStatus("P"); //Pending
			entity.setLeaveTypeCode(leaveEncashmentDTO.getLeaveType());
			entity.setSalaryProcessed(false);
			entity.setUnitCode(UNIT_CODE);
			entity.setAmount(amount);
			break;
		case "Recommend":
			entity.setDocumentNumber(Integer.parseInt(leaveEncashmentDTO.getDocNumber()));
			entity.setRecommendBy(leaveEncashmentDTO.getRequestorId());
			entity.setRecommendDate(new Date());
			entity.setRemarks(currentUserDetails.getEmployeeName()+" - "+leaveEncashmentDTO.getRemarks());
			entity.setEncashStatus("R"); //Recommended
			break;
		case "Accept":
			entity.setDocumentNumber(Integer.parseInt(leaveEncashmentDTO.getDocNumber()));
			entity.setApprovedBy(leaveEncashmentDTO.getRequestorId());
			entity.setApprovedDate(new Date());
			entity.setRemarks(entity.getRemarks()+":"+currentUserDetails.getEmployeeName()+" - "+leaveEncashmentDTO.getRemarks());
			entity.setEncashStatus("C"); //Accepted
			entity.setPaymentDate(leaveEncashmentDTO.getPaymentDate());
			entity.setPaymentMode(leaveEncashmentDTO.getPaymentMode());
			entity.setPaymentBy(leaveEncashmentDTO.getRequestorId());
			entity.setSalaryMonth(leaveEncashmentDTO.getSalaryMonth());
			entity.setSalaryProcessed(leaveEncashmentDTO.isSalaryProcessed());
			break;
		case "Reject":
			entity.setEncashStatus("T");//Rejected - Terminated
			entity.setRemarks(currentUserDetails.getEmployeeName()+" - "+leaveEncashmentDTO.getRemarks());
			break;
		}
		
		
		return entity;
	}
	
	/**
	 * getMaxDocumentNo is a temporary method which is used to generate documentNumber.
	 *
	 */
	public int getMaxDocumentNo() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "SELECT COALESCE(MAX(metaInfo),100) FROM ApplicationEntity";
		int maxNumber = (int) entityManager.createQuery(query).getResultList().get(0);
		entityManager.clear();
		entityManager.close();
		return maxNumber;
		
	}

	private boolean checkLeaveEncashmentBalance(LeaveEncashmentDTO leaveEncashmentDTO) {
		LeaveSummaryDTO leaveBalanceInfo = leaveApplicationRepository.getLeaveBalanceSummaryById(leaveEncashmentDTO.getEmployeeId());
		if(leaveEncashmentDTO.getEncashmentDays() > 0 && leaveBalanceInfo.getTotalEncashableLeaves()>= leaveEncashmentDTO.getEncashmentDays() && leaveBalanceInfo.getAnnualLeaves() > leaveEncashmentDTO.getEncashmentDays()) {
			return true;
		}
		return false;
	}
	
}
