package com.omifco.repository.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.LineManagerEntity;
import com.omifco.entity.LookupMasterEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.entity.UserEntity;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.UserInfoRepository;
import com.omifco.repository.UtilRepository;

/**
 * UtilRepositoryImpl : Implementation class of UtilRepository.
 * 
 * @author Prolifics
 *
 */
@Repository
public class UtilRepositoryImpl implements UtilRepository, MessageConstants {
	
	/**
	 * EntityManager instance is injected by Spring Framework.
	 * 
	 * This is used to manage all the Persistent entities
	 * defined in the System.
	 */
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	
	@Autowired
	private UserInfoRepository userInfoRepository;
	
	
	/**
	 * getLookupsByType returns all active Master Lookup
	 * entries of a specified type from the database.
	 * @param lookupType
	 * 	<p>The type of Lookup values desired.</p>
	 * @return
	 * 	<p>List of <strong>LookupMasterEntity</strong> instances.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<LookupMasterEntity> getLookupsByType(String lookupType) {
		String query = "FROM LookupMasterEntity WHERE LOOKUP_TYPE = '"+lookupType+"' and IS_ACTIVE =1";
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<LookupMasterEntity> lookupsList = entityManager.createQuery(query).getResultList();
		entityManager.clear();
		entityManager.close();
		return lookupsList;
	}
	
	/**
	 * getAllRequestsOfUser returns all Application Requests
	 * of a User.
	 * @param empId
	 * 	<p>Employee Id of the User.</p>
	 * @return
	 * 	<p>List of <strong>ApplicationEntity</strong> instances.
	 */
	public List<ApplicationEntity> getAllRequestsOfUser(String empId){
		List<ApplicationEntity> requests = null;
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		CriteriaBuilder criteriaBuilder 		= entityManager.getCriteriaBuilder();		
		CriteriaQuery<ApplicationEntity> query 	= criteriaBuilder.createQuery(ApplicationEntity.class);		
		Root<ApplicationEntity> applicationRoot = query.from(ApplicationEntity.class);
		query.select(applicationRoot).where(criteriaBuilder.equal(applicationRoot.get("employeeId"), empId));		
		query.orderBy(criteriaBuilder.desc(applicationRoot.get("requestedDate")));
		requests = entityManager.createQuery(query).getResultList();
		entityManager.clear();
		entityManager.close();
		return requests;
		
	}
	
	/**
	 * getNotificationsOfUserByType returns all current and historical
	 * Notifications of a User based on specified type.
	 * @param empId
	 * 	<p>Employee Id of the User.</p>
	 * @param unActionedOnly
	 * 	<p>Flag to specify if only un-actioned item to return.</p>
	 * @return
	 * 	<p>List of <strong>NotificationEntity</strong> instances.
	 */
	public List<NotificationEntity> getNotificationsOfUserByType(String empId, boolean unActionedOnly){
		List<NotificationEntity> list = null;
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		if(unActionedOnly){
			list = entityManager.createNamedQuery("getActiveNotificationsOfUser", NotificationEntity.class)
				    .setParameter(1, empId).getResultList();
		}else{
			list = entityManager.createNamedQuery("getAllNotificationsOfUser", NotificationEntity.class)
				    .setParameter(1, empId).getResultList();
		}
		if(null != list && !list.isEmpty()) {
			EntityTransaction entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			for (NotificationEntity notificationEntity : list) {
				String updateNotificationQuery = "FROM NotificationEntity where NOTIFICATION_ID = "+notificationEntity.getNotificationId();
				NotificationEntity notificationEntityUpdate = (NotificationEntity) entityManager.createQuery(updateNotificationQuery).getResultList().get(0);
				if(!notificationEntityUpdate.isActionTaken() && (notificationEntityUpdate.getNotification().contains("Accepted") || notificationEntityUpdate.getNotification().contains("Rejected"))) {
					notificationEntityUpdate.setActionTaken(true);
					entityManager.merge(notificationEntityUpdate);
				}
			}
			entityTransaction.commit();
			entityManager.clear();
			entityManager.close();
		}
		return list;
	}
	
	/**
	 *getAllApprovers returns a map of all direct line managers of an employee.
	 *
	 *@param employeeId
	 */
	@Override
	public Map<String,String> getAllApprovers(String employeeId,int levels) {
		List<LineManagerEntity> lineManagers = userInfoRepository.getLineManagers(employeeId);
		UserEntity loggedInUser = userInfoRepository.getEmployeeDetails(employeeId);
		Map<String,String> lineManagersMap = new HashMap<String,String>();
		for (LineManagerEntity lineManager : lineManagers) {
			if(levels == 3 || loggedInUser.getRole().getRole().equalsIgnoreCase("USER")) {
				UserEntity empDetails = userInfoRepository.getEmployeeDetails(lineManager.getLineManagerId());
				lineManagersMap.put(lineManager.getLineManagerId(), empDetails.getEmployeeName());
			}else if(levels == 2 && !loggedInUser.getRole().getRole().equalsIgnoreCase("USER") && lineManager.getFinalApprover() != null) {
				UserEntity empDetails = userInfoRepository.getEmployeeDetails(lineManager.getFinalApprover());
				lineManagersMap.put(lineManager.getFinalApprover(), empDetails.getEmployeeName());
			}
			
		}
		return lineManagersMap;
	}

}
