/**
 * 
 */
package com.omifco.repository;

import com.omifco.dto.EmployeeTourDTO;

/**
 * @author Anigam
 *
 */
public interface EmployeeTourRepository {
	
	public void insertEmployeeTourDetails(EmployeeTourDTO employeeTourDTO);
	
	public void updateEmployeeTourDetails(EmployeeTourDTO employeeTourDTO);

	public EmployeeTourDTO getTourDetails(String identifier);

}
