package com.omifco.repository.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.omifco.compositeids.PrsnlSchlTutionFeeId;
import com.omifco.compositeids.WorkflowLeaveHeaderId;
import com.omifco.dto.FeeReimbursementDTO;
import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.DependentDetailsEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.entity.PrsnlSchlTutionFeeDetailsEntity;
import com.omifco.entity.PrsnlSchlTutionFeeHeaderEntity;
import com.omifco.entity.UserEntity;
import com.omifco.entity.WorkflowPrsnlSchlTutnFeeDetailsEntity;
import com.omifco.entity.WorkflowPrsnlSchlTutnFeeHeaderEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.TutionFeeRepository;
import com.omifco.repository.UserInfoRepository;



@Repository
public class TutionFeeRepositoryImpl implements TutionFeeRepository, MessageConstants {

	/**
	 * EntityManager instance is injected by Spring Framework.
	 * 
	 * This is used to manage all the Persistent entities
	 * defined in the System.
	 */
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;


	@Autowired
	private UserInfoRepository userInfoRepository;
	
	private DependentDetailsEntity dependentDetailsEntity;

	private final int UNIT_CODE = 1020;
	private final int DOC_CODE = 1;
	
	/**
	 *insertTutionFeeDetails is responsible to insert the tution fee claim data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolled back.
	 *
	 *@param feeReimburseDTO
	 */
	@Override
	public void insertTutionFeeDetails(FeeReimbursementDTO feeReimbursementDTO){
		
		boolean isValidAmount = checkClaimedAmount(feeReimbursementDTO);
		boolean isValidYear = checkDependentClaimHeaders(feeReimbursementDTO.getEmployeeId(), feeReimbursementDTO.getDependentSerialNo(), feeReimbursementDTO.getClaimYear());
		if(isValidAmount && isValidYear) {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			WorkflowPrsnlSchlTutnFeeHeaderEntity workflowPrsnlSchlTutnFeeHeaderEntity = new WorkflowPrsnlSchlTutnFeeHeaderEntity();
			workflowPrsnlSchlTutnFeeHeaderEntity = updateWorkflowPrsnlSchlTutnFeeHeaderEntity(feeReimbursementDTO, workflowPrsnlSchlTutnFeeHeaderEntity);
			WorkflowPrsnlSchlTutnFeeDetailsEntity workflowPrsnlSchlTutnFeeDetailsEntity = new WorkflowPrsnlSchlTutnFeeDetailsEntity();
			workflowPrsnlSchlTutnFeeDetailsEntity = updateWorkflowPrsnlSchlTutnFeeDetailsEntity(feeReimbursementDTO, workflowPrsnlSchlTutnFeeDetailsEntity);
			PrsnlSchlTutionFeeHeaderEntity prsnlSchlTutionFeeHeaderEntity= new PrsnlSchlTutionFeeHeaderEntity();
			prsnlSchlTutionFeeHeaderEntity = updatePrsnlSchlTutionFeeHeaderEntity(feeReimbursementDTO, prsnlSchlTutionFeeHeaderEntity);
			PrsnlSchlTutionFeeDetailsEntity prsnlSchlTutionFeeDetailsEntity = new PrsnlSchlTutionFeeDetailsEntity();
			prsnlSchlTutionFeeDetailsEntity = updatePrsnlSchlTutionFeeDetailsEntity(feeReimbursementDTO, prsnlSchlTutionFeeDetailsEntity);
			NotificationEntity notificationEntity = new NotificationEntity();
			notificationEntity = updateNotificationEntity(feeReimbursementDTO,notificationEntity);
			ApplicationEntity applicationEntity = new ApplicationEntity(); 
			applicationEntity = updateApplicationEntity(feeReimbursementDTO,applicationEntity);
			EntityTransaction entityTransaction = entityManager.getTransaction();
			try {
				//Start of transaction
				entityTransaction.begin();

				//persist method is used to do insertion of entities into their DB table.
				entityManager.persist(workflowPrsnlSchlTutnFeeHeaderEntity);
				entityManager.persist(workflowPrsnlSchlTutnFeeDetailsEntity);
				entityManager.persist(prsnlSchlTutionFeeHeaderEntity);
				entityManager.persist(prsnlSchlTutionFeeDetailsEntity);
				entityManager.persist(notificationEntity);
				entityManager.persist(applicationEntity);

				//commit will actually make this transaction persist in DB.
				entityTransaction.commit();
			} catch (RuntimeException e) {
				if (entityTransaction.isActive()) {
					entityTransaction.rollback();
				}
				e.printStackTrace();
				throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG,SOMETHING_WENT_WRONG_MSG);
			} finally {
				entityManager.clear();
				entityManager.close();
			}
		}
	}


	/**
	 *updateTutionFeeDetails is responsible to update the tution fee claim data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolled back.
	 *
	 *@param feeReimburseDTO
	 */
	@Override
	public void updateTutionFeeDetails(FeeReimbursementDTO feeReimbursementDTO) {
		PrsnlSchlTutionFeeId prsnlSchlTutionFeeId = new PrsnlSchlTutionFeeId(UNIT_CODE,feeReimbursementDTO.getEmployeeId(),feeReimbursementDTO.getClaimsSrNumber());
		String notificationQuery;
		if(feeReimbursementDTO.getOperation().equals("Cancel")) {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Tution Fee' and META_INFO = '"+feeReimbursementDTO.getClaimsSrNumber()+"'";
		}else {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Tution Fee' and META_INFO = '"+feeReimbursementDTO.getClaimsSrNumber()+"' and EMPLOYEE_ID='"+feeReimbursementDTO.getRequestorId()+"'";
		}
		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Tution Fee' and META_INFO = '"+feeReimbursementDTO.getClaimsSrNumber()+"'";
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		try {
			//Start of transaction
			entityTransaction.begin();
			//updating respective entity objects to insert data to their respective tables using LeaveDTO
			PrsnlSchlTutionFeeDetailsEntity prsnlSchlTutionFeeDetailsEntity = entityManager.find(PrsnlSchlTutionFeeDetailsEntity.class,prsnlSchlTutionFeeId);
			prsnlSchlTutionFeeDetailsEntity = updatePrsnlSchlTutionFeeDetailsEntity(feeReimbursementDTO,prsnlSchlTutionFeeDetailsEntity);
			WorkflowLeaveHeaderId workflowLeaveHeaderId = new WorkflowLeaveHeaderId(UNIT_CODE,DOC_CODE,feeReimbursementDTO.getClaimsSrNumber());
			WorkflowPrsnlSchlTutnFeeHeaderEntity workflowPrsnlSchlTutnFeeHeaderEntity = entityManager.find(WorkflowPrsnlSchlTutnFeeHeaderEntity.class,workflowLeaveHeaderId);
			workflowPrsnlSchlTutnFeeHeaderEntity = updateWorkflowPrsnlSchlTutnFeeHeaderEntity(feeReimbursementDTO, workflowPrsnlSchlTutnFeeHeaderEntity);
			PrsnlSchlTutionFeeHeaderEntity prsnlSchlTutionFeeHeaderEntity = entityManager.find(PrsnlSchlTutionFeeHeaderEntity.class, prsnlSchlTutionFeeId);
			prsnlSchlTutionFeeHeaderEntity = updatePrsnlSchlTutionFeeHeaderEntity(feeReimbursementDTO, prsnlSchlTutionFeeHeaderEntity);

			NotificationEntity notificationEntityUpdate = (NotificationEntity) entityManager.createQuery(notificationQuery).getResultList().get(0);
			notificationEntityUpdate = updateNotificationEntity(feeReimbursementDTO,notificationEntityUpdate);
			notificationEntityUpdate.setActionTaken(true);
			//Overriding empId and actionTaken
			notificationEntityUpdate.setEmployeeId(feeReimbursementDTO.getRequestorId());
			NotificationEntity notificationEntityInsert = new NotificationEntity();
			notificationEntityInsert = updateNotificationEntity(feeReimbursementDTO,notificationEntityInsert);
			notificationEntityInsert.setActionTaken(false);
			
			ApplicationEntity applicationEntityUpdate = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
			applicationEntityUpdate = updateApplicationEntity(feeReimbursementDTO,applicationEntityUpdate);
			
			entityManager.persist(notificationEntityInsert);
			entityManager.merge(prsnlSchlTutionFeeDetailsEntity);
			entityManager.merge(notificationEntityUpdate); 
			entityManager.merge(applicationEntityUpdate);
			entityManager.merge(prsnlSchlTutionFeeHeaderEntity);
			entityManager.merge(workflowPrsnlSchlTutnFeeHeaderEntity);

			entityTransaction.commit();
			//END of transaction
		} catch (RuntimeException e) {
			if (entityTransaction.isActive()) {
				entityTransaction.rollback();
			}
			e.printStackTrace();
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		} finally {
			entityManager.clear();
			entityManager.close();
		}
	}
	
	/**
	 * checkClaimedAmount returns the boolean value to true only if claimed amount is less than or equal to admisible amount
	 * 
	 *@param feeReimbursementDTO
	 */
	private boolean checkClaimedAmount(FeeReimbursementDTO feeReimbursementDTO) {
		dependentDetailsEntity = getDependentDetail(feeReimbursementDTO.getEmployeeId(), feeReimbursementDTO.getDependentSerialNo());
		if(feeReimbursementDTO.getClaimedAmount() > 0 && dependentDetailsEntity.getAdmisibleFeeClaimAmount() >= feeReimbursementDTO.getClaimedAmount()){
			return true;
		}
		else {
			throw new OMIFCOBusinessException(REIMBURSE_AMOUNTERROR_CODE,REIMBURSE_AMOUNTERROR_MSG);
		}
	}
	/**
	 * checkDependentClaimHeaders returns the boolean value to true only if employee has not submitted the claim for the dependent for that year
	 * 
	 *@param employeeId 
	 *@param dependentSerialNo
	 *@param claimYear
	 */
	public boolean checkDependentClaimHeaders(String employeeId, int dependentSerialNo, int claimYear){
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String yearQuery = "FROM PrsnlSchlTutionFeeDetailsEntity WHERE PERSONAL_NO = '"+employeeId+"' AND DEPENDENT_SNO ="+dependentSerialNo+" AND CLAIM_YEAR="+claimYear;	
		if(entityManager.createQuery(yearQuery).getResultList().size() > 0)
			throw new OMIFCOBusinessException(REIMBURSE_YEARERROR_CODE,REIMBURSE_YEARERROR_MSG);
		else{
			entityManager.clear();
			entityManager.close();
			return true;
		}
	}
	/**
	 * getDependentDetail returns the dependent details based on based on the employeeId and dependent Serial No 
	 * generated during the time of submitting request.
	 * 
	 *@param employeeId
	 *@param dependentSerialNo
	 */
	public DependentDetailsEntity getDependentDetail(String employeeId, int dependentSerialNo) {
		DependentDetailsEntity dependentDetailsEntity =	new DependentDetailsEntity();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String amtQuery = "FROM DependentDetailsEntity WHERE PERSONAL_NO = '"+employeeId+"' AND DEPENDENT_SNO ="+dependentSerialNo;
		try{
			dependentDetailsEntity =  (DependentDetailsEntity) entityManager.createQuery(amtQuery).getResultList().get(0);
		}catch(Exception e){
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		}finally {
			entityManager.clear();
			entityManager.close();
		}
		return dependentDetailsEntity;
	}
	/**
	 * updateWorkflowPrsnlSchlTutnFeeHeaderEntity updates WorkflowPrsnlSchlTutnFeeHeaderEntity using FeeReimbursementDTO
	 * 
	 * @param FeeReimbursementDTO
	 * @param entity
	 * @return
	 */
	private WorkflowPrsnlSchlTutnFeeHeaderEntity updateWorkflowPrsnlSchlTutnFeeHeaderEntity(FeeReimbursementDTO feeReimbursementDTO, WorkflowPrsnlSchlTutnFeeHeaderEntity entity){
		switch (feeReimbursementDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentCode(DOC_CODE);
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
			entity.setEmployeeId(feeReimbursementDTO.getEmployeeId());
			entity.setClaimYear(feeReimbursementDTO.getClaimYear());
			entity.setClaimDate(new Date());
			entity.setClaimAmount(feeReimbursementDTO.getClaimedAmount());
			entity.setClaimedMembers(feeReimbursementDTO.getDependentSerialNo());
			entity.setApplicationType("N");
			entity.setEducationalYear(feeReimbursementDTO.getClaimYear());
			entity.setSchoolName(dependentDetailsEntity.getSchoolName());
			entity.setSchoolAddress(dependentDetailsEntity.getSchoolAddress());
			entity.setCreatedBy(feeReimbursementDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			entity.setClaimSerialNo(getMaxDocumentNo()+1);
			break;
		case "Recommend":
			entity.setRecommendBy(feeReimbursementDTO.getRequestorId());
			entity.setRecommendDate(new Date());
			break;
		case "Accept":
			entity.setApprovedBy(feeReimbursementDTO.getRequestorId());
			entity.setApprovedDate(new Date());
			break;
		case "Reject":
			entity.setApplicationType("C");//Cancelled
			break;
		}
		return entity;
	}
	/**
	 * updateWorkflowPrsnlSchlTutnFeeDetailsEntity updates WorkflowPrsnlSchlTutnFeeDetailsEntity using FeeReimbursementDTO
	 * 
	 * @param FeeReimbursementDTO
	 * @param entity
	 * @return
	 */
	private WorkflowPrsnlSchlTutnFeeDetailsEntity updateWorkflowPrsnlSchlTutnFeeDetailsEntity(FeeReimbursementDTO feeReimbursementDTO, WorkflowPrsnlSchlTutnFeeDetailsEntity entity){
		switch (feeReimbursementDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentCode(DOC_CODE);
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
			entity.setEmployeeId(feeReimbursementDTO.getEmployeeId());
			entity.setClaimYear(feeReimbursementDTO.getClaimYear());
			entity.setdependentSerialNo(feeReimbursementDTO.getDependentSerialNo());
			entity.setAdmisibleAmount(dependentDetailsEntity.getAdmisibleFeeClaimAmount());
			entity.setClaimedAmount(feeReimbursementDTO.getClaimedAmount());
			entity.setclassNo(dependentDetailsEntity.getClassNo());
			entity.setFeePaid(feeReimbursementDTO.getFeePaid());
			entity.setAge(dependentDetailsEntity.getAge());
			entity.setCreatedBy(feeReimbursementDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			entity.setclaimSerialNo(getMaxDocumentNo()+1);
			break;
		}
		return entity;	
	}
	
	/**
	 * updatePrsnlSchlTutionFeeHeaderEntity updates PrsnlSchlTutionFeeHeaderEntity using FeeReimbursementDTO
	 * 
	 * @param FeeReimbursementDTO
	 * @param entity
	 * @return
	 */
	private PrsnlSchlTutionFeeHeaderEntity updatePrsnlSchlTutionFeeHeaderEntity(FeeReimbursementDTO feeReimbursementDTO, PrsnlSchlTutionFeeHeaderEntity entity){
		switch (feeReimbursementDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setEmployeeId(feeReimbursementDTO.getEmployeeId());
			entity.setClaimYear(feeReimbursementDTO.getClaimYear());
			entity.setClaimDate(new Date());
			entity.setClaimAmount(feeReimbursementDTO.getClaimedAmount());
			entity.setClaimedMembers(feeReimbursementDTO.getDependentSerialNo());
			entity.setEducationalYear(feeReimbursementDTO.getClaimYear());
			entity.setSchoolName(dependentDetailsEntity.getSchoolName());
			entity.setSchoolAddress(dependentDetailsEntity.getSchoolAddress());
			entity.setCreatedBy(feeReimbursementDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			entity.setClaimSerialNo(getMaxDocumentNo()+1);
			break;

		case "Recommend":
			entity.setRecommendBy(feeReimbursementDTO.getRequestorId());
			entity.setRecommendDate(new Date());
			break;
		case "Accept":
			entity.setApprovedBy(feeReimbursementDTO.getRequestorId());
			entity.setApprovedDate(new Date());
			entity.setApprovedAmount(feeReimbursementDTO.getClaimedAmount());

		}
		return entity;
	}
	
	/**
	 * updatePrsnlSchlTutionFeeDetailsEntity updates PrsnlSchlTutionFeeDetailsEntity using FeeReimbursementDTO
	 * 
	 * @param FeeReimbursementDTO
	 * @param entity
	 * @return
	 */
	private PrsnlSchlTutionFeeDetailsEntity updatePrsnlSchlTutionFeeDetailsEntity(FeeReimbursementDTO feeReimbursementDTO, PrsnlSchlTutionFeeDetailsEntity entity){

		switch (feeReimbursementDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setEmployeeId(feeReimbursementDTO.getEmployeeId());
			entity.setClaimYear(feeReimbursementDTO.getClaimYear());
			entity.setDependentSerialNo(feeReimbursementDTO.getDependentSerialNo());
			entity.setAdmisibleAmount(dependentDetailsEntity.getAdmisibleFeeClaimAmount());
			entity.setAge(dependentDetailsEntity.getAge());
			entity.setCreatedBy(feeReimbursementDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			entity.setFeePaid(feeReimbursementDTO.getFeePaid());
			entity.setclassNo(dependentDetailsEntity.getClassNo());
			entity.setClaimedAmount(feeReimbursementDTO.getClaimedAmount());
			entity.setStatus("P");
			entity.setClaimSerialNo(getMaxDocumentNo()+1);
			break;
		case "Recommend":
			entity.setStatus("R");
			break;
		case "Accept":
			entity.setStatus("C");
			break;
		case "Reject":
			entity.setStatus("T");//Rejected - Terminated
			break;

		}
		return entity;
	}
	/**
	 * updateNotificationEntity updates NotificationEntity using FeeReimbursementDTO
	 * 
	 * @param FeeReimbursementDTO
	 * @param entity
	 * @return
	 */
	private NotificationEntity updateNotificationEntity(FeeReimbursementDTO feeReimbursementDTO, NotificationEntity entity) {
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(feeReimbursementDTO.getEmployeeId());
		entity.setActionTaken(false);
		entity.setEmployeeId(feeReimbursementDTO.getSendTo());
		entity.setNotificationDate(new Date());
		entity.setAppType("Tution Fee");
		entity.setDeleted(false);
		switch (feeReimbursementDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(Integer.toString(getMaxDocumentNo()+1));
			entity.setNotification("Tution Fee Claim Request : "+feeReimbursementDTO.getEmployeeId()+" - "+empDetails.getEmployeeName());
			break;
		case "Recommend":
			entity.setNotification("Tution Fee Claim Recommended : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(""+feeReimbursementDTO.getClaimsSrNumber());
			break;
		case "Accept":
			entity.setEmployeeId(feeReimbursementDTO.getEmployeeId());
			entity.setNotification("Tution Fee Claim Accepted : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(""+feeReimbursementDTO.getClaimsSrNumber());
			break;
		case "Reject":
			entity.setEmployeeId(feeReimbursementDTO.getEmployeeId());
			entity.setNotification("Tution Fee Claim Rejected : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(""+feeReimbursementDTO.getClaimsSrNumber());
			break;
		}
		return entity;
	}
	/**
	 * updateApplicationEntity updates Application Entity using FeeReimbursementDTO
	 * 
	 * @param FeeReimbursementDTO
	 * @param entity
	 * @return
	 */
	private ApplicationEntity updateApplicationEntity(FeeReimbursementDTO feeReimbursementDTO, ApplicationEntity entity) {
		entity.setEmployeeId(feeReimbursementDTO.getEmployeeId());
		entity.setAppType("Tution Fee");
		entity.setRequestedDate(new Date());
		switch (feeReimbursementDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(getMaxDocumentNo()+1);
			entity.setAppStatus("Applied");
			break;
		case "Recommend":
			entity.setAppStatus("Recommended");
			break;
		case "Accept":
			entity.setAppStatus("Accepted");
			break;
		case "Reject":
			entity.setAppStatus("Rejected");
			break;
		}
		return entity;
	}
	/**
	 * getMaxDocumentNo is a temporary method which is used to generate documentNumber.
	 *
	 */
	public int getMaxDocumentNo() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "SELECT COALESCE(MAX(metaInfo),100) FROM ApplicationEntity";
		int maxNumber = (int) entityManager.createQuery(query).getResultList().get(0);
		entityManager.clear();
		entityManager.close();
		return maxNumber;

	}
	/**
	 *getDependentDetails is responsible to get the list of dependent details based on employeeId
	 *
	 *@param employeeId
	 */
	public List<DependentDetailsEntity> getDependentDetails(String employeeId){
		return	userInfoRepository.getDependentDetails(employeeId);

	}
	/**
	 *getClaimDetails is invoked to get the claim details based on claims Serial No.
	 *
	 *@param claimsSrNumber
	 */
	@Override
	public FeeReimbursementDTO getClaimDetails(String claimsSrNumber) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		int claimssrNumber = Integer.parseInt(claimsSrNumber); 
		String query = "FROM PrsnlSchlTutionFeeDetailsEntity where CLAIM_SRNO ="+claimssrNumber;
		PrsnlSchlTutionFeeDetailsEntity prsnlSchlTutionFeeDetailsEntity = (PrsnlSchlTutionFeeDetailsEntity)entityManager.createQuery(query).getResultList().get(0);
		String query2 = "FROM DependentDetailsEntity where PERSONAL_NO='"+prsnlSchlTutionFeeDetailsEntity.getEmployeeId()+"' and DEPENDENT_SNO ="+prsnlSchlTutionFeeDetailsEntity.getDependentSerialNo();
		DependentDetailsEntity dependentDetailsEntity = (DependentDetailsEntity)entityManager.createQuery(query2).getResultList().get(0);
		FeeReimbursementDTO response = new FeeReimbursementDTO();
		if(null != prsnlSchlTutionFeeDetailsEntity) {
			UserEntity empDetails = userInfoRepository.getEmployeeDetails(prsnlSchlTutionFeeDetailsEntity.getEmployeeId());
			response.setClaimedAmount(prsnlSchlTutionFeeDetailsEntity.getClaimedAmount());
			response.setClaimsSrNumber(prsnlSchlTutionFeeDetailsEntity.getClaimSerialNo());
			response.setClaimYear(prsnlSchlTutionFeeDetailsEntity.getClaimYear());
			response.setDependentSerialNo(prsnlSchlTutionFeeDetailsEntity.getDependentSerialNo());
			response.setEmployeeName(empDetails.getEmployeeName());
			response.setEmployeeId(prsnlSchlTutionFeeDetailsEntity.getEmployeeId());
			response.setFeePaid(prsnlSchlTutionFeeDetailsEntity.getFeePaid());
			response.setDependentName(dependentDetailsEntity.getName());
			response.setStatus(prsnlSchlTutionFeeDetailsEntity.getStatus());
			entityManager.clear();
			entityManager.close();
		}
		return response;
	}

}
