package com.omifco.repository.impl;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.omifco.compositeids.MedBillReimbId;
import com.omifco.compositeids.WorkflowLeaveHeaderId;
import com.omifco.dto.MedBillReimbDTO;
import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.MedBillReimbDetailsEntity;
import com.omifco.entity.MedBillReimbHeaderEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.entity.UserEntity;
import com.omifco.entity.WorkflowMedBillReimbDetailsEntity;
import com.omifco.entity.WorkflowMedBillReimbHeaderEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.MedBillReimbRepository;
import com.omifco.repository.UserInfoRepository;

@Repository
public class MedBillReimbRepositoryImpl implements MedBillReimbRepository, MessageConstants {

	/**
	 * EntityManager instance is injected by Spring Framework.
	 * 
	 * This is used to manage all the Persistent entities defined in the System.
	 */
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	private UserInfoRepository userInfoRepository;

	private final int UNIT_CODE = 1010;
	private final int DOC_CODE = 1;
	private final double ADMISSIBLE_AMOUNT = 100000.00;

	@Override
	public void insertMedBillReimbursementDetails(MedBillReimbDTO medBillReimbDTO) {
		// TODO Auto-generated method stub
		boolean hasValidAmount = checkClaimedAmount(medBillReimbDTO);
		if (hasValidAmount) {

			EntityManager entityManager = entityManagerFactory.createEntityManager();

			WorkflowMedBillReimbHeaderEntity workflowMedBillReimbHeaderEntity = new WorkflowMedBillReimbHeaderEntity();
			workflowMedBillReimbHeaderEntity = updateWorkflowMedBillReimbHeaderEntity(medBillReimbDTO, workflowMedBillReimbHeaderEntity);

			MedBillReimbHeaderEntity medBillReimbHeaderEntity = new MedBillReimbHeaderEntity();
			medBillReimbHeaderEntity = updateMedBillReimbHeaderEntity(medBillReimbDTO, medBillReimbHeaderEntity);

			WorkflowMedBillReimbDetailsEntity workflowMedBillReimbDetailsEntity = new WorkflowMedBillReimbDetailsEntity();
			workflowMedBillReimbDetailsEntity = updateWorkflowMedBillReimbDetailsEntity(medBillReimbDTO, workflowMedBillReimbDetailsEntity);

			MedBillReimbDetailsEntity medBillReimbDetailsEntity = new MedBillReimbDetailsEntity();
			medBillReimbDetailsEntity = updateMedBillReimbDetailsEntity(medBillReimbDTO, medBillReimbDetailsEntity);

			NotificationEntity notificationEntity = new NotificationEntity();
			notificationEntity = updateNotificationEntity(medBillReimbDTO, notificationEntity);
			ApplicationEntity applicationEntity = new ApplicationEntity();
			applicationEntity = updateApplicationEntity(medBillReimbDTO, applicationEntity);

			EntityTransaction entityTransaction = entityManager.getTransaction();
			try {
				// Start of transaction
				entityTransaction.begin();
				// persist method is used to do insertion of entities into their
				// DB table.
				entityManager.persist(workflowMedBillReimbHeaderEntity);
				entityManager.persist(medBillReimbHeaderEntity);
				entityManager.persist(workflowMedBillReimbDetailsEntity);
				entityManager.persist(medBillReimbDetailsEntity);
				entityManager.persist(notificationEntity);
				entityManager.persist(applicationEntity);

				// commit will actually make this transaction persist in DB.
				entityTransaction.commit();

			} catch (RuntimeException e) {
				if (entityTransaction.isActive()) {
					entityTransaction.rollback();
				}
				e.printStackTrace();
				throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
			} finally {
				entityManager.clear();
				entityManager.close();
			}
		}
	}

	@Override
	public void updateMedBillReimbursementDetails(MedBillReimbDTO medBillReimbDTO) {
		// TODO Auto-generated method stub
		String notificationQuery;
		if(medBillReimbDTO.getOperation().equals("Cancel")) {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Medical Bill Reimbursement' and META_INFO = "+medBillReimbDTO.getDocumentSerialNo();
		}else {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Medical Bill Reimbursement' and META_INFO = "+medBillReimbDTO.getDocumentSerialNo()+" and EMPLOYEE_ID='"+medBillReimbDTO.getRequestorId()+"'";
		}
		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Medical Bill Reimbursement' and META_INFO = "+medBillReimbDTO.getDocumentSerialNo();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		
		try{
			entityTransaction.begin();
			
			WorkflowLeaveHeaderId workflowLeaveHeaderId = new WorkflowLeaveHeaderId(UNIT_CODE,DOC_CODE,medBillReimbDTO.getDocumentSerialNo());
			MedBillReimbId medBillReimbId = new MedBillReimbId(UNIT_CODE, medBillReimbDTO.getDocumentSerialNo());
			
			WorkflowMedBillReimbHeaderEntity workflowMedBillReimbHeaderEntity = entityManager.find(WorkflowMedBillReimbHeaderEntity.class, workflowLeaveHeaderId);
			workflowMedBillReimbHeaderEntity = updateWorkflowMedBillReimbHeaderEntity(medBillReimbDTO , workflowMedBillReimbHeaderEntity);
			
			MedBillReimbHeaderEntity medBillReimbHeaderEntity = entityManager.find(MedBillReimbHeaderEntity.class, medBillReimbId);
			medBillReimbHeaderEntity = updateMedBillReimbHeaderEntity(medBillReimbDTO, medBillReimbHeaderEntity);
			
			WorkflowMedBillReimbDetailsEntity workflowMedBillReimbDetailsEntity = entityManager.find(WorkflowMedBillReimbDetailsEntity.class, workflowLeaveHeaderId);
			workflowMedBillReimbDetailsEntity = updateWorkflowMedBillReimbDetailsEntity(medBillReimbDTO , workflowMedBillReimbDetailsEntity);
			
			MedBillReimbDetailsEntity medBillReimbDetailsEntity = entityManager.find(MedBillReimbDetailsEntity.class, medBillReimbId);
			medBillReimbDetailsEntity = updateMedBillReimbDetailsEntity(medBillReimbDTO, medBillReimbDetailsEntity);
			
			NotificationEntity notificationEntityUpdate = (NotificationEntity) entityManager.createQuery(notificationQuery).getResultList().get(0);
			notificationEntityUpdate.setActionTaken(true);

			NotificationEntity notificationEntityInsert = new NotificationEntity();
			notificationEntityInsert = updateNotificationEntity(medBillReimbDTO, notificationEntityInsert);
			
			ApplicationEntity applicationEntityUpdate = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
			applicationEntityUpdate = updateApplicationEntity(medBillReimbDTO,applicationEntityUpdate);
			
			entityManager.persist(workflowMedBillReimbHeaderEntity);
			entityManager.persist(medBillReimbHeaderEntity);
			entityManager.persist(workflowMedBillReimbDetailsEntity);
			entityManager.persist(medBillReimbDetailsEntity);
			entityManager.merge(notificationEntityUpdate);
			entityManager.persist(notificationEntityInsert);
			entityManager.persist(applicationEntityUpdate);
			
			entityTransaction.commit();
		}catch(RuntimeException e){
			if(entityTransaction.isActive()){
				entityTransaction.rollback();
			}
			e.printStackTrace();
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		}finally{
			entityManager.clear();
			entityManager.close();
		}
		
		
	}

	@Override
	public MedBillReimbDTO getMedBillReimbursementDetails(String identifier) {
		// TODO Auto-generated method stub
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Medical Bill Reimbursement' and META_INFO = "+identifier;
		ApplicationEntity getApplicatioDetails = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
		MedBillReimbDTO medBillReimbDTO = new MedBillReimbDTO();
				
		
		WorkflowLeaveHeaderId workflowLeaveHeaderId = new WorkflowLeaveHeaderId(UNIT_CODE,DOC_CODE,Integer.parseInt(identifier));
		MedBillReimbId medBillReimbId =new MedBillReimbId(UNIT_CODE,Integer.parseInt(identifier));
		
		WorkflowMedBillReimbHeaderEntity workflowMedBillReimbHeaderEntity = entityManager.find(WorkflowMedBillReimbHeaderEntity.class, workflowLeaveHeaderId);
		WorkflowMedBillReimbDetailsEntity workflowMedBillReimbDetailsEntity = entityManager.find(WorkflowMedBillReimbDetailsEntity.class, workflowLeaveHeaderId);
		MedBillReimbHeaderEntity medBillReimbHeaderEntity =entityManager.find(MedBillReimbHeaderEntity.class, medBillReimbId);
		
		medBillReimbDTO.setDocumentSerialNo(Integer.parseInt(identifier));
		medBillReimbDTO.setEmployeeId(medBillReimbHeaderEntity.getEmployeeId());
		medBillReimbDTO.setBillType(workflowMedBillReimbHeaderEntity.getBillType());
		medBillReimbDTO.setSanctionNo(workflowMedBillReimbHeaderEntity.getSanctionNo());
		medBillReimbDTO.setDirPayToHosp(workflowMedBillReimbHeaderEntity.isDirPayToHosp());
		medBillReimbDTO.setDependentSerialNo(workflowMedBillReimbDetailsEntity.getDependentSerialNo());
		medBillReimbDTO.setHospitalCode(workflowMedBillReimbHeaderEntity.getHospitalCode());
		medBillReimbDTO.setReceiptNo(workflowMedBillReimbDetailsEntity.getReceiptNo());
		medBillReimbDTO.setReceiptDate(workflowMedBillReimbDetailsEntity.getReceiptDate());
		medBillReimbDTO.setClaimedAmount(workflowMedBillReimbHeaderEntity.getClaimedAmount());
		medBillReimbDTO.setCurrencyCode(workflowMedBillReimbHeaderEntity.getCurrencyCode());
		medBillReimbDTO.setCurrencyRate(workflowMedBillReimbHeaderEntity.getCurrencyRate());
		medBillReimbDTO.setApprovedAmount(workflowMedBillReimbHeaderEntity.getApprovedAmount());
		medBillReimbDTO.setReimbType(workflowMedBillReimbDetailsEntity.getReimbType());
		
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(medBillReimbDTO.getEmployeeId());
		medBillReimbDTO.setEmployeeName(empDetails.getEmployeeName());
		
		switch(getApplicatioDetails.getAppStatus()){
		
		case "Applied":
			medBillReimbDTO.setStatus("P");
			break;
		case "Recommended":
			medBillReimbDTO.setStatus("R");
			break;
		case "Approved":
			medBillReimbDTO.setStatus("A");
			break;
		case "SentToFinance":
			medBillReimbDTO.setStatus("C");
			break;	
		case "Rejected":
			medBillReimbDTO.setStatus("T");
			break;		
		}
		return medBillReimbDTO;
	}

	@Override
	public double getByAdmissibleAmountEmployeeId(String employeeId) {
		// TODO Auto-generated method stub
		return ADMISSIBLE_AMOUNT;
	}

	private boolean checkClaimedAmount(MedBillReimbDTO medBillReimbDTO) {
		if (medBillReimbDTO.getClaimedAmount() <= ADMISSIBLE_AMOUNT)
			return true;
		else {
			throw new OMIFCOBusinessException(MED_BILL_REIMB_AMOUNT_ERROR_CODE, MED_BILL_REIMB_AMOUNT_ERROR_MSG);
		}
	}

	private WorkflowMedBillReimbHeaderEntity updateWorkflowMedBillReimbHeaderEntity(MedBillReimbDTO medBillReimbDTO,
			WorkflowMedBillReimbHeaderEntity entity) {
		
		switch(medBillReimbDTO.getOperation()){
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentCode(DOC_CODE);
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
			entity.setApplicationType("N");
			entity.setBillType(medBillReimbDTO.getBillType());
			entity.setDirPayToHosp(medBillReimbDTO.isDirPayToHosp());
			entity.setHospitalCode(medBillReimbDTO.getHospitalCode());
			entity.setClaimedAmount(medBillReimbDTO.getClaimedAmount());
			entity.setAdmissibleAmount(ADMISSIBLE_AMOUNT);
			entity.setCurrencyCode(medBillReimbDTO.getCurrencyCode());					
			break;
		case "Approve":
			entity.setApprovedAmount(medBillReimbDTO.getApprovedAmount());
			break;
		case "SendToFinance":
			entity.setSanctionNo(medBillReimbDTO.getSanctionNo());			
			entity.setCurrencyRate(medBillReimbDTO.getCurrencyRate());
			entity.setApplicationType("C");
			break;
		case "Reject":
			entity.setApplicationType("T");
			break;
		}
		return entity;
	}

	private MedBillReimbHeaderEntity updateMedBillReimbHeaderEntity(MedBillReimbDTO medBillReimbDTO,
			MedBillReimbHeaderEntity entity) {
		
		switch(medBillReimbDTO.getOperation()){
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setBillSerialNo(getMaxDocumentNo()+1);
			entity.setClaimDate(new Date());
			entity.setEmployeeId(medBillReimbDTO.getEmployeeId());
			entity.setBillType(medBillReimbDTO.getBillType());
			entity.setDirPayToHosp(medBillReimbDTO.isDirPayToHosp());
			entity.setHospitalCode(medBillReimbDTO.getHospitalCode());
			entity.setClaimedAmount(medBillReimbDTO.getClaimedAmount());
			entity.setAdmissibleAmount(ADMISSIBLE_AMOUNT);
			entity.setCurrencyCode(medBillReimbDTO.getCurrencyCode());	
			entity.setCreatedBy(medBillReimbDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			break;
		case "Recommend":
			entity.setRecommendBy(medBillReimbDTO.getRequestorId());
			entity.setRecommendDate(new Date());
			break;
		case "Approve":
			entity.setApprovedAmount(medBillReimbDTO.getApprovedAmount());
			entity.setApprovedBy(medBillReimbDTO.getRequestorId());
			entity.setApprovedDate(new Date());
			entity.setSendToFinance(true);
			entity.setSentToFinDate(new Date());
			break;
		case "SendToFinance":
			entity.setFinReceiveDate(new Date());
			entity.setSanctionNo(medBillReimbDTO.getSanctionNo());
			entity.setCurrencyRate(medBillReimbDTO.getCurrencyRate());
			entity.setPayReleaseDate(new Date());
			break;
//		case "Reject":
//			break;
		}
		return entity;
	}

	private WorkflowMedBillReimbDetailsEntity updateWorkflowMedBillReimbDetailsEntity(MedBillReimbDTO medBillReimbDTO,
			WorkflowMedBillReimbDetailsEntity entity) {
		switch(medBillReimbDTO.getOperation()){
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentCode(DOC_CODE);
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
			entity.setBillDetailSerialNo(getMaxDocumentNo()+1);
			entity.setDependentSerialNo(medBillReimbDTO.getDependentSerialNo());
			entity.setReceiptNo(medBillReimbDTO.getReceiptNo());
			entity.setReceiptDate(medBillReimbDTO.getReceiptDate());
			entity.setClaimAmount(medBillReimbDTO.getClaimedAmount());
			entity.setAdmissibleAmount(ADMISSIBLE_AMOUNT);		
			break;
		case "SendToFinance":
			entity.setReimbType(medBillReimbDTO.getReimbType());
			break;
//		case "Reject":
//			break;
		}
		return entity;
	}

	private MedBillReimbDetailsEntity updateMedBillReimbDetailsEntity(MedBillReimbDTO medBillReimbDTO,
			MedBillReimbDetailsEntity entity) {
		switch(medBillReimbDTO.getOperation()){
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setBillSerialNo(getMaxDocumentNo()+1);
			entity.setBillDetailSerialNo(getMaxDocumentNo()+1);
			entity.setDependentSerialNo(medBillReimbDTO.getDependentSerialNo());
			entity.setReceiptNo(medBillReimbDTO.getReceiptNo());
			entity.setReceiptDate(medBillReimbDTO.getReceiptDate());
			entity.setClaimAmount(medBillReimbDTO.getClaimedAmount());
			entity.setAdmissibleAmount(ADMISSIBLE_AMOUNT);		
			entity.setCreatedBy(medBillReimbDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			break;
//		case "Recommend":
//			break;
//		case "Approve":
//			break;
		case "SendToFinance":
			entity.setReimbType(medBillReimbDTO.getReimbType());
			break;
//		case "Reject":
//			break;
		}
		
		return entity;
	}

	/**
	 * updateNotificationEntity updates NotificationEntity using medBillReimbDTO
	 * 
	 * @param medBillReimbDTO
	 * @param entity
	 * @return
	 */
	private NotificationEntity updateNotificationEntity(MedBillReimbDTO medBillReimbDTO, NotificationEntity entity) {
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(medBillReimbDTO.getEmployeeId());
		entity.setActionTaken(false);
		entity.setEmployeeId(medBillReimbDTO.getSendTo());
		entity.setNotificationDate(new Date());
		entity.setAppType("Medical Bill Reimbursement");
		entity.setDeleted(false);
		switch (medBillReimbDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(Integer.toString(getMaxDocumentNo() + 1));
			entity.setNotification("Medical Bill Reimbursement Request : " + medBillReimbDTO.getEmployeeId() + " - "+ empDetails.getEmployeeName());
			break;
		case "Recommend":
			entity.setNotification("Medical Bill Reimbursement Recommended : Requested by " + empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(medBillReimbDTO.getDocumentSerialNo()));
			break;
		case "Approve":
			entity.setNotification("Medical Bill Reimbursement approved : Requested by " + empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(medBillReimbDTO.getDocumentSerialNo()));
			break;
		case "SendToFinance":
			entity.setEmployeeId(medBillReimbDTO.getEmployeeId());
			entity.setNotification("Medical Bill Reimbursement Sent To Finance : Requested by " + empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(medBillReimbDTO.getDocumentSerialNo()));
			break;
		case "Reject":
			entity.setEmployeeId(medBillReimbDTO.getEmployeeId());
			entity.setNotification("Medical Bill Reimbursement Rejected : Requested by " + empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(medBillReimbDTO.getDocumentSerialNo()));
			break;
		}
		return entity;
	}

	/**
	 * updateApplicationEntity updates Application Entity using medBillReimbDTO
	 * 
	 * @param medBillReimbDTO
	 * @param entity
	 * @return
	 */
	private ApplicationEntity updateApplicationEntity(MedBillReimbDTO medBillReimbDTO, ApplicationEntity entity) {
		entity.setEmployeeId(medBillReimbDTO.getEmployeeId());
		entity.setAppType("Medical Bill Reimbursement");
		entity.setRequestedDate(new Date());
		switch (medBillReimbDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(getMaxDocumentNo() + 1);
			entity.setAppStatus("Applied");
			break;
		case "Recommend":
			entity.setAppStatus("Recommended");
			break;
		case "Approve":
			entity.setAppStatus("SentToFinance");
			break;
		case "SendToFinance":
			entity.setAppStatus("Finance Accepted");
			break;
		case "Reject":
			entity.setAppStatus("Rejected");
			break;
		}
		return entity;
	}

	/**
	 * getMaxDocumentNo is a temporary method which is used to generate
	 * documentNumber.
	 *
	 */
	public int getMaxDocumentNo() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "SELECT COALESCE(MAX(metaInfo),100) FROM ApplicationEntity";
		int maxNumber = (int) entityManager.createQuery(query).getResultList().get(0);
		entityManager.clear();
		entityManager.close();

		return maxNumber;
	}
}
