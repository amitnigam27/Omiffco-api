package com.omifco.repository.impl;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.omifco.compositeids.TimeLeaveDetailsId;
import com.omifco.compositeids.TimeLeaveHeaderId;
import com.omifco.dto.LeaveDTO;
import com.omifco.dto.LeaveSummaryDTO;
import com.omifco.dto.RemarksDTO;
import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.LeaveBalanceSummaryEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.entity.TimeLeaveDetailsEntity;
import com.omifco.entity.TimeLeaveHeaderEntity;
import com.omifco.entity.UserEntity;
import com.omifco.entity.WorkflowLeaveDetailsEntity;
import com.omifco.entity.WorkflowLeaveHeaderEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.LeaveApplicationRepository;
import com.omifco.repository.UserInfoRepository;

/**
 * UtilRepositoryImpl : Implementation class of UtilRepository.
 * 
 * @author Prolifics
 *
 */
@Repository
public class LeaveApplicationRepositoryImpl implements LeaveApplicationRepository, MessageConstants {
	
	/**
	 * EntityManager instance is injected by Spring Framework.
	 * 
	 * This is used to manage all the Persistent entities
	 * defined in the System.
	 */
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	
	@Autowired
	private UserInfoRepository userInfoRepository;
	
	private final int UNIT_CODE = 1010;
	private final int DOC_CODE = 1;
	
	/**
	 *insertLeaveDetails is responsible to insert the leave data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolledback.
	 *
	 *@param leaveDTO
	 */
	@Override
	public void insertLeaveDetails(LeaveDTO leaveDTO) {
		boolean hasSufficientBalance = checkLeaveBalance(leaveDTO);
		//proceed further to apply leave only if employee has sufficient balance.
		if(hasSufficientBalance) {
			//updating respective entity objects to insert data to their respective tables using LeaveDTO
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			WorkflowLeaveHeaderEntity leaveHeaderEntity = new WorkflowLeaveHeaderEntity();
			leaveHeaderEntity = updateWorkflowLeaveHeaderEntity(leaveDTO,leaveHeaderEntity);
			WorkflowLeaveDetailsEntity leaveDetailsEntity = new WorkflowLeaveDetailsEntity(); 
			leaveDetailsEntity = updateWorkflowLeaveDetailsEntity(leaveDTO,leaveDetailsEntity);
			TimeLeaveHeaderEntity timeLeaveHeaderEntity = new TimeLeaveHeaderEntity(); 
			timeLeaveHeaderEntity = updateTimeLeaveHeaderEntity(leaveDTO,timeLeaveHeaderEntity);
			TimeLeaveDetailsEntity timeLeaveDetailsEntity = new TimeLeaveDetailsEntity();
			timeLeaveDetailsEntity = updateTimeLeaveDetailsEntity(leaveDTO,timeLeaveDetailsEntity);
			NotificationEntity notificationEntity = new NotificationEntity();
			notificationEntity = updateNotificationEntity(leaveDTO,notificationEntity);
			ApplicationEntity applicationEntity = new ApplicationEntity(); 
			applicationEntity = updateApplicationEntity(leaveDTO,applicationEntity);
			//Query to get leave balance so that as soon as employee apply a leave his balance gets deducted.
			String leaveBalanceQuery = "FROM LeaveBalanceSummaryEntity where LV_TYPE_CODE = '"+leaveDTO.getLeaveType()
			+"' and PERSONAL_NO ='"+leaveDTO.getEmployeeId()+"' and LV_PAY_FLAG="+leaveDTO.getLeaveFlag();
			EntityTransaction entityTransaction = entityManager.getTransaction();
			try {
				//Start of transaction
				entityTransaction.begin();
				LeaveBalanceSummaryEntity leaveBalanceEntity = (LeaveBalanceSummaryEntity) entityManager.createQuery(leaveBalanceQuery).getResultList().get(0);
				int leaveDays = calculateNoOfDays(leaveDTO.getFromDate(), leaveDTO.getToDate());
				leaveBalanceEntity.setBalanceDays(leaveBalanceEntity.getBalanceDays()-leaveDays);
				leaveBalanceEntity.setModifiedBy(leaveDTO.getEmployeeId());
				leaveBalanceEntity.setDateOfModification(new Date());
				//persist method is used to do insertion of entities into their DB table.
				entityManager.persist(leaveHeaderEntity);
				entityManager.persist(leaveDetailsEntity);
				entityManager.persist(timeLeaveHeaderEntity);
				entityManager.persist(timeLeaveDetailsEntity);
				entityManager.persist(notificationEntity);
				entityManager.persist(applicationEntity);
				//merge method is used to update entities into their DB table.
				entityManager.merge(leaveBalanceEntity);
				//commit will actually make this transaction persist in DB.
				entityTransaction.commit();
			} catch (RuntimeException e) {
			    if (entityTransaction.isActive()) {
			        entityTransaction.rollback();
			    }
			    e.printStackTrace();
			    throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG,SOMETHING_WENT_WRONG_MSG);
			} finally {
				entityManager.clear();
			    entityManager.close();
			}
		}else {
			throw new OMIFCOBusinessException(INSUFFICENT_LEAVE_CODE,INSUFFICENT_LEAVE_MSG);
		}
		
	}

	/**
	 *updateLeaveDetails is responsible to update the leave data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolled back.
	 *
	 *@param leaveDTO
	 */
	@Override
	public void updateLeaveDetails(LeaveDTO leaveDTO) {
		TimeLeaveHeaderId timLeaveHdrId = new TimeLeaveHeaderId(UNIT_CODE,Integer.parseInt(leaveDTO.getDocNumber()));
		TimeLeaveDetailsId timLeaveDtlsId = new TimeLeaveDetailsId(UNIT_CODE,Integer.parseInt(leaveDTO.getDocNumber()));
		String notificationQuery;
		if(leaveDTO.getOperation().equals("Cancel")) {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Leave Application' and META_INFO = '"+leaveDTO.getDocNumber()+"'";
		}else {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Leave Application' and META_INFO = '"+leaveDTO.getDocNumber()+"' and EMPLOYEE_ID='"+leaveDTO.getRequestorId()+"'";
		}

		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Leave Application' and META_INFO = '"+leaveDTO.getDocNumber()+"'";
		
		String leaveBalanceQuery = "FROM LeaveBalanceSummaryEntity where LV_TYPE_CODE = '"+leaveDTO.getLeaveType()
		+"' and PERSONAL_NO ='"+leaveDTO.getEmployeeId()+"' and LV_PAY_FLAG="+leaveDTO.getLeaveFlag();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		try {
			//Start of transaction
			entityTransaction.begin();
			//updating respective entity objects to insert data to their respective tables using LeaveDTO
			TimeLeaveHeaderEntity timeLeaveHeaderEntity = entityManager.find(TimeLeaveHeaderEntity.class,timLeaveHdrId);
			timeLeaveHeaderEntity = updateTimeLeaveHeaderEntity(leaveDTO,timeLeaveHeaderEntity);
			timeLeaveHeaderEntity.setUnitCode(UNIT_CODE);
			TimeLeaveDetailsEntity leaveDetailsEntity = entityManager.find(TimeLeaveDetailsEntity.class,timLeaveDtlsId);
			leaveDetailsEntity = updateTimeLeaveDetailsEntity(leaveDTO,leaveDetailsEntity);
			leaveDetailsEntity.setUnitCode(UNIT_CODE);
			NotificationEntity notificationEntityUpdate = (NotificationEntity) entityManager.createQuery(notificationQuery).getResultList().get(0);
			notificationEntityUpdate = updateNotificationEntity(leaveDTO,notificationEntityUpdate);
			NotificationEntity notificationEntityInsert = new NotificationEntity();
			//In case of withdrawing leave, no need to send any notification to anyone.
			if(!leaveDTO.getOperation().equals("Cancel")) {
				notificationEntityInsert = updateNotificationEntity(leaveDTO,notificationEntityInsert);
				//Overriding empId and actionTaken
				notificationEntityUpdate.setEmployeeId(leaveDTO.getRequestorId());
				notificationEntityInsert.setActionTaken(false);
			}
			notificationEntityUpdate.setActionTaken(true);
			ApplicationEntity applicationEntityUpdate = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
			applicationEntityUpdate = updateApplicationEntity(leaveDTO,applicationEntityUpdate);
			//If leave gets rejected or employee withdraws it, increase his/her leave balance by same amount.
			if(leaveDTO.getOperation().equals("Cancel") || leaveDTO.getOperation().equals("Reject")) {
				LeaveBalanceSummaryEntity leaveBalanceEntity = (LeaveBalanceSummaryEntity) entityManager.createQuery(leaveBalanceQuery).getResultList().get(0);
				int leaveDays = calculateNoOfDays(leaveDTO.getFromDate(), leaveDTO.getToDate());
				leaveBalanceEntity.setBalanceDays(leaveBalanceEntity.getBalanceDays()+leaveDays);
				entityManager.merge(leaveBalanceEntity);
			}
			entityManager.merge(timeLeaveHeaderEntity);
			entityManager.merge(leaveDetailsEntity);
			entityManager.merge(notificationEntityUpdate);
			if(!leaveDTO.getOperation().equals("Cancel")) {
				entityManager.persist(notificationEntityInsert);	
			}
			entityManager.merge(applicationEntityUpdate);
			entityTransaction.commit();
			//END of transaction
		} catch (RuntimeException e) {
		    if (entityTransaction.isActive()) {
		        entityTransaction.rollback();
		    }
		    e.printStackTrace();
		    throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		} finally {
			entityManager.clear();
		    entityManager.close();
		}
	}

	/**
	 * checkLeaveBalance is responsible to check if an employee has sufficient
	 * leave balance or not and thereby returns boolean value based on it.
	 * 
	 * @param leaveDTO
	 * @return
	 */
	private boolean checkLeaveBalance(LeaveDTO leaveDTO) {
		LeaveSummaryDTO leaveBalanceInfo = getLeaveBalanceSummaryById(leaveDTO.getEmployeeId());
		int leaveDays = calculateNoOfDays(leaveDTO.getFromDate(),leaveDTO.getToDate());
		if(leaveBalanceInfo.getTotalLeaveBalance() >= leaveDays) {
			String leaveType = leaveDTO.getLeaveType();
			switch (leaveType) {
			case "AL":
				if(leaveBalanceInfo.getAnnualLeaves() >= leaveDays) {
					return true;
				}else {
					throw new OMIFCOBusinessException(INSUFFICENT_ANNUAL_LEAVE_CODE,INSUFFICENT_ANNUAL_LEAVE_MSG);
				}
			case "SL":
				if(leaveBalanceInfo.getSickLeaves() >= leaveDays) {
					return true;
				}else {
					throw new OMIFCOBusinessException(INSUFFICENT_SICK_LEAVE_CODE,INSUFFICENT_SICK_LEAVE_MSG);
				}
			case "EL":
				if(leaveBalanceInfo.getEmergencyLeaves()>= leaveDays && leaveDays <= 2) {
					return true;
				}else if(leaveDays > 2) {
					//throw an exception if employee tries to apply emergency leave more than 2 days.
					throw new OMIFCOBusinessException(EMERGENCY_LEAVE_LIMIT_CODE,EMERGENCY_LEAVE_LIMIT_MSG);
				}else{
					//throw an exception if employee has insufficient balance.
					throw new OMIFCOBusinessException(INSUFFICENT_EMERGENCY_LEAVE_CODE,INSUFFICENT_EMERGENCY_LEAVE_MSG);
				}
			}
		}
		return false;
	}
	
	/**
	 * updateApplicationEntity updates Application Entity using LeaveDTO
	 * 
	 * @param leaveDTO
	 * @param entity
	 * @return
	 */
	private ApplicationEntity updateApplicationEntity(LeaveDTO leaveDTO,ApplicationEntity entity) {
		entity.setEmployeeId(leaveDTO.getEmployeeId());
		entity.setAppType("Leave Application");
		entity.setRequestedDate(new Date());
		switch (leaveDTO.getOperation()) {
		case "Apply":
			if(leaveDTO.getDocNumber()!=null && !leaveDTO.getDocNumber().isEmpty()) {
				entity.setMetaInfo(Integer.parseInt(leaveDTO.getDocNumber()));
			}else {
				entity.setMetaInfo(getMaxDocumentNo()+1);
			}
			
			entity.setAppStatus("Applied");
			break;
		case "Recommend":
			entity.setAppStatus("Recommended");
			break;
		case "Approve":
			entity.setAppStatus("Approved");
			break;
		case "Accept":
			entity.setEmployeeId(leaveDTO.getEmployeeId());
			entity.setAppStatus("Accepted");
			break;
		case "Cancel":
			entity.setEmployeeId(leaveDTO.getEmployeeId());
			entity.setAppStatus("Cancelled");
			break;
		case "Reject":
			entity.setEmployeeId(leaveDTO.getEmployeeId());
			entity.setAppStatus("Rejected");
			break;
		}
		return entity;
	}

	/**
	 * updateNotificationEntity updates NotificationEntity using LeaveDTO
	 * 
	 * @param leaveDTO
	 * @param entity
	 * @return
	 */
	private NotificationEntity updateNotificationEntity(LeaveDTO leaveDTO,NotificationEntity entity) {
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(leaveDTO.getEmployeeId());
		entity.setActionTaken(false);
		entity.setEmployeeId(leaveDTO.getSendTo());
		entity.setNotificationDate(new Date());
		entity.setDeleted(false);
		entity.setAppType("Leave Application");
		switch (leaveDTO.getOperation()) {
		case "Apply":
			if(leaveDTO.getDocNumber()!=null && !leaveDTO.getDocNumber().isEmpty()) {
				entity.setMetaInfo(leaveDTO.getDocNumber());
			}else {
				entity.setMetaInfo(Integer.toString(getMaxDocumentNo()+1));
			}
			entity.setNotification("Leave Application Recommendation Request : "+leaveDTO.getEmployeeId()+" - "+empDetails.getEmployeeName());
			break;
		case "Recommend":
			entity.setNotification("Leave Application Recommended : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(leaveDTO.getDocNumber());
			break;
		case "Approve":
			entity.setNotification("Leave Application Approved : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(leaveDTO.getDocNumber());
			break;
		case "Accept":
			entity.setEmployeeId(leaveDTO.getEmployeeId());
			entity.setNotification("Leave Application Accepted : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(leaveDTO.getDocNumber());
			break;
		case "Cancel":
			entity.setEmployeeId(leaveDTO.getEmployeeId());
			entity.setNotification("Your leave has been cancelled.");
			entity.setMetaInfo(leaveDTO.getDocNumber());
			break;
		case "Reject":
			entity.setEmployeeId(leaveDTO.getEmployeeId());
			entity.setNotification("Leave Application Rejected : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(leaveDTO.getDocNumber());
			break;
		}
		return entity;
	}

	/**
	 * updateTimeLeaveDetailsEntity updates TimeLeaveDetailsEntity using LeaveDTO
	 * 
	 * @param leaveDTO
	 * @param entity
	 * @return
	 */
	private TimeLeaveDetailsEntity updateTimeLeaveDetailsEntity(LeaveDTO leaveDTO,TimeLeaveDetailsEntity entity) {
		switch (leaveDTO.getOperation()) {
		case "Apply":
			entity.setCreatedBy(leaveDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			if(leaveDTO.getDocNumber()!=null && !leaveDTO.getDocNumber().isEmpty()) {
				entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			}else {
				entity.setDocumentNumber(getMaxDocumentNo()+1);
			}
			entity.setEmployeeId(leaveDTO.getEmployeeId());
			entity.setLeaveStatus("P");
			entity.setUnitCode(1010);
			int days = calculateNoOfDays(leaveDTO.getFromDate(),leaveDTO.getToDate());
			entity.setLeaveDays(days);
			entity.setLeavePayFlag(leaveDTO.getLeaveFlag());
			entity.setLeavePurposeCode(Integer.parseInt(leaveDTO.getLeavePurpose()));
			entity.setLeaveTypeCode(leaveDTO.getLeaveType());
			entity.setPeriodFrom(leaveDTO.getFromDate());
			entity.setPeriodTo(leaveDTO.getToDate());
			break;
		case "Recommend":
			entity.setLeaveStatus("R");
			entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setModifiedDate(new Date());
			break;
		case "Approve":
			entity.setLeaveStatus("A");
			entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setModifiedDate(new Date());
			break;
		case "Accept":
			entity.setLeaveStatus("C");
			entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setModifiedDate(new Date());
			break;
		case "Cancel":
			entity.setLeaveStatus("F");
			entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setModifiedDate(new Date());
			break;
		case "Reject":
			entity.setLeaveStatus("T");//Rejected - Terminated
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setModifiedDate(new Date());
			break;
		}
		return entity;
	}

	/**
	 * updateTimeLeaveHeaderEntity updates TimeLeaveHeaderEntity using LeaveDTO
	 * 
	 * @param leaveDTO
	 * @param entity
	 * @return
	 */
	private TimeLeaveHeaderEntity updateTimeLeaveHeaderEntity(LeaveDTO leaveDTO,TimeLeaveHeaderEntity entity) {
		UserEntity currentUserDetails = userInfoRepository.getEmployeeDetails(leaveDTO.getRequestorId());
		switch (leaveDTO.getOperation()) {
		case "Apply":
			entity.setApplicationDate(new Date());
			entity.setCreatedBy(leaveDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			if(leaveDTO.getDocNumber()!=null && !leaveDTO.getDocNumber().isEmpty()) {
				entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			}else {
				entity.setDocumentNumber(getMaxDocumentNo()+1);
			}
			entity.setEmployeeId(leaveDTO.getEmployeeId());
			entity.setLeaveStatus("P"); //In Progress
			entity.setUnitCode(UNIT_CODE);
			break;
		case "Recommend":
			entity.setRecommendBy(leaveDTO.getRequestorId());
			entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			entity.setRecommendDate(new Date());
			entity.setLeaveStatus("R");//Recommended
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setModifiedDate(new Date());
			System.out.println(leaveDTO.getRemarks());
			entity.setRemarks(currentUserDetails.getEmployeeName()+" - "+leaveDTO.getRemarks());
			break;
		case "Approve":
			entity.setApprovedBy(leaveDTO.getRequestorId());
			entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			entity.setApprovedDate(new Date());
			entity.setLeaveStatus("A");//Approved
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setModifiedDate(new Date());
			entity.setRemarks(entity.getRemarks()+":"+currentUserDetails.getEmployeeName()+" - "+leaveDTO.getRemarks());
			break;
		case "Accept":
			entity.setLeaveStatus("C");//Accepted - Completed
			entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setModifiedDate(new Date());
			entity.setRemarks(entity.getRemarks()+":"+currentUserDetails.getEmployeeName()+" - "+leaveDTO.getRemarks());
			break;
		case "Cancel":
			entity.setLeaveStatus("F");//Cancelled - Failed
			entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setModifiedDate(new Date());
			entity.setRemarks(entity.getRemarks()+":"+currentUserDetails.getEmployeeName()+" - "+leaveDTO.getRemarks());
			break;
		case "Reject":
			entity.setLeaveStatus("T");//Rejected - Terminated
			entity.setModifiedBy(leaveDTO.getRequestorId());
			entity.setDocumentNumber(Integer.parseInt(leaveDTO.getDocNumber()));
			entity.setModifiedDate(new Date());
			entity.setRemarks(entity.getRemarks()+":"+currentUserDetails.getEmployeeName()+" - "+leaveDTO.getRemarks());
			break;
		}

		return entity;
	}

	/**
	 * updateWorkflowLeaveDetailsEntity updates WorkflowLeaveDetailsEntity using LeaveDTO
	 * 
	 * @param leaveDTO
	 * @param entity
	 * @return
	 */
	private WorkflowLeaveDetailsEntity updateWorkflowLeaveDetailsEntity(LeaveDTO leaveDTO,WorkflowLeaveDetailsEntity entity) {
		entity.setAbsentDays(0);
		entity.setDocumentCode(DOC_CODE);
		if(leaveDTO.getDocNumber()!=null && !leaveDTO.getDocNumber().isEmpty()) {
			entity.setDocumentSerialNo(Integer.parseInt(leaveDTO.getDocNumber()));
		}else {
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
		}
		int days = calculateNoOfDays(leaveDTO.getFromDate(),leaveDTO.getToDate());
		entity.setLeaveDays(days);
		entity.setPeriodFrom(leaveDTO.getFromDate());
		entity.setPeriodTo(leaveDTO.getToDate());
		entity.setLeavePayFlag(leaveDTO.getLeaveFlag());
		entity.setLeavePurposeCode(Integer.parseInt(leaveDTO.getLeavePurpose()));
		entity.setLeaveTypeCode(leaveDTO.getLeaveType());
		entity.setUnitCode(UNIT_CODE);
		return entity;
	}
	
	/**
	 * calculateNoOfDays returns no of days for which employee is applying leave.
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public int calculateNoOfDays(Date fromDate, Date toDate) {
		LocalDate fromLocal = fromDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate toLocal = toDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int days = (int)ChronoUnit.DAYS.between(fromLocal, toLocal);
		//Incrementing difference by one to include endDate.
		days = days +1;
		return days;
	}

	/**
	 * updateWorkflowLeaveHeaderEntity updates WorkflowLeaveHeaderEntity using LeaveDTO
	 * 
	 * @param leaveDTO
	 * @param entity
	 * @return
	 */
	private WorkflowLeaveHeaderEntity updateWorkflowLeaveHeaderEntity(LeaveDTO leave,WorkflowLeaveHeaderEntity entity) {
		entity.setApplicationDate(new Date());
		entity.setApplicationType("N");
		entity.setDocumentCode(DOC_CODE);
		if(leave.getDocNumber()!=null && !leave.getDocNumber().isEmpty()) {
			entity.setDocumentSerialNo(Integer.parseInt(leave.getDocNumber()));
		}else {
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
		}
		entity.setEmployeeId(leave.getEmployeeId());
		entity.setUnitCode(UNIT_CODE);
		return entity;
	}

	/**
	 * getMaxDocumentNo is a temporary method which is used to generate documentNumber.
	 *
	 */
	@Override
	public int getMaxDocumentNo() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "SELECT COALESCE(MAX(metaInfo),100) FROM ApplicationEntity";
		int maxNumber = (int) entityManager.createQuery(query).getResultList().get(0);
		entityManager.clear();
		entityManager.close();
		return maxNumber;
		
	}

	/**
	 * getLeaveDetails returns the leave details based on document number 
	 * generated during the time of applying leave.
	 * 
	 *@param docNumber
	 */
	@Override
	public LeaveDTO getLeaveDetails(String docNumber) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String timeLeaveDetailquery = "FROM TimeLeaveDetailsEntity where UNIT_CODE = "+UNIT_CODE+" and DOCCUMENT_NO ="+docNumber;
		TimeLeaveDetailsEntity leaveDetailsEntity = (TimeLeaveDetailsEntity) entityManager.createQuery(timeLeaveDetailquery).getResultList().get(0);
		String timeLeaveHdrsquery = "FROM TimeLeaveHeaderEntity where UNIT_CODE = "+UNIT_CODE+" and DOCCUMENT_NO ="+docNumber;
		TimeLeaveHeaderEntity leaveHeaderEntity = (TimeLeaveHeaderEntity) entityManager.createQuery(timeLeaveHdrsquery).getResultList().get(0);
		LeaveDTO leaveDetails = new LeaveDTO();
		if(leaveDetailsEntity!= null) {
			leaveDetails.setDocNumber(Integer.toString(leaveDetailsEntity.getDocumentNumber()));
			UserEntity empDetails = userInfoRepository.getEmployeeDetails(leaveDetailsEntity.getEmployeeId());
			leaveDetails.setEmployeeId(leaveDetailsEntity.getEmployeeId());
			leaveDetails.setEmployeeName(empDetails.getEmployeeName());
			leaveDetails.setFromDate(leaveDetailsEntity.getPeriodFrom());
			leaveDetails.setToDate(leaveDetailsEntity.getPeriodTo());
			leaveDetails.setLeaveFlag(leaveDetailsEntity.getLeavePayFlag());
			leaveDetails.setLeavePurpose(Integer.toString(leaveDetailsEntity.getLeavePurposeCode()));
			leaveDetails.setLeaveType(leaveDetailsEntity.getLeaveTypeCode());
			leaveDetails.setLeaveStatus(leaveDetailsEntity.getLeaveStatus());
			List<RemarksDTO> listOfRemarks = new ArrayList<RemarksDTO>();
			String approverRemarks = leaveHeaderEntity.getRemarks();
			//Logic to distinguish remarks of all approvers.
			try {
				if(null!=approverRemarks && approverRemarks.contains(":")) {
					String[] remarksArray = approverRemarks.split(":");
					for (String remark : remarksArray) {
						if(remark.contains(" - ")) {
							RemarksDTO remarksDTO = new RemarksDTO();
							remarksDTO.setApproverName(remark.split(" - ",2)[0]);
							remarksDTO.setApproverRemarks(remark.split(" - ",2)[1]);
							listOfRemarks.add(remarksDTO);
						}
					}
				}else if(null!=approverRemarks && !approverRemarks.isEmpty()){
					if(approverRemarks.contains(" - ")) {
						RemarksDTO remarksDTO = new RemarksDTO();
						remarksDTO.setApproverName(approverRemarks.split(" - ",2)[0]);
						remarksDTO.setApproverRemarks(approverRemarks.split(" - ",2)[1]);
						listOfRemarks.add(remarksDTO);
					}
				}
				leaveDetails.setApproverRemarks(listOfRemarks);
			}catch(Exception e) {
				throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
			}
				
		}
		entityManager.clear();
		entityManager.close();
		return leaveDetails;
	}

	
	/**
	 *getLeaveAppDetails used to return application details based on appType and identifier
	 *
	 *@param applicationType
	 *@param identifier
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ApplicationEntity> getLeaveAppDetails(String applicationType, String identifier) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "FROM ApplicationEntity where APPLICATION_TYPE = '"+applicationType+"' and META_INFO = '"+identifier+"'";
		List<ApplicationEntity> leaveAppList =  entityManager.createQuery(query).getResultList();
		entityManager.clear();
		entityManager.close();
		return leaveAppList;
	}

	/**
	 * getLeaveBalanceSummaryById return leave summary - available leaves,
	 * pending leaves, approved leaves, leave balance for AL,SL,EL etc.
	 * 
	 * @return  leaveSummaryDTO
	 */
	@SuppressWarnings("unchecked")
	@Override
	public LeaveSummaryDTO getLeaveBalanceSummaryById(String employeeId) {
		LeaveSummaryDTO leaveSummaryDTO = new LeaveSummaryDTO();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "FROM LeaveBalanceSummaryEntity WHERE PERSONAL_NO = '"+employeeId+"'";
		String encashmentQuery = "Select COALESCE(SUM(daysEncashed), 0) FROM LeaveEncashmentEntity where PERSONAL_NO = '"+employeeId+"'";
		try {
			List<LeaveBalanceSummaryEntity> leaveBalanceSummary =  entityManager.createQuery(query).getResultList();
			double encashedDays = (double) entityManager.createQuery(encashmentQuery).getResultList().get(0);
			for (LeaveBalanceSummaryEntity leaveSummaryEntity : leaveBalanceSummary) {
				
				
				switch (leaveSummaryEntity.getLeaveTypeCode()) {
				case "AL":
					double annualLeaves = leaveSummaryDTO.getAnnualLeaves()+leaveSummaryEntity.getBalanceDays();
					leaveSummaryDTO.setAnnualLeaves(annualLeaves);
					
					//As of now we are considering only Annual leaves are encashable having pay flag as Full Pay(1).
					if(leaveSummaryEntity.getPayFlag() == 1) {
						leaveSummaryDTO.setNewEncashableLeaves(leaveSummaryEntity.getOpeningEncahableLeave());
						leaveSummaryDTO.setTotalAccruedLeaves(leaveSummaryEntity.getAccruedLeaves());
						double totalEncashableLeaves = leaveSummaryDTO.getNewEncashableLeaves()+leaveSummaryDTO.getTotalAccruedLeaves();
						leaveSummaryDTO.setEncashedDays(encashedDays);
						leaveSummaryDTO.setTotalEncashableLeaves(totalEncashableLeaves - encashedDays);
					}
					break;
				case "SL":
					double sickLeaves = leaveSummaryDTO.getSickLeaves()+leaveSummaryEntity.getBalanceDays();
					leaveSummaryDTO.setSickLeaves(sickLeaves);
					break;
				case "EL":
					double emergencyLeaves = leaveSummaryDTO.getEmergencyLeaves()+leaveSummaryEntity.getBalanceDays();
					leaveSummaryDTO.setEmergencyLeaves(emergencyLeaves);
					break;
				}
			}
			
			String pendingLeaves = "Select COALESCE(SUM(leaveDays), 0) FROM TimeLeaveDetailsEntity where PERSONAL_NO = '"+employeeId+"' and LEAVE_STATUS = 'P'";
			double noOfPendingLeaves = (double) entityManager.createQuery(pendingLeaves).getResultList().get(0);
			leaveSummaryDTO.setPendingLeaves(noOfPendingLeaves);
			
			String approvedLeaves = "Select COALESCE(SUM(leaveDays), 0) FROM TimeLeaveDetailsEntity where PERSONAL_NO = '"+employeeId+"' and LEAVE_STATUS = 'C'";
			double noOfApprovedLeaves = (double) entityManager.createQuery(approvedLeaves).getResultList().get(0);
			leaveSummaryDTO.setApprovedLeaves(noOfApprovedLeaves);
			
			double totalLeaveBalance = leaveSummaryDTO.getAnnualLeaves()+leaveSummaryDTO.getEmergencyLeaves()+leaveSummaryDTO.getSickLeaves();
			leaveSummaryDTO.setTotalLeaveBalance(totalLeaveBalance);	
		}catch(Exception e){
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		}finally {
			entityManager.clear();
			entityManager.close();
		}
		
		return leaveSummaryDTO;
	}
}
