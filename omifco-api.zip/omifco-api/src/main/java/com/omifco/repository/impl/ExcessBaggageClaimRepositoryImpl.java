package com.omifco.repository.impl;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.omifco.compositeids.BaggageClaimId;
import com.omifco.compositeids.TimeLeaveDetailsId;
import com.omifco.compositeids.WorkflowLeaveHeaderId;
import com.omifco.dto.AnnualTrvlAlwnceDTO;
import com.omifco.dto.ExcessBaggageClaimDTO;
import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.LeaveBalanceSummaryEntity;
import com.omifco.entity.LeaveEncashmentEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.entity.PrsnlExcessBaggageClaimDtlsEntity;
import com.omifco.entity.PrsnlExcessBaggageClaimHdrsEntity;
import com.omifco.entity.UserEntity;
import com.omifco.entity.WorkFlowExcessBaggageClaimHdrsEntity;
import com.omifco.entity.WorkFlowExcessBaggageClaimsDetailsEntity;
import com.omifco.entity.WorkflowPrsnlAnnualTrvlAlwnceEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.ExcessBaggageClaimRepository;
import com.omifco.repository.UserInfoRepository;

@Repository
public class ExcessBaggageClaimRepositoryImpl implements ExcessBaggageClaimRepository, MessageConstants {

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	@Autowired
	private UserInfoRepository userInfoRepository;
	private final int UNIT_CODE = 1010;
	private final int DOC_CODE = 1;
	
	
	
	
	@Override
	public void insertBaggageClaimDetails(ExcessBaggageClaimDTO excessBaggageClaimDTO){
		//boolean isValidAmount = checkClaimedAmount(excessBaggageClaimDTO);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		WorkFlowExcessBaggageClaimHdrsEntity workFlowExcessBaggageClaimHdrsEntity = new WorkFlowExcessBaggageClaimHdrsEntity();
		workFlowExcessBaggageClaimHdrsEntity = updateWorkFlowExcessBaggageClaimHdrsEntity(excessBaggageClaimDTO, workFlowExcessBaggageClaimHdrsEntity);
		WorkFlowExcessBaggageClaimsDetailsEntity workFlowExcessBaggageClaimsDetailsEntity = new WorkFlowExcessBaggageClaimsDetailsEntity();
		workFlowExcessBaggageClaimsDetailsEntity = updateWorkFlowExcessBaggageClaimsDetailsEntity(excessBaggageClaimDTO, workFlowExcessBaggageClaimsDetailsEntity);
		PrsnlExcessBaggageClaimHdrsEntity prsnlExcessBaggageClaimHdrsEntity= new PrsnlExcessBaggageClaimHdrsEntity();
		prsnlExcessBaggageClaimHdrsEntity = updatePrsnlExcessBaggageClaimHdrsEntity(excessBaggageClaimDTO, prsnlExcessBaggageClaimHdrsEntity);
		PrsnlExcessBaggageClaimDtlsEntity prsnlExcessBaggageClaimDtlsEntity = new PrsnlExcessBaggageClaimDtlsEntity();
		prsnlExcessBaggageClaimDtlsEntity = updatePrsnlExcessBaggageClaimDtlsEntity(excessBaggageClaimDTO, prsnlExcessBaggageClaimDtlsEntity);
		NotificationEntity notificationEntity = new NotificationEntity();
		notificationEntity = updateNotificationEntity(excessBaggageClaimDTO,notificationEntity);
		ApplicationEntity applicationEntity = new ApplicationEntity(); 
		applicationEntity = updateApplicationEntity(excessBaggageClaimDTO,applicationEntity);
		EntityTransaction entityTransaction = entityManager.getTransaction();
		
		try {
			//Start of transaction
			entityTransaction.begin();
			//persist method is used to do insertion of entities into their DB table.
			entityManager.persist(workFlowExcessBaggageClaimHdrsEntity);
			entityManager.persist(workFlowExcessBaggageClaimsDetailsEntity);
			entityManager.persist(prsnlExcessBaggageClaimHdrsEntity);
			entityManager.persist(prsnlExcessBaggageClaimDtlsEntity);
			entityManager.persist(notificationEntity);
			entityManager.persist(applicationEntity);
			//commit will actually make this transaction persist in DB.
			entityTransaction.commit();
		} catch (RuntimeException e) {
			if (entityTransaction.isActive()) {
				entityTransaction.rollback();
			}
			e.printStackTrace();
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG,SOMETHING_WENT_WRONG_MSG);
		} finally {
			entityManager.clear();
			entityManager.close();
		}
	}
	
	@Override
	public void updateBaggageClaimDetails(ExcessBaggageClaimDTO excessBaggageClaimDTO) {
		BaggageClaimId baggageClaimId = new BaggageClaimId(UNIT_CODE,Integer.parseInt(excessBaggageClaimDTO.getDocNumber()));
		WorkflowLeaveHeaderId workflowLeaveHeaderId = new WorkflowLeaveHeaderId(UNIT_CODE,DOC_CODE,Integer.parseInt(excessBaggageClaimDTO.getDocNumber()));
		String notificationQuery;
		if(excessBaggageClaimDTO.getOperation().equals("Cancel")) {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Excess Baggage Claim' and META_INFO = '"+excessBaggageClaimDTO.getDocNumber()+"'";
		}else {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Excess Baggage Claim' and META_INFO = '"+excessBaggageClaimDTO.getDocNumber()+"' and EMPLOYEE_ID='"+excessBaggageClaimDTO.getRequestorId()+"'";
		}
		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Excess Baggage Claim' and META_INFO = '"+excessBaggageClaimDTO.getDocNumber()+"'";
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		try {
			//Start of transaction
			entityTransaction.begin();
			//updating respective entity objects to insert data to their respective tables using LeaveDTO
			PrsnlExcessBaggageClaimHdrsEntity prsnlExcessBaggageClaimHdrsEntity = entityManager.find(PrsnlExcessBaggageClaimHdrsEntity.class,baggageClaimId);
			prsnlExcessBaggageClaimHdrsEntity = updatePrsnlExcessBaggageClaimHdrsEntity(excessBaggageClaimDTO,prsnlExcessBaggageClaimHdrsEntity);		
			
			WorkFlowExcessBaggageClaimHdrsEntity workFlowExcessBaggageClaimHdrsEntity = entityManager.find(WorkFlowExcessBaggageClaimHdrsEntity.class, workflowLeaveHeaderId);
			workFlowExcessBaggageClaimHdrsEntity = updateWorkFlowExcessBaggageClaimHdrsEntity(excessBaggageClaimDTO, workFlowExcessBaggageClaimHdrsEntity);
			
			NotificationEntity notificationEntityUpdate = (NotificationEntity) entityManager.createQuery(notificationQuery).getResultList().get(0);
		//	notificationEntityUpdate = updateNotificationEntity(excessBaggageClaimDTO,notificationEntityUpdate);
			notificationEntityUpdate.setActionTaken(true);
			
			NotificationEntity notificationEntityInsert = new NotificationEntity();
			notificationEntityInsert = updateNotificationEntity(excessBaggageClaimDTO,notificationEntityInsert);
			
			//Overriding empId and actionTaken
		//	notificationEntityUpdate.setEmployeeId(excessBaggageClaimDTO.getRequestorId());
		//	notificationEntityInsert.setActionTaken(false);
			entityManager.persist(notificationEntityInsert);
			
			ApplicationEntity applicationEntityUpdate = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
			applicationEntityUpdate = updateApplicationEntity(excessBaggageClaimDTO,applicationEntityUpdate);
			
			entityManager.merge(prsnlExcessBaggageClaimHdrsEntity);
			entityManager.merge(workFlowExcessBaggageClaimHdrsEntity);
			entityManager.merge(notificationEntityUpdate);
			entityManager.merge(applicationEntityUpdate);
			entityTransaction.commit();
			//END of transaction
		} catch (RuntimeException e) {
		    if (entityTransaction.isActive()) {
		        entityTransaction.rollback();
		    }
		    e.printStackTrace();
		    throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		} finally {
			entityManager.clear();
		    entityManager.close();
		}
	}
	
	
	
	private WorkFlowExcessBaggageClaimHdrsEntity updateWorkFlowExcessBaggageClaimHdrsEntity(ExcessBaggageClaimDTO excessBaggageClaimDTO, WorkFlowExcessBaggageClaimHdrsEntity entity){
		switch (excessBaggageClaimDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentCode(DOC_CODE);
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
			entity.setEmployeeId(excessBaggageClaimDTO.getEmployeeId());
			entity.setClaimCode(excessBaggageClaimDTO.getClaimsCode());
			entity.setClaimYear(excessBaggageClaimDTO.getClaimsYear());
			entity.setClaimDate(new Date());
			entity.setApplicationType("New");
			entity.setCurrencyCode(excessBaggageClaimDTO.getCurrencyCode());
			entity.setCurrencyRate(excessBaggageClaimDTO.getCurrencyRate());
			entity.setExcessWeight(excessBaggageClaimDTO.getExcessWeight());
			
			
			break;
		case "Accept":
			entity.setApplicationType("Completed");
			break;
		case "Reject":
			entity.setApplicationType("Cancelled");
			break;
		}
		return entity;
	}
	
	
	private WorkFlowExcessBaggageClaimsDetailsEntity updateWorkFlowExcessBaggageClaimsDetailsEntity(ExcessBaggageClaimDTO excessBaggageClaimDTO, WorkFlowExcessBaggageClaimsDetailsEntity entity){
		switch (excessBaggageClaimDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentCode(DOC_CODE);
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
			entity.setBillDetailSNo(getMaxDocumentNo()+1);
			entity.setReceiptNo(excessBaggageClaimDTO.getReceiptNo());
			entity.setReceiptDate(excessBaggageClaimDTO.getReceiptDate());
			entity.setExcessWeight(excessBaggageClaimDTO.getExcessWeight());
			entity.setClaimAmount(excessBaggageClaimDTO.getClaimAmount());
			break;
		}
		return entity;	
	}
	
	
	private PrsnlExcessBaggageClaimHdrsEntity updatePrsnlExcessBaggageClaimHdrsEntity(ExcessBaggageClaimDTO excessBaggageClaimDTO, PrsnlExcessBaggageClaimHdrsEntity entity){
		switch (excessBaggageClaimDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setBillNumber(getMaxDocumentNo()+1);
			entity.setEmployeeId(excessBaggageClaimDTO.getEmployeeId());
			entity.setClaimDate(new Date());
			entity.setClaimCode(excessBaggageClaimDTO.getClaimsCode());
			entity.setCurrencyCode(excessBaggageClaimDTO.getCurrencyCode());
			entity.setCurrencyRate(excessBaggageClaimDTO.getCurrencyRate());
			entity.setExcessWeight(excessBaggageClaimDTO.getExcessWeight());
			entity.setCreatedBy(excessBaggageClaimDTO.getEmployeeId());
			entity.setDateTimeCreated(new Date());
//			entity.setSchoolAddress(dependentDetailsEntity.getSchoolAddress());
//			entity.setCreatedBy(feeReimbursementDTO.getEmployeeId());
//			entity.setCreatedDate(new Date());
//			entity.setClaimSerialNo(getMaxDocumentNo()+1);
			break;

		case "Recommend":
			entity.setRecomendBy(excessBaggageClaimDTO.getRequestorId());
			entity.setRecomendDate(new Date());
			entity.setCurrencyRate(excessBaggageClaimDTO.getCurrencyRate());
			break;
		case "Accept":
			entity.setApprovedBy(excessBaggageClaimDTO.getRequestorId());
			entity.setApprovedDate(new Date());
			entity.setCurrencyRate(excessBaggageClaimDTO.getCurrencyRate());
			break;
			
		}
		return entity;
	}
	
	
	private PrsnlExcessBaggageClaimDtlsEntity updatePrsnlExcessBaggageClaimDtlsEntity(ExcessBaggageClaimDTO excessBaggageClaimDTO, PrsnlExcessBaggageClaimDtlsEntity entity){

		switch (excessBaggageClaimDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setBillNumber(getMaxDocumentNo()+1);
			entity.setBillDetailSNo(getMaxDocumentNo()+1);
			entity.setClaimAmount(excessBaggageClaimDTO.getClaimAmount());
		//	entity.setAdmisibleAmount(excessBaggageClaimDTO.geta);
			entity.setReceiptNo(excessBaggageClaimDTO.getReceiptNo());
			entity.setReceiptDate(excessBaggageClaimDTO.getReceiptDate());
			entity.setExcessWeight(excessBaggageClaimDTO.getExcessWeight());
			entity.setCreatedBy(excessBaggageClaimDTO.getEmployeeId());
			entity.setDateTimeCreated(new Date());
			break;
//		case "Recommend":
//			entity.setStatus("R");
//			break;
//		case "Accept":
//			entity.setStatus("C");
//			break;
//		case "Reject":
//			entity.setStatus("T");//Rejected - Terminated
//			break;

		}
		return entity;
	}
	
	
	private NotificationEntity updateNotificationEntity(ExcessBaggageClaimDTO excessBaggageClaimDTO, NotificationEntity entity) {
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(excessBaggageClaimDTO.getEmployeeId());
		entity.setActionTaken(false);
		entity.setEmployeeId(excessBaggageClaimDTO.getSendTo());
		entity.setNotificationDate(new Date());
		entity.setAppType("Excess Baggage Claim");
		entity.setDeleted(false);
		switch (excessBaggageClaimDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(Integer.toString(getMaxDocumentNo()+1));
			entity.setNotification("Excess Baggage Claim Request : "+excessBaggageClaimDTO.getEmployeeId()+" - "+empDetails.getEmployeeName());
			break;
			
		case "Recommend":
			entity.setNotification("Baggage Claim Recommended : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(excessBaggageClaimDTO.getDocNumber());
			break;
		case "Accept":
			entity.setEmployeeId(excessBaggageClaimDTO.getEmployeeId());
			entity.setNotification("Baggage Claim Accepted : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(excessBaggageClaimDTO.getDocNumber());
			break;
		case "Reject":
			entity.setEmployeeId(excessBaggageClaimDTO.getEmployeeId());
			entity.setNotification("Baggage Claim Rejected : Requested by "+empDetails.getEmployeeName());//Rejected - Terminated
			entity.setMetaInfo(excessBaggageClaimDTO.getDocNumber());
			break;

		}
		return entity;
	}
	
	
	private ApplicationEntity updateApplicationEntity(ExcessBaggageClaimDTO excessBaggageClaimDTO, ApplicationEntity entity) {
		entity.setEmployeeId(excessBaggageClaimDTO.getEmployeeId());
		entity.setAppType("Excess Baggage Claim");
		entity.setRequestedDate(new Date());
		switch (excessBaggageClaimDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(getMaxDocumentNo()+1);
			entity.setAppStatus("Applied");
			break;
		case "Recommend":
			entity.setAppStatus("Recommended");
			break;
		case "Accept":
			entity.setAppStatus("Accepted");
			break;
		case "Reject":
			entity.setAppStatus("Rejected");
			break;
		}
		return entity;
	}
	/**
	 * getMaxDocumentNo is a temporary method which is used to generate documentNumber.
	 *
	 */
	public int getMaxDocumentNo() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "SELECT COALESCE(MAX(metaInfo),100) FROM ApplicationEntity";
		int maxNumber = (int) entityManager.createQuery(query).getResultList().get(0);
		entityManager.clear();
		entityManager.close();
		return maxNumber;

	}
	
	@Override
	public ExcessBaggageClaimDTO getExcessBagaggeClaimDetail(String identifier){
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Excess Baggage Claim' and META_INFO = "+identifier;
		ApplicationEntity getApplicatioDetails = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
		ExcessBaggageClaimDTO excessBaggageClaimDTO = new ExcessBaggageClaimDTO();
		
		String query = "FROM NotificationEntity where APPLICATION_TYPE='Excess Baggage Claim' and META_INFO = "+identifier;
		NotificationEntity getNotificationDetails = (NotificationEntity)entityManager.createQuery(query).getResultList().get(0);
		
		
		BaggageClaimId baggageClaimId = new BaggageClaimId(UNIT_CODE,Integer.parseInt(identifier));
		PrsnlExcessBaggageClaimHdrsEntity prsnlExcessBaggageClaimHdrsEntity = entityManager.find(PrsnlExcessBaggageClaimHdrsEntity.class,baggageClaimId);
		
		PrsnlExcessBaggageClaimDtlsEntity prsnlExcessBaggageClaimDtlsEntity = entityManager.find(PrsnlExcessBaggageClaimDtlsEntity.class,baggageClaimId);
		
		WorkflowLeaveHeaderId workflowLeaveHeaderId = new WorkflowLeaveHeaderId(UNIT_CODE,DOC_CODE,Integer.parseInt(identifier));
		WorkFlowExcessBaggageClaimHdrsEntity workFlowExcessBaggageClaimHdrsEntity = entityManager.find(WorkFlowExcessBaggageClaimHdrsEntity.class, workflowLeaveHeaderId);
		
		WorkFlowExcessBaggageClaimsDetailsEntity workFlowExcessBaggageClaimsDetailsEntity = entityManager.find(WorkFlowExcessBaggageClaimsDetailsEntity.class, workflowLeaveHeaderId);
		excessBaggageClaimDTO.setEmployeeId(prsnlExcessBaggageClaimHdrsEntity.getEmployeeId());
		excessBaggageClaimDTO.setClaimsCode(prsnlExcessBaggageClaimHdrsEntity.getClaimCode());
		excessBaggageClaimDTO.setCurrencyCode(prsnlExcessBaggageClaimHdrsEntity.getCurrencyCode());
		excessBaggageClaimDTO.setCurrencyRate(prsnlExcessBaggageClaimHdrsEntity.getCurrencyRate());
		excessBaggageClaimDTO.setExcessWeight(prsnlExcessBaggageClaimHdrsEntity.getExcessWeight());
		excessBaggageClaimDTO.setClaimsYear(workFlowExcessBaggageClaimHdrsEntity.getClaimYear());
		excessBaggageClaimDTO.setDocNumber(identifier);
		excessBaggageClaimDTO.setClaimAmount(prsnlExcessBaggageClaimDtlsEntity.getClaimAmount());
		excessBaggageClaimDTO.setReceiptNo(prsnlExcessBaggageClaimDtlsEntity.getReceiptNo());
		excessBaggageClaimDTO.setReceiptDate(workFlowExcessBaggageClaimsDetailsEntity.getReceiptDate());
		excessBaggageClaimDTO.setSendTo(getNotificationDetails.getEmployeeId());
		
	
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(excessBaggageClaimDTO.getEmployeeId());
		excessBaggageClaimDTO.setEmployeeName(empDetails.getEmployeeName());
		
		
		switch(getApplicatioDetails.getAppStatus()){
		case "Applied":
			excessBaggageClaimDTO.setStatus("P");
			break;
		case "Recommended":
			excessBaggageClaimDTO.setStatus("R");
			break;
		case "Accepted":
			excessBaggageClaimDTO.setStatus("C");
			break;
		case "Rejected":
			excessBaggageClaimDTO.setStatus("T");
			break;		
		}
		

		
		return excessBaggageClaimDTO;
	}

	

}

