/**
 * 
 */
package com.omifco.repository.impl;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.omifco.compositeids.TimeLeaveDetailsId;
import com.omifco.compositeids.WorkflowLeaveHeaderId;
import com.omifco.dto.EmployeeTourDTO;
import com.omifco.dto.LeaveDTO;
import com.omifco.dto.LeaveSummaryDTO;
import com.omifco.dto.RemarksDTO;
import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.LeaveBalanceSummaryEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.entity.TimEmployeeTourDetailsEntity;
import com.omifco.entity.TimEmployeeTourHeaderEntity;
import com.omifco.entity.UserEntity;
import com.omifco.entity.WorkFlowTimEmployeeTourDetailsEntity;
import com.omifco.entity.WorkflowTimEmployeeTourHeaderEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.EmployeeTourRepository;
import com.omifco.repository.LeaveApplicationRepository;
import com.omifco.repository.UserInfoRepository;

/**
 * @author Anigam
 *
 */
@Repository
public class EmployeeTourRepositoryImpl implements EmployeeTourRepository, MessageConstants {

	/**
	 * EntityManager instance is injected by Spring Framework.
	 * 
	 * This is used to manage all the Persistent entities
	 * defined in the System.
	 */
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	
	@Autowired
	private UserInfoRepository userInfoRepository;
	
	@Autowired
	private LeaveApplicationRepository leaveApplicationRepositiory;
	
	private final int UNIT_CODE = 1010;
	private final int DOC_CODE = 1;
	
	
	@Override
	public void insertEmployeeTourDetails(EmployeeTourDTO employeeTourDTO){
		
		boolean hasSufficientBalance = checkLeaveBalance(employeeTourDTO);
		if(hasSufficientBalance) {
			
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			WorkflowTimEmployeeTourHeaderEntity workflowTimEmployeeTourHeaderEntity = new WorkflowTimEmployeeTourHeaderEntity();
			workflowTimEmployeeTourHeaderEntity = updateworkflowTimEmployeeTourHeaderEntity(employeeTourDTO, workflowTimEmployeeTourHeaderEntity);
			WorkFlowTimEmployeeTourDetailsEntity workFlowTimEmployeeTourDetailsEntity = new WorkFlowTimEmployeeTourDetailsEntity();
			workFlowTimEmployeeTourDetailsEntity = updateWorkFlowTimEmployeeTourDetailsEntity(employeeTourDTO, workFlowTimEmployeeTourDetailsEntity);
			TimEmployeeTourHeaderEntity timEmployeeTourHeaderEntity= new TimEmployeeTourHeaderEntity();
			timEmployeeTourHeaderEntity = updateTimEmployeeTourHeaderEntity(employeeTourDTO, timEmployeeTourHeaderEntity);
			TimEmployeeTourDetailsEntity timEmployeeTourDetailsEntity = new TimEmployeeTourDetailsEntity();
			timEmployeeTourDetailsEntity = updateTimEmployeeTourDetailsEntity(employeeTourDTO, timEmployeeTourDetailsEntity);
			NotificationEntity notificationEntity = new NotificationEntity();
			notificationEntity = updateNotificationEntity(employeeTourDTO,notificationEntity);
			ApplicationEntity applicationEntity = new ApplicationEntity(); 
			applicationEntity = updateApplicationEntity(employeeTourDTO,applicationEntity);
			EntityTransaction entityTransaction = entityManager.getTransaction();
			
			LeaveDTO leaveDTO = updateLeaveDTO(employeeTourDTO);
			String leaveBalanceQuery = "FROM LeaveBalanceSummaryEntity where LV_TYPE_CODE = '"+leaveDTO.getLeaveType()
			+"' and PERSONAL_NO ='"+leaveDTO.getEmployeeId()+"' and LV_PAY_FLAG="+leaveDTO.getLeaveFlag();
			
			try {
				LeaveBalanceSummaryEntity leaveBalanceEntity = (LeaveBalanceSummaryEntity) entityManager.createQuery(leaveBalanceQuery).getResultList().get(0);
				int leaveDays = calculateNoOfDays(leaveDTO.getFromDate(), leaveDTO.getToDate());
				leaveBalanceEntity.setBalanceDays(leaveBalanceEntity.getBalanceDays()-leaveDays);
				//Start of transaction
				entityTransaction.begin();
				//persist method is used to do insertion of entities into their DB table.
				entityManager.persist(workflowTimEmployeeTourHeaderEntity);
				entityManager.persist(workFlowTimEmployeeTourDetailsEntity);
				entityManager.persist(timEmployeeTourHeaderEntity);
				entityManager.persist(timEmployeeTourDetailsEntity);
				entityManager.persist(notificationEntity);
				entityManager.persist(applicationEntity);
				entityManager.merge(leaveBalanceEntity);
				//commit will actually make this transaction persist in DB.
				entityTransaction.commit();
			} catch (RuntimeException e) {
				if (entityTransaction.isActive()) {
					entityTransaction.rollback();
				}
				e.printStackTrace();
				throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG,SOMETHING_WENT_WRONG_MSG);
			} finally {
				entityManager.clear();
				entityManager.close();
			}
		}else {
			throw new OMIFCOBusinessException(INSUFFICENT_LEAVE_CODE,INSUFFICENT_LEAVE_MSG);
		}
		
	}
	
	private LeaveDTO updateLeaveDTO(EmployeeTourDTO employeeTourDTO) {
		LeaveDTO leaveDTO = new LeaveDTO();
		leaveDTO.setEmployeeId(employeeTourDTO.getEmployeeId());
		leaveDTO.setFromDate(employeeTourDTO.getLeaveFrom());
		leaveDTO.setToDate(employeeTourDTO.getLeaveTo());
		leaveDTO.setLeaveFlag(1);
		leaveDTO.setLeavePurpose("44");
		leaveDTO.setLeaveType("AL");
		leaveDTO.setOperation(employeeTourDTO.getOperation());
		leaveDTO.setRequestorId(employeeTourDTO.getRequestorId());
		leaveDTO.setSendTo(employeeTourDTO.getSendTo());
		leaveDTO.setRemarks(employeeTourDTO.getRemarks());
		leaveDTO.setDocNumber(Integer.toString(employeeTourDTO.getDocumentSerialNumber()));
		if (employeeTourDTO.getOperation().equalsIgnoreCase("Apply")) {
			leaveDTO.setDocNumber(Integer.toString(getMaxDocumentNo()+1));
		}
		return leaveDTO;
	}

	@Override
	public void updateEmployeeTourDetails(EmployeeTourDTO employeeTourDTO){
		String notificationQuery;
		if(employeeTourDTO.getOperation().equals("Cancel")) {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Employee Tour' and META_INFO = "+employeeTourDTO.getDocumentSerialNumber();
		}else {
			notificationQuery = "FROM NotificationEntity where APPLICATION_TYPE='Employee Tour' and META_INFO = "+employeeTourDTO.getDocumentSerialNumber()+" and EMPLOYEE_ID='"+employeeTourDTO.getRequestorId()+"'";
		}
		String appQuery = "FROM ApplicationEntity where APPLICATION_TYPE='Employee Tour' and META_INFO = "+employeeTourDTO.getDocumentSerialNumber();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		LeaveDTO leaveDTO = updateLeaveDTO(employeeTourDTO);
		String leaveBalanceQuery = "FROM LeaveBalanceSummaryEntity where LV_TYPE_CODE = '"+leaveDTO.getLeaveType()
		+"' and PERSONAL_NO ='"+leaveDTO.getEmployeeId()+"' and LV_PAY_FLAG="+leaveDTO.getLeaveFlag();
		try {
			//Start of transaction

			entityTransaction.begin();
			
			WorkflowLeaveHeaderId workflowLeaveHeaderId = new WorkflowLeaveHeaderId(UNIT_CODE,DOC_CODE,employeeTourDTO.getDocumentSerialNumber());
			TimeLeaveDetailsId timeLeaveDetailsId = new TimeLeaveDetailsId(UNIT_CODE,employeeTourDTO.getDocumentSerialNumber());
			
			WorkflowTimEmployeeTourHeaderEntity workflowTimEmployeeTourHeaderEntity = entityManager.find(WorkflowTimEmployeeTourHeaderEntity.class,workflowLeaveHeaderId);
			workflowTimEmployeeTourHeaderEntity = updateworkflowTimEmployeeTourHeaderEntity(employeeTourDTO,workflowTimEmployeeTourHeaderEntity);
			
			TimEmployeeTourHeaderEntity timEmployeeTourHeaderEntity= entityManager.find(TimEmployeeTourHeaderEntity.class,timeLeaveDetailsId);
			timEmployeeTourHeaderEntity = updateTimEmployeeTourHeaderEntity(employeeTourDTO, timEmployeeTourHeaderEntity);
		
			NotificationEntity notificationEntityUpdate = (NotificationEntity) entityManager.createQuery(notificationQuery).getResultList().get(0);
			notificationEntityUpdate.setActionTaken(true);
	//		notificationEntityUpdate = updateNotificationEntity(employeeTourDTO,notificationEntityUpdate);
			NotificationEntity notificationEntityInsert = new NotificationEntity();
			notificationEntityInsert = updateNotificationEntity(employeeTourDTO,notificationEntityInsert);
			ApplicationEntity applicationEntityUpdate = (ApplicationEntity) entityManager.createQuery(appQuery).getResultList().get(0);
			applicationEntityUpdate = updateApplicationEntity(employeeTourDTO,applicationEntityUpdate);
			if(employeeTourDTO.getOperation().equals("Reject")){
				LeaveBalanceSummaryEntity leaveBalanceEntity = (LeaveBalanceSummaryEntity) entityManager.createQuery(leaveBalanceQuery).getResultList().get(0);
				int leaveDays = calculateNoOfDays(leaveDTO.getFromDate(), leaveDTO.getToDate());
				leaveBalanceEntity.setBalanceDays(leaveBalanceEntity.getBalanceDays()+leaveDays);
				entityManager.merge(leaveBalanceEntity);
				}
			entityManager.merge(workflowTimEmployeeTourHeaderEntity);
			entityManager.merge(timEmployeeTourHeaderEntity);
			entityManager.merge(notificationEntityUpdate); 
			entityManager.merge(applicationEntityUpdate);
			entityManager.persist(notificationEntityInsert);
			entityTransaction.commit();
			//END of transaction
		} catch (RuntimeException e) {
			if (entityTransaction.isActive()) {
				entityTransaction.rollback();
			}
			e.printStackTrace();
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		} finally {
			entityManager.clear();
			entityManager.close();
		}
	}
	
	/**
	 * checkLeaveBalance is responsible to check if an employee has sufficient
	 * leave balance or not and thereby returns boolean value based on it.
	 * 
	 * @param leaveDTO
	 * @return
	 */
	private boolean checkLeaveBalance(EmployeeTourDTO employeeTourDTO) {
		LeaveSummaryDTO leaveBalanceInfo = leaveApplicationRepositiory.getLeaveBalanceSummaryById(employeeTourDTO.getEmployeeId());
		int leaveDays = calculateNoOfDays(employeeTourDTO.getLeaveFrom(),employeeTourDTO.getLeaveTo());
		if(leaveBalanceInfo.getTotalLeaveBalance() >= leaveDays) {
			String leaveType = "AL";
			switch (leaveType) {
			case "AL":
				if(leaveBalanceInfo.getAnnualLeaves() >= leaveDays) {
					return true;
				}else {
					throw new OMIFCOBusinessException(INSUFFICENT_ANNUAL_LEAVE_CODE,INSUFFICENT_ANNUAL_LEAVE_MSG);
				}
			}
		}
		return false;
	}
	
	/**
	 * calculateNoOfDays returns no of days for which employee is applying leave.
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public int calculateNoOfDays(Date fromDate, Date toDate) {
		LocalDate fromLocal = fromDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate toLocal = toDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int days = (int)ChronoUnit.DAYS.between(fromLocal, toLocal);
		//Incrementing difference by one to include endDate.
		days = days +1;
		return days;
	}
	
	private WorkflowTimEmployeeTourHeaderEntity updateworkflowTimEmployeeTourHeaderEntity(EmployeeTourDTO employeeTourDTO, WorkflowTimEmployeeTourHeaderEntity entity){
		switch (employeeTourDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentCode(DOC_CODE);
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
			entity.setEmployeeId(employeeTourDTO.getEmployeeId());
			entity.setApplicationType("N");
			entity.setTourStartDate(employeeTourDTO.getDepartureDate());
			entity.setTourEndDate(employeeTourDTO.getArrivalDate());
			entity.setApplicationDate(new Date());
			entity.setTourStartTime(employeeTourDTO.getDepartureTime());
			entity.setTourEndTime(employeeTourDTO.getArrivalTime());
			entity.setTourType(employeeTourDTO.getTourType());
			entity.setPlacesOfVisit("");
			entity.setGradeCode("GGG");
			entity.setTourPurpose(employeeTourDTO.getTourPurpose());
			entity.setExceptionIfAny("");
			entity.setOrigRevised("A");
			entity.setOrigDocumentNumber("123");
			entity.setTourStatus("P");
			entity.setLeaveFrom(employeeTourDTO.getLeaveFrom());
			entity.setLeaveTo(employeeTourDTO.getLeaveTo());
			break;
		case "Recommend":
			entity.setTourStatus("R");
			break;
		case "Approve":
			entity.setTourStatus("A");
			break;
		case "Accept":
			entity.setTourStatus("C");
			break;
		case "Reject":
			entity.setTourStatus("T");//Cancelled
			break;
		}
		return entity;
	}
	
	private WorkFlowTimEmployeeTourDetailsEntity updateWorkFlowTimEmployeeTourDetailsEntity(EmployeeTourDTO employeeTourDTO, WorkFlowTimEmployeeTourDetailsEntity entity){
		switch (employeeTourDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentCode(DOC_CODE);
			entity.setDocumentSerialNo(getMaxDocumentNo()+1);
			entity.setDetailsSNumber(getMaxDocumentNo()+1);
			entity.setStationFrom(employeeTourDTO.getStationFrom());
			entity.setStationTo(employeeTourDTO.getStationTo());
			entity.setDepartureDate(employeeTourDTO.getDepartureDate());
			entity.setDepartureTime(employeeTourDTO.getDepartureTime());
			entity.setArrivalDate(employeeTourDTO.getArrivalDate());
			entity.setArrivalTime(employeeTourDTO.getArrivalTime());
			entity.setTravelMode(employeeTourDTO.getTravelMode());
			break;
		}
		return entity;
	}
	
	private TimEmployeeTourHeaderEntity updateTimEmployeeTourHeaderEntity(EmployeeTourDTO employeeTourDTO, TimEmployeeTourHeaderEntity entity){
		UserEntity currentUserDetails = userInfoRepository.getEmployeeDetails(employeeTourDTO.getRequestorId());
		switch (employeeTourDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentNumber(getMaxDocumentNo()+1);
			entity.setEmployeeId(employeeTourDTO.getEmployeeId());
			entity.setApplicationDate(new Date());
			entity.setTourStartDate(employeeTourDTO.getDepartureDate());
			entity.setTourEndDate(employeeTourDTO.getArrivalDate());
			entity.setTourStartTime(employeeTourDTO.getDepartureTime());
			entity.setTourEndTime(employeeTourDTO.getArrivalTime());
			entity.setTourType(employeeTourDTO.getTourType());
			entity.setPlacesOfVisit("");
			entity.setGradeCode("GGG");
			entity.setTourPurpose(employeeTourDTO.getTourPurpose());
			entity.setExceptionIfAny("");
			entity.setOrigRevised("A");
			entity.setOrigDocumentNumber("123");
			entity.setTourStatus("P");
			entity.setLeaveFrom(employeeTourDTO.getLeaveFrom());
			entity.setLeaveTo(employeeTourDTO.getLeaveTo());
			entity.setCreatedBy(employeeTourDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			break;
		case "Recommend":
			entity.setRecommendBy(employeeTourDTO.getRequestorId());
			entity.setRecommendDate(new Date());
			entity.setTourStatus("R");
			entity.setRemarks(currentUserDetails.getEmployeeName()+" - "+employeeTourDTO.getRemarks());
			break;
		case "Approve":
			entity.setApprovedBy(employeeTourDTO.getRequestorId());
			entity.setApprovedDate(new Date());
			entity.setTourStatus("A");
			entity.setRemarks((entity.getRemarks()==null ? "" : entity.getRemarks()+" : ")+ currentUserDetails.getEmployeeName()+" - "+employeeTourDTO.getRemarks());
			break;
		case "Accept":
			entity.setTourStatus("C");
			entity.setRemarks((entity.getRemarks()==null ? "" : entity.getRemarks()+" : ")+ currentUserDetails.getEmployeeName()+" - "+employeeTourDTO.getRemarks());
			break;
		case "Reject":
			entity.setTourStatus("T");//Cancelled
			entity.setRemarks((entity.getRemarks()==null ? "" : entity.getRemarks()+" : ")+ currentUserDetails.getEmployeeName()+" - "+employeeTourDTO.getRemarks());
			break;
		}
		
		return entity;
	}
	
	private TimEmployeeTourDetailsEntity updateTimEmployeeTourDetailsEntity(EmployeeTourDTO employeeTourDTO, TimEmployeeTourDetailsEntity entity){
		switch (employeeTourDTO.getOperation()) {
		case "Apply":
			entity.setUnitCode(UNIT_CODE);
			entity.setDocumentNumber(getMaxDocumentNo()+1);
			entity.setDetailsSNumber(getMaxDocumentNo()+1);
			entity.setEmployeeId(employeeTourDTO.getEmployeeId());
			entity.setStationFrom(employeeTourDTO.getStationFrom());
			entity.setStationTo(employeeTourDTO.getStationTo());
			entity.setDepartureDate(employeeTourDTO.getDepartureDate());
			entity.setDepartureTime(employeeTourDTO.getDepartureTime());
			entity.setArrivalDate(employeeTourDTO.getArrivalDate());
			entity.setArrivalTime(employeeTourDTO.getArrivalTime());
			entity.setTravelMode(employeeTourDTO.getTravelMode());
			entity.setCreatedBy(employeeTourDTO.getEmployeeId());
			entity.setCreatedDate(new Date());
			break;
		}
		return entity;
	}
	
	/**
	 * getMaxDocumentNo is a temporary method which is used to generate documentNumber.
	 *
	 */
	public int getMaxDocumentNo() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String query = "SELECT COALESCE(MAX(metaInfo),100) FROM ApplicationEntity";
		int maxNumber = (int) entityManager.createQuery(query).getResultList().get(0);
		entityManager.clear();
		entityManager.close();
	
		return maxNumber;
	}
	/**
	 * updateNotificationEntity updates NotificationEntity using EmployeeTourDTO
	 * 
	 * @param employeeTourDTO
	 * @param entity
	 * @return
	 */
	private NotificationEntity updateNotificationEntity(EmployeeTourDTO employeeTourDTO, NotificationEntity entity) {
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(employeeTourDTO.getEmployeeId());
		entity.setActionTaken(false);
		entity.setEmployeeId(employeeTourDTO.getSendTo());
		entity.setNotificationDate(new Date());
		entity.setAppType("Employee Tour");
		entity.setDeleted(false);
		switch (employeeTourDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(Integer.toString(getMaxDocumentNo()+1));
			entity.setNotification("Employee Tour Request : "+employeeTourDTO.getEmployeeId()+" - "+empDetails.getEmployeeName());
			break;
		case "Recommend":
			entity.setNotification("Employee Tour Recommended : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(employeeTourDTO.getDocumentSerialNumber()));
			break;
		case "Approve":
			entity.setNotification("Employee Tour Approved : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(employeeTourDTO.getDocumentSerialNumber()));
			break;	
		case "Accept":
			entity.setEmployeeId(employeeTourDTO.getEmployeeId());
			entity.setNotification("Employee Tour Accepted : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(employeeTourDTO.getDocumentSerialNumber()));
			break;
		case "Reject":
			entity.setEmployeeId(employeeTourDTO.getEmployeeId());
			entity.setNotification("Employee Tour Rejected : Requested by "+empDetails.getEmployeeName());
			entity.setMetaInfo(Integer.toString(employeeTourDTO.getDocumentSerialNumber()));
			break;
		}
		return entity;
	}
	
	/**
	 * updateApplicationEntity updates Application Entity using EmployeeTourDTO
	 * 
	 * @param 
	 * @param entity
	 * @return
	 */
	private ApplicationEntity updateApplicationEntity(EmployeeTourDTO employeeTourDTO, ApplicationEntity entity) {
		entity.setEmployeeId(employeeTourDTO.getEmployeeId());
		entity.setAppType("Employee Tour");
		entity.setRequestedDate(new Date());
		switch (employeeTourDTO.getOperation()) {
		case "Apply":
			entity.setMetaInfo(getMaxDocumentNo()+1);
			entity.setAppStatus("Applied");
			break;
		case "Recommend":
			entity.setAppStatus("Recommended");
			break;
		case "Approved":
			entity.setAppStatus("Approved");
			break;	
		case "Accept":
			entity.setAppStatus("Accepted");
			break;
		case "Reject":
			entity.setAppStatus("Rejected");
			break;
		}
		return entity;
	}

	@Override
	public EmployeeTourDTO getTourDetails(String identifier) {
		EmployeeTourDTO employeeTourDTO = new EmployeeTourDTO();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		TimeLeaveDetailsId timeLeaveDetailsId = new TimeLeaveDetailsId(UNIT_CODE,Integer.parseInt(identifier));
		TimEmployeeTourHeaderEntity timEmployeeTourHeaderEntity= entityManager.find(TimEmployeeTourHeaderEntity.class,timeLeaveDetailsId);
		TimEmployeeTourDetailsEntity timEmployeeTourDetailsEntity = entityManager.find(TimEmployeeTourDetailsEntity.class,timeLeaveDetailsId);
		employeeTourDTO.setArrivalDate(timEmployeeTourHeaderEntity.getTourEndDate());
		employeeTourDTO.setArrivalTime(timEmployeeTourHeaderEntity.getTourEndTime());
		employeeTourDTO.setDepartureDate(timEmployeeTourHeaderEntity.getTourStartDate());
		employeeTourDTO.setDepartureTime(timEmployeeTourHeaderEntity.getTourStartTime());
		employeeTourDTO.setDocumentSerialNumber(Integer.parseInt(identifier));
		employeeTourDTO.setEmployeeId(timEmployeeTourHeaderEntity.getEmployeeId());
		UserEntity empDetails = userInfoRepository.getEmployeeDetails(employeeTourDTO.getEmployeeId());
		employeeTourDTO.setEmployeeName(empDetails.getEmployeeName());
		employeeTourDTO.setLeaveFrom(timEmployeeTourHeaderEntity.getLeaveFrom());
		employeeTourDTO.setLeaveTo(timEmployeeTourHeaderEntity.getLeaveTo());
		employeeTourDTO.setStationFrom(timEmployeeTourDetailsEntity.getStationFrom());
		employeeTourDTO.setStationTo(timEmployeeTourDetailsEntity.getStationTo());
		employeeTourDTO.setTourPurpose(timEmployeeTourHeaderEntity.getTourPurpose());
		employeeTourDTO.setTourType(timEmployeeTourHeaderEntity.getTourType());
		employeeTourDTO.setTravelMode(timEmployeeTourDetailsEntity.getTravelMode());
		employeeTourDTO.setStatus(timEmployeeTourHeaderEntity.getTourStatus());
		List<RemarksDTO> listOfRemarks = new ArrayList<RemarksDTO>();
		String approverRemarks = timEmployeeTourHeaderEntity.getRemarks();
		//Logic to distinguish remarks of all approvers.
		try {
			if(null!=approverRemarks && approverRemarks.contains(":")) {
				String[] remarksArray = approverRemarks.split(":");
				for (String remark : remarksArray) {
					if(remark.contains(" - ")) {
						RemarksDTO remarksDTO = new RemarksDTO();
						remarksDTO.setApproverName(remark.split(" - ",2)[0]);
						remarksDTO.setApproverRemarks(remark.split(" - ",2)[1]);
						listOfRemarks.add(remarksDTO);
					}
				}
			}else if(null!=approverRemarks && !approverRemarks.isEmpty()){
				if(approverRemarks.contains(" - ")) {
					RemarksDTO remarksDTO = new RemarksDTO();
					remarksDTO.setApproverName(approverRemarks.split(" - ",2)[0]);
					remarksDTO.setApproverRemarks(approverRemarks.split(" - ",2)[1]);
					listOfRemarks.add(remarksDTO);
				}
			}
			employeeTourDTO.setApproverRemarks(listOfRemarks);
		}catch(Exception e) {
			throw new OMIFCOBusinessException(SOMETHING_WENT_WRONG, SOMETHING_WENT_WRONG_MSG);
		}
		return employeeTourDTO;
	}
}
