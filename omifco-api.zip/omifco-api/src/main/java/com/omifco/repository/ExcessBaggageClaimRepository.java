package com.omifco.repository;

import com.omifco.dto.ExcessBaggageClaimDTO;

public interface ExcessBaggageClaimRepository {

	/**
	 * getMaxDocumentNo is a temporary method which is used to generate documentNumber.
	 *
	 */
	public int getMaxDocumentNo();
	
	/**
	 *insertLeaveDetails is responsible to insert the leave data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolledback.
	 *
	 *@param leaveDTO
	 */
	public void insertBaggageClaimDetails(ExcessBaggageClaimDTO excessBaggageClaimDTO);
	
	/**
	 *updateLeaveDetails is responsible to update the leave data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolledback.
	 *
	 *@param leaveDTO 
	 */
	public void updateBaggageClaimDetails(ExcessBaggageClaimDTO excessBaggageClaimDTO);
	
	
	
	public ExcessBaggageClaimDTO getExcessBagaggeClaimDetail(String identifier);
//	
//	/**
//	 * getLeaveDetails returns the leave details based on document number 
//	 * generated during the time of applying leave.
//	 * 
//	 *@param docNumber
//	 */
//	public LeaveDTO getLeaveDetails(String docNumber);
//
//	/**
//	 *getLeaveAppDetails used to return application details based on appType and identifier
//	 *
//	 *@param applicationType
//	 *@param identifier
//	 */
//	public List<ApplicationEntity> getLeaveAppDetails(String applicationType, String identifier);
//	
//	/**
//	 * getLeaveBalanceSummaryById return leave summary - available leaves,
//	 * pending leaves, approved leaves, leave balance for AL,SL,EL etc.
//	 * 
//	 * @return  leaveSummaryDTO
//	 */
//	public LeaveSummaryDTO getLeaveBalanceSummaryById(String employeeId);
}
