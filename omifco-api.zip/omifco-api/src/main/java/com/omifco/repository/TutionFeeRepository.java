package com.omifco.repository;

import java.util.List;

import com.omifco.dto.FeeReimbursementDTO;
import com.omifco.entity.DependentDetailsEntity;

public interface TutionFeeRepository {

	
	/**
	 *insertTutionFeeDetails is responsible to insert the tution fee claim data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolled back.
	 *
	 *@param feeReimburseDTO
	 */
	public void insertTutionFeeDetails(FeeReimbursementDTO feeReimburseDTO);
	
	/**
	 *getDependentDetail is responsible to get the dependent details based on employeeId and dependent Serial No.
	 *
	 *@param employeeId
	 *@param dependentSerialNo
	 */
	public DependentDetailsEntity getDependentDetail(String employeeId, int dependentSerialNo);
	
	/**
	 *updateTutionFeeDetails is responsible to update the tution fee claim data into DB
	 *using a transaction. If anywhere during the insertion something went wrong
	 *the whole transaction gets rolled back.
	 *
	 *@param feeReimburseDTO
	 */
	public void updateTutionFeeDetails(FeeReimbursementDTO feeReimburseDTO);
	
	/**
	 *getDependentDetails is responsible to get the list of dependent details based on employeeId
	 *
	 *@param employeeId
	 */
	public List<DependentDetailsEntity> getDependentDetails(String employeeId);
	
	/**
	 *getClaimDetails is invoked to get the claim details based on claims Serial No.
	 *
	 *@param claimsSrNumber
	 */
	public FeeReimbursementDTO getClaimDetails(String claimsSrNumber);
	
	
}
