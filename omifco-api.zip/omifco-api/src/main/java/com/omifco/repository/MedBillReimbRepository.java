package com.omifco.repository;

import com.omifco.dto.MedBillReimbDTO;

public interface MedBillReimbRepository {

	public void insertMedBillReimbursementDetails(MedBillReimbDTO medBillReimbDTO);

	public void updateMedBillReimbursementDetails(MedBillReimbDTO medBillReimbDTO);

	public MedBillReimbDTO getMedBillReimbursementDetails(String identifier);
	
	public double getByAdmissibleAmountEmployeeId(String employeeId);
}
