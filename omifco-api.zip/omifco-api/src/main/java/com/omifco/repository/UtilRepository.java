package com.omifco.repository;

import java.util.List;
import java.util.Map;

import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.LookupMasterEntity;
import com.omifco.entity.NotificationEntity;

/**
 * UtilRepository encapsulates all database operations
 * related to utility functionalities of the System.
 * 
 * @author Prolifics
 *
 */
public interface UtilRepository {
	/**
	 * getLookupsByType returns all active Master Lookup
	 * entries of a specified type from the database.
	 * @param lookupType
	 * 	<p>The type of Lookup values desired.</p>
	 * @return
	 * 	<p>List of <strong>LookupMasterEntity</strong> instances.
	 */
	public List<LookupMasterEntity> getLookupsByType(String lookupType);
	
	/**
	 * getAllRequestsOfUser returns all Application Requests
	 * of a User.
	 * @param empId
	 * 	<p>Employee Id of the User.</p>
	 * @return
	 * 	<p>List of <strong>ApplicationEntity</strong> instances.
	 */
	public List<ApplicationEntity> getAllRequestsOfUser(String empId);
	
	/**
	 * getNotificationsOfUserByType returns all current and historical
	 * Notifications of a User based on specified type.
	 * @param empId
	 * 	<p>Employee Id of the User.</p>
	 * @param unActionedOnly
	 * 	<p>Flag to specify if only un-actioned item to return.</p>
	 * @return
	 * 	<p>List of <strong>NotificationEntity</strong> instances.
	 */
	public List<NotificationEntity> getNotificationsOfUserByType(String empId, boolean unActionedOnly);
	
	/**
	 *getAllApprovers returns a map of all direct line managers of an employee.
	 *
	 *@param employeeId
	 */
	public Map<String,String> getAllApprovers(String employeeId,int levels);

}
