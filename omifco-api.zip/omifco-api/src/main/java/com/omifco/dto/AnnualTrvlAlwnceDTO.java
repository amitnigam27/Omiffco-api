/**
 * 
 */
package com.omifco.dto;

/**
 * @author Prolifics
 *
 */
public class AnnualTrvlAlwnceDTO {

	private int documentSerialNo;
	
	private String employeeId;
	
	private String employeeName;
	
	private String claimCode;
	
	private int claimYear;
	
	private double claimAmount;
	
	private double approvedAmount;
	
	private double eligibilityAmount;
	
	private String requestorId;
	
	private String status;
	
	private String sendTo;
	
	private String operation;

	/**
	 * @return the documentSerialNo
	 */
	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	/**
	 * @param documentSerialNo the documentSerialNo to set
	 */
	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the claimCode
	 */
	public String getClaimCode() {
		return claimCode;
	}

	/**
	 * @param claimCode the claimCode to set
	 */
	public void setClaimCode(String claimCode) {
		this.claimCode = claimCode;
	}

	/**
	 * @return the claimYear
	 */
	public int getClaimYear() {
		return claimYear;
	}

	/**
	 * @param claimYear the claimYear to set
	 */
	public void setClaimYear(int claimYear) {
		this.claimYear = claimYear;
	}

	/**
	 * @return the claimAmount
	 */
	public double getClaimAmount() {
		return claimAmount;
	}

	/**
	 * @param claimAmount the claimAmount to set
	 */
	public void setClaimAmount(double claimAmount) {
		this.claimAmount = claimAmount;
	}

	/**
	 * @return the approvedAmount
	 */
	public double getApprovedAmount() {
		return approvedAmount;
	}

	/**
	 * @param approvedAmount the approvedAmount to set
	 */
	public void setApprovedAmount(double approvedAmount) {
		this.approvedAmount = approvedAmount;
	}

	/**
	 * @return the eligibilityAmount
	 */
	public double getEligibilityAmount() {
		return eligibilityAmount;
	}

	/**
	 * @param eligibilityAmount the eligibilityAmount to set
	 */
	public void setEligibilityAmount(double eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	/**
	 * @return the requestorId
	 */
	public String getRequestorId() {
		return requestorId;
	}

	/**
	 * @param requestorId the requestorId to set
	 */
	public void setRequestorId(String requestorId) {
		this.requestorId = requestorId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the sendTo
	 */
	public String getSendTo() {
		return sendTo;
	}

	/**
	 * @param sendTo the sendTo to set
	 */
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	/**
	 * @return the operation
	 */
	public String getOperation() {
		return operation;
	}

	/**
	 * @param operation the operation to set
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AnnualTrvlAlwnceDTO [documentSerialNo=" + documentSerialNo + ", employeeId=" + employeeId
				+ ", employeeName=" + employeeName + ", claimCode=" + claimCode + ", claimYear=" + claimYear
				+ ", claimAmount=" + claimAmount + ", approvedAmount=" + approvedAmount + ", eligibilityAmount="
				+ eligibilityAmount + ", requestorId=" + requestorId + ", status=" + status + ", sendTo=" + sendTo
				+ ", operation=" + operation + "]";
	}
	
	
}
