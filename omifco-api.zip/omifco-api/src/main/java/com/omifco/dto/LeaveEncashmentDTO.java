package com.omifco.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Leave Data Transfer Object.
 * 
 * @author Prolifics.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LeaveEncashmentDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	/**
	 * The Employee Id.
	 */
	private String employeeId;
	/**
	 * The Employee Name.
	 */
	private String employeeName;
	/**
	 * The Employee Role.
	 */
	private String employeeRole;
	/**
	 * The Encashment Number.
	 */
	private String encashmentNo;
	/**
	 * The Number of days.
	 */
	private double encashmentDays;
	/**
	 * Type of Leave like - Annual Leave, Sick Leave etc.
	 */
	private String leaveType;
	/**
	 * Send to - next level approver.
	 */
	private String sendTo;
	/**
	 * Current status of leave encashment request.
	 */
	private String leaveEncashmentStatus ;
	/**
	 * The Amount.
	 */
	private double encashmentAmount;
	/**
	 * The Operation to perform like Apply, Cancel or Approve.
	 */
	private String operation;
	/**
	 * Remarks
	 */
	private String remarks ;
	/**
	 * Document Number for the applied leave.
	 */
	private String docNumber;
	/**
	 * Id of the employee who is performing current action.
	 */
	private String requestorId ;
	/**
	 * Payment Date.
	 */
	private Date paymentDate ;
	/**
	 * Payment Mode.
	 */
	private String paymentMode ;
	/**
	 * Salary Month.
	 */
	private String salaryMonth ;
	/**
	 * Salary Month.
	 */
	private boolean salaryProcessed ;
	/**
	 * Remarks
	 */
	private List<RemarksDTO> approverRemarks ;
	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}
	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	/**
	 * @return the employeeRole
	 */
	public String getEmployeeRole() {
		return employeeRole;
	}
	/**
	 * @param employeeRole the employeeRole to set
	 */
	public void setEmployeeRole(String employeeRole) {
		this.employeeRole = employeeRole;
	}
	/**
	 * @return the encashmentNo
	 */
	public String getEncashmentNo() {
		return encashmentNo;
	}
	/**
	 * @param encashmentNo the encashmentNo to set
	 */
	public void setEncashmentNo(String encashmentNo) {
		this.encashmentNo = encashmentNo;
	}
	/**
	 * @return the encashmentDays
	 */
	public double getEncashmentDays() {
		return encashmentDays;
	}
	/**
	 * @param encashmentDays the encashmentDays to set
	 */
	public void setEncashmentDays(double encashmentDays) {
		this.encashmentDays = encashmentDays;
	}
	/**
	 * @return the leaveType
	 */
	public String getLeaveType() {
		return leaveType;
	}
	/**
	 * @param leaveType the leaveType to set
	 */
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	/**
	 * @return the sendTo
	 */
	public String getSendTo() {
		return sendTo;
	}
	/**
	 * @param sendTo the sendTo to set
	 */
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}
	/**
	 * @return the leaveEncashmentStatus
	 */
	public String getLeaveEncashmentStatus() {
		return leaveEncashmentStatus;
	}
	/**
	 * @param leaveEncashmentStatus the leaveEncashmentStatus to set
	 */
	public void setLeaveEncashmentStatus(String leaveEncashmentStatus) {
		this.leaveEncashmentStatus = leaveEncashmentStatus;
	}
	/**
	 * @return the encashmentAmount
	 */
	public double getEncashmentAmount() {
		return encashmentAmount;
	}
	/**
	 * @param encashmentAmount the encashmentAmount to set
	 */
	public void setEncashmentAmount(double encashmentAmount) {
		this.encashmentAmount = encashmentAmount;
	}
	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	/**
	 * @return the approverRemarks
	 */
	public List<RemarksDTO> getApproverRemarks() {
		return approverRemarks;
	}
	/**
	 * @param approverRemarks the approverRemarks to set
	 */
	public void setApproverRemarks(List<RemarksDTO> approverRemarks) {
		this.approverRemarks = approverRemarks;
	}
	/**
	 * @return the operation
	 */
	public String getOperation() {
		return operation;
	}
	/**
	 * @param operation the operation to set
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}
	/**
	 * @return the docNumber
	 */
	public String getDocNumber() {
		return docNumber;
	}
	/**
	 * @param docNumber the docNumber to set
	 */
	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}	
	
	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}
	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	/**
	 * @return the requestorId
	 */
	public String getRequestorId() {
		return requestorId;
	}
	/**
	 * @param requestorId the requestorId to set
	 */
	public void setRequestorId(String requestorId) {
		this.requestorId = requestorId;
	}
	
	/**
	 * @return the paymentDate
	 */
	public Date getPaymentDate() {
		return paymentDate;
	}
	/**
	 * @param paymentDate the paymentDate to set
	 */
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	/**
	 * @return the paymentMode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}
	/**
	 * @param paymentMode the paymentMode to set
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	/**
	 * @return the salaryMonth
	 */
	public String getSalaryMonth() {
		return salaryMonth;
	}
	/**
	 * @param salaryMonth the salaryMonth to set
	 */
	public void setSalaryMonth(String salaryMonth) {
		this.salaryMonth = salaryMonth;
	}
	/**
	 * @return the salaryProcessed
	 */
	public boolean isSalaryProcessed() {
		return salaryProcessed;
	}
	/**
	 * @param salaryProcessed the salaryProcessed to set
	 */
	public void setSalaryProcessed(boolean salaryProcessed) {
		this.salaryProcessed = salaryProcessed;
	}
	
	@Override
	public String toString() {
		return "LeaveEncashmentDTO [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeRole="
				+ employeeRole + ", encashmentNo=" + encashmentNo + ", encashmentDays=" + encashmentDays
				+ ", leaveType=" + leaveType + ", sendTo=" + sendTo + ", leaveEncashmentStatus=" + leaveEncashmentStatus
				+ ", encashmentAmount=" + encashmentAmount + ", operation=" + operation + ", remarks=" + remarks
				+ ", docNumber=" + docNumber + ", requestorId=" + requestorId + ", paymentDate=" + paymentDate
				+ ", paymentMode=" + paymentMode + ", salaryMonth=" + salaryMonth + ", salaryProcessed="
				+ salaryProcessed + ", approverRemarks=" + approverRemarks + "]";
	}
	
}
