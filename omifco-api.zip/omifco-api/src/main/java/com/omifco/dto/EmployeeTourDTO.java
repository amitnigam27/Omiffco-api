package com.omifco.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class EmployeeTourDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String employeeId;
	/**
	 * The Employee Name.
	 */
	private String employeeName;
	
	private String stationFrom;
	
	private Date departureDate;
	
	private Date departureTime;
	
	private String stationTo;
	
	private Date arrivalDate;
	
	private Date arrivalTime;
	
	private String travelMode;
	
	private String tourType;
	
	private String tourPurpose;
	
	private Date leaveFrom;
	
	private String requestorId;
	
	private Date leaveTo;
	
	private String remarks;
	
	private int documentSerialNumber;
	
	private String status;
	/**
	 * Remarks
	 */
	private List<RemarksDTO> approverRemarks ;
	
	/**
	 * Send to - next level approver.
	 */
	private String sendTo;
	
	/**
	 * The Operation to perform like Apply, Cancel or Approve.
	 */
	private String operation;

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getStationFrom() {
		return stationFrom;
	}

	public void setStationFrom(String stationFrom) {
		this.stationFrom = stationFrom;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}

	public String getStationTo() {
		return stationTo;
	}

	public void setStationTo(String stationTo) {
		this.stationTo = stationTo;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public Date getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getTravelMode() {
		return travelMode;
	}

	public void setTravelMode(String travelMode) {
		this.travelMode = travelMode;
	}
	
	public String getTourType() {
		return tourType;
	}

	public void setTourType(String tourType) {
		this.tourType = tourType;
	}

	public String getTourPurpose() {
		return tourPurpose;
	}

	public void setTourPurpose(String tourPurpose) {
		this.tourPurpose = tourPurpose;
	}

	public Date getLeaveFrom() {
		return leaveFrom;
	}

	public void setLeaveFrom(Date leaveFrom) {
		this.leaveFrom = leaveFrom;
	}

	public Date getLeaveTo() {
		return leaveTo;
	}

	public void setLeaveTo(Date leaveTo) {
		this.leaveTo = leaveTo;
	}

	public String getSendTo() {
		return sendTo;
	}

	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getRequestorId() {
		return requestorId;
	}

	public void setRequestorId(String requestorId) {
		this.requestorId = requestorId;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the documentSerialNumber
	 */
	public int getDocumentSerialNumber() {
		return documentSerialNumber;
	}

	/**
	 * @param documentSerialNumber the documentSerialNumber to set
	 */
	public void setDocumentSerialNumber(int documentSerialNumber) {
		this.documentSerialNumber = documentSerialNumber;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the approverRemarks
	 */
	public List<RemarksDTO> getApproverRemarks() {
		return approverRemarks;
	}

	/**
	 * @param approverRemarks the approverRemarks to set
	 */
	public void setApproverRemarks(List<RemarksDTO> approverRemarks) {
		this.approverRemarks = approverRemarks;
	}

	@Override
	public String toString() {
		return "EmployeeTourDTO [employeeId=" + employeeId + ", employeeName=" + employeeName + ", stationFrom="
				+ stationFrom + ", departureDate=" + departureDate + ", departureTime=" + departureTime + ", stationTo="
				+ stationTo + ", arrivalDate=" + arrivalDate + ", arrivalTime=" + arrivalTime + ", travelMode="
				+ travelMode + ", tourType=" + tourType + ", tourPurpose=" + tourPurpose + ", leaveFrom=" + leaveFrom
				+ ", requestorId=" + requestorId + ", leaveTo=" + leaveTo + ", remarks=" + remarks
				+ ", documentSerialNumber=" + documentSerialNumber + ", status=" + status + ", approverRemarks="
				+ approverRemarks + ", sendTo=" + sendTo + ", operation=" + operation + "]";
	}
	
	
}
