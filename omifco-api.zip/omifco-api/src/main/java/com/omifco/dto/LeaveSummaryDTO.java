package com.omifco.dto;

import java.io.Serializable;

public class LeaveSummaryDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	/**
	 * Holds no. of Approved Leaves.
	 */
	private double approvedLeaves;
	/**
	 * Holds no. of Pending Leaves.
	 */
	private double pendingLeaves;
	/**
	 * Holds no. of Annual. Leaves.
	 */
	private double annualLeaves;
	/**
	 * Holds no. of Emergency Leaves.
	 */
	private double emergencyLeaves;
	/**
	 * Holds no. of Sick Leaves.
	 */
	private double sickLeaves;
	/**
	 * Holds no. of Total Leave Balance.
	 */
	private double totalLeaveBalance;
	/**
	 * Holds no. of Total Encashable Leave Balance.
	 */
	private double totalEncashableLeaves;
	/**
	 * Holds no. of Total Accrued Leave Balance.
	 */
	private double totalAccruedLeaves;
	/**
	 * Holds no. of New/Opening Encashable Leave Balance.
	 */
	private double newEncashableLeaves;
	/**
	 * Holds no. of Encashed Days.
	 */
	private double encashedDays;
	
	/**
	 * 
	 */
	public LeaveSummaryDTO() {
		super();
	}

	/**
	 * @return the approvedLeaves
	 */
	public double getApprovedLeaves() {
		return approvedLeaves;
	}

	/**
	 * @param approvedLeaves the approvedLeaves to set
	 */
	public void setApprovedLeaves(double approvedLeaves) {
		this.approvedLeaves = approvedLeaves;
	}

	/**
	 * @return the pendingLeaves
	 */
	public double getPendingLeaves() {
		return pendingLeaves;
	}

	/**
	 * @param pendingLeaves the pendingLeaves to set
	 */
	public void setPendingLeaves(double pendingLeaves) {
		this.pendingLeaves = pendingLeaves;
	}

	/**
	 * @return the annualLeaves
	 */
	public double getAnnualLeaves() {
		return annualLeaves;
	}

	/**
	 * @param annualLeaves the annualLeaves to set
	 */
	public void setAnnualLeaves(double annualLeaves) {
		this.annualLeaves = annualLeaves;
	}

	/**
	 * @return the emergencyLeaves
	 */
	public double getEmergencyLeaves() {
		return emergencyLeaves;
	}

	/**
	 * @param emergencyLeaves the emergencyLeaves to set
	 */
	public void setEmergencyLeaves(double emergencyLeaves) {
		this.emergencyLeaves = emergencyLeaves;
	}

	/**
	 * @return the sickLeaves
	 */
	public double getSickLeaves() {
		return sickLeaves;
	}

	/**
	 * @param sickLeaves the sickLeaves to set
	 */
	public void setSickLeaves(double sickLeaves) {
		this.sickLeaves = sickLeaves;
	}

	/**
	 * @return the totalLeaveBalance
	 */
	public double getTotalLeaveBalance() {
		return totalLeaveBalance;
	}

	/**
	 * @param totalLeaveBalance the totalLeaveBalance to set
	 */
	public void setTotalLeaveBalance(double totalLeaveBalance) {
		this.totalLeaveBalance = totalLeaveBalance;
	}

	/**
	 * @return the totalEncashableLeaves
	 */
	public double getTotalEncashableLeaves() {
		return totalEncashableLeaves;
	}

	/**
	 * @param totalEncashableLeaves the totalEncashableLeaves to set
	 */
	public void setTotalEncashableLeaves(double totalEncashableLeaves) {
		this.totalEncashableLeaves = totalEncashableLeaves;
	}

	/**
	 * @return the totalAccruedLeaves
	 */
	public double getTotalAccruedLeaves() {
		return totalAccruedLeaves;
	}

	/**
	 * @param totalAccruedLeaves the totalAccruedLeaves to set
	 */
	public void setTotalAccruedLeaves(double totalAccruedLeaves) {
		this.totalAccruedLeaves = totalAccruedLeaves;
	}

	/**
	 * @return the newEncashableLeaves
	 */
	public double getNewEncashableLeaves() {
		return newEncashableLeaves;
	}

	/**
	 * @param newEncashableLeaves the newEncashableLeaves to set
	 */
	public void setNewEncashableLeaves(double newEncashableLeaves) {
		this.newEncashableLeaves = newEncashableLeaves;
	}
	
	/**
	 * @return the encashedDays
	 */
	public double getEncashedDays() {
		return encashedDays;
	}

	/**
	 * @param encashedDays the encashedDays to set
	 */
	public void setEncashedDays(double encashedDays) {
		this.encashedDays = encashedDays;
	}

	@Override
	public String toString() {
		return "LeaveSummaryDTO [approvedLeaves=" + approvedLeaves + ", pendingLeaves=" + pendingLeaves
				+ ", annualLeaves=" + annualLeaves + ", emergencyLeaves=" + emergencyLeaves + ", sickLeaves="
				+ sickLeaves + ", totalLeaveBalance=" + totalLeaveBalance + ", totalEncashableLeaves="
				+ totalEncashableLeaves + ", totalAccruedLeaves=" + totalAccruedLeaves + ", newEncashableLeaves="
				+ newEncashableLeaves + ", encashedDays=" + encashedDays + "]";
	}
	
}
