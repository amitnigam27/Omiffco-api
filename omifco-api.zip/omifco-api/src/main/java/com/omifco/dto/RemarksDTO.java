package com.omifco.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Remarks Data Transfer Object.
 * 
 * @author Prolifics.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RemarksDTO implements Serializable{
	private static final long serialVersionUID = 1L;

	/**
	 * The Approver	Name.
	 */
	private String approverName;
	/**
	 * The Approver Remarks.
	 */
	private String approverRemarks;
	
	/**
	 * Empty Constructor.
	 */
	public RemarksDTO(){		
	}
	
	/**
	 * Parameterized Constructor.
	 */
	public RemarksDTO(String approverName, String approverRemarks){
		this.approverName		= approverName;
		this.approverRemarks	= approverRemarks;
	}

	/**
	 * @return the approverName
	 */
	public String getApproverName() {
		return approverName;
	}

	/**
	 * @param approverName the approverName to set
	 */
	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}

	/**
	 * @return the approverRemarks
	 */
	public String getApproverRemarks() {
		return approverRemarks;
	}

	/**
	 * @param approverRemarks the approverRemarks to set
	 */
	public void setApproverRemarks(String approverRemarks) {
		this.approverRemarks = approverRemarks;
	}

	@Override
	public String toString() {
		return "RemarksDTO [approverName=" + approverName + ", approverRemarks=" + approverRemarks + "]";
	}

}
