package com.omifco.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ExcessBaggageClaimDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	/**
	 * The Employee Id.
	 */
	private String employeeId;
	/**
	 * The Employee Name.
	 */
	private String employeeName;
	 
	/**
	 * Id of the employee who is performing current action.
	 */
	private String requestorId ;
	
	/***
	 * Status
	 */
	private String status;
	
	private String claimsCode;
	
	private String claimsYear;
	
	private String currencyCode;
	
	private double currencyRate;
	
	private int excessWeight;
	 
	private int claimAmount;
	
	private int receiptNo;
		
	/**
	 * Document Number for the applied Claim.
	 */
	private String docNumber;
	 
	private Date receiptDate;
	
	private String operation;
	
	private String sendTo;
	
	
	
	
	
	


	public String getDocNumber() {
		return docNumber;
	}


	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}


	public String getSendTo() {
		return sendTo;
	}


	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}


	public String getOperation() {
		return operation;
	}


	public void setOperation(String operation) {
		this.operation = operation;
	}


	public String getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public String getRequestorId() {
		return requestorId;
	}


	public void setRequestorId(String requestorId) {
		this.requestorId = requestorId;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getClaimsCode() {
		return claimsCode;
	}


	public void setClaimsCode(String claimsCode) {
		this.claimsCode = claimsCode;
	}


	public String getClaimsYear() {
		return claimsYear;
	}


	public void setClaimsYear(String claimsYear) {
		this.claimsYear = claimsYear;
	}


	public String getCurrencyCode() {
		return currencyCode;
	}


	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}


	public double getCurrencyRate() {
		return currencyRate;
	}


	public void setCurrencyRate(double currencyRate) {
		this.currencyRate = currencyRate;
	}


	public int getExcessWeight() {
		return excessWeight;
	}


	public void setExcessWeight(int excessWeight) {
		this.excessWeight = excessWeight;
	}


	public int getClaimAmount() {
		return claimAmount;
	}


	public void setClaimAmount(int claimAmount) {
		this.claimAmount = claimAmount;
	}


	public int getReceiptNo() {
		return receiptNo;
	}


	public void setReceiptNo(int receiptNo) {
		this.receiptNo = receiptNo;
	}


	public Date getReceiptDate() {
		return receiptDate;
	}


	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}


	@Override
	public String toString() {
		return "ExcessBaggageClaimDTO [employeeId=" + employeeId + ", employeeName=" + employeeName + ", requestorId="
				+ requestorId + ", status=" + status + ", claimsCode=" + claimsCode + ", claimsYear=" + claimsYear
				+ ", currencyCode=" + currencyCode + ", currencyRate=" + currencyRate + ", excessWeight=" + excessWeight
				+ ", claimAmount=" + claimAmount + ", receiptNo=" + receiptNo + ", docNumber=" + docNumber
				+ ", receiptDate=" + receiptDate + ", operation=" + operation + ", sendTo=" + sendTo + "]";
	}


	


	


	


	


	
	
	

}
