package com.omifco.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Leave Data Transfer Object.
 * 
 * @author Prolifics.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LeaveDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	/**
	 * The Employee Id.
	 */
	private String employeeId;
	/**
	 * The Employee Name.
	 */
	private String employeeName;
	/**
	 * Type of Leave like - Annual Leave, Sick Leave etc.
	 */
	private String leaveType;
	/**
	 * The reason of the Leave Request.
	 */
	private String leavePurpose;
	/**
	 * Leave Start Date.
	 */
	private Date fromDate;
	/**
	 * Leave End Date.
	 */
	private Date toDate;
	/**
	 * Leave Flag - Half Pay/Full Pay.
	 */
	private int leaveFlag;
	/**
	 * Send to - next level approver.
	 */
	private String sendTo;
	/**
	 * The Operation to perform like Apply, Cancel or Approve.
	 */
	private String operation;
	/**
	 * Document Number for the applied leave.
	 */
	private String docNumber;
	/**
	 * Id of the employee who is performing current action.
	 */
	private String requestorId ;
	/**
	 * Current status of leave.
	 */
	private String leaveStatus ;
	/**
	 * Remarks
	 */
	private String remarks ;
	/**
	 * Remarks
	 */
	private List<RemarksDTO> approverRemarks ;

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}
	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}
	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	/**
	 * @return the leaveType
	 */
	public String getLeaveType() {
		return leaveType;
	}
	/**
	 * @param leaveType the leaveType to set
	 */
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	/**
	 * @return the leavePurpose
	 */
	public String getLeavePurpose() {
		return leavePurpose;
	}
	/**
	 * @param leavePurpose the leavePurpose to set
	 */
	public void setLeavePurpose(String leavePurpose) {
		this.leavePurpose = leavePurpose;
	}
	/**
	 * @return the fromDate
	 */
	public Date getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	/**
	 * @return the toDate
	 */
	public Date getToDate() {
		return toDate;
	}
	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	/**
	 * @return the leaveFlag
	 */
	public int getLeaveFlag() {
		return leaveFlag;
	}
	/**
	 * @param leaveFlag the leaveFlag to set
	 */
	public void setLeaveFlag(int leaveFlag) {
		this.leaveFlag = leaveFlag;
	}
	/**
	 * @return the sendTo
	 */
	public String getSendTo() {
		return sendTo;
	}
	/**
	 * @param sendTo the sendTo to set
	 */
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}
	/**
	 * @return the operation
	 */
	public String getOperation() {
		return operation;
	}
	/**
	 * @return the docNumber
	 */
	public String getDocNumber() {
		return docNumber;
	}
	/**
	 * @param docNumber the docNumber to set
	 */
	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}
	/**
	 * @param operation the operation to set
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}
	/**
	 * @return the requestorId
	 */
	public String getRequestorId() {
		return requestorId;
	}
	/**
	 * @param requestorId the requestorId to set
	 */
	public void setRequestorId(String requestorId) {
		this.requestorId = requestorId;
	}
	/**
	 * @return the leaveStatus
	 */
	public String getLeaveStatus() {
		return leaveStatus;
	}
	/**
	 * @param leaveStatus the leaveStatus to set
	 */
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}
	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	/**
	 * @return the approverRemarks
	 */
	public List<RemarksDTO> getApproverRemarks() {
		return approverRemarks;
	}
	/**
	 * @param approverRemarks the approverRemarks to set
	 */
	public void setApproverRemarks(List<RemarksDTO> approverRemarks) {
		this.approverRemarks = approverRemarks;
	}
	@Override
	public String toString() {
		return "LeaveDTO [employeeId=" + employeeId + ", leaveType=" + leaveType + ", leavePurpose=" + leavePurpose
				+ ", fromDate=" + fromDate + ", toDate=" + toDate + ", leaveFlag=" + leaveFlag + ", sendTo=" + sendTo
				+ ", operation=" + operation + ", docNumber=" + docNumber + ", requestorId=" + requestorId
				+ ", leaveStatus=" + leaveStatus + ", remarks=" + remarks + ", approverRemarks=" + approverRemarks
				+ "]";
	}
		
}
