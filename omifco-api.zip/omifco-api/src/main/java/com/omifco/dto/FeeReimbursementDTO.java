package com.omifco.dto;

import java.io.Serializable;

public class FeeReimbursementDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private String employeeId;
	
	private String employeeName;

	private int claimYear;

	private int claimsSrNumber;	
	
	private double feePaid;

	private String requestorId;
	/**
	 * Send to - next level approver.
	 */
	private String sendTo;

	private String dependentName;
	/**
	 * The Operation to perform like Apply, Cancel or Approve.
	 */
	private String operation;

	private double claimedAmount;

	private int dependentSerialNo;
	
	private String status;

	

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}



	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}



	/**
	 * @return the claimYear
	 */
	public int getClaimYear() {
		return claimYear;
	}



	/**
	 * @param claimYear the claimYear to set
	 */
	public void setClaimYear(int claimYear) {
		this.claimYear = claimYear;
	}



	/**
	 * @return the claimsSrNumber
	 */
	public int getClaimsSrNumber() {
		return claimsSrNumber;
	}



	/**
	 * @param claimsSrNumber the claimsSrNumber to set
	 */
	public void setClaimsSrNumber(int claimsSrNumber) {
		this.claimsSrNumber = claimsSrNumber;
	}



	/**
	 * @return the feePaid
	 */
	public double getFeePaid() {
		return feePaid;
	}



	/**
	 * @param feePaid the feePaid to set
	 */
	public void setFeePaid(double feePaid) {
		this.feePaid = feePaid;
	}



	/**
	 * @return the requestorId
	 */
	public String getRequestorId() {
		return requestorId;
	}



	/**
	 * @param requestorId the requestorId to set
	 */
	public void setRequestorId(String requestorId) {
		this.requestorId = requestorId;
	}



	/**
	 * @return the dependentName
	 */
	public String getDependentName() {
		return dependentName;
	}



	/**
	 * @param dependentName the dependentName to set
	 */
	public void setDependentName(String dependentName) {
		this.dependentName = dependentName;
	}



	/**
	 * @return the operation
	 */
	public String getOperation() {
		return operation;
	}



	/**
	 * @param operation the operation to set
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}



	/**
	 * @return the claimedAmount
	 */
	public double getClaimedAmount() {
		return claimedAmount;
	}



	/**
	 * @param claimedAmount the claimedAmount to set
	 */
	public void setClaimedAmount(double claimedAmount) {
		this.claimedAmount = claimedAmount;
	}



	/**
	 * @return the dependentSerialNo
	 */
	public int getDependentSerialNo() {
		return dependentSerialNo;
	}



	/**
	 * @param dependentSerialNo the dependentSerialNo to set
	 */
	public void setDependentSerialNo(int dependentSerialNo) {
		this.dependentSerialNo = dependentSerialNo;
	}

	/**
	 * @return the sendTo
	 */
	public String getSendTo() {
		return sendTo;
	}

	/**
	 * @param sendTo the sendTo to set
	 */
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	@Override
	public String toString() {
		return "FeeReimbursementDTO [employeeId=" + employeeId + ", employeeName=" + employeeName + ", claimYear="
				+ claimYear + ", claimsSrNumber=" + claimsSrNumber + ", feePaid=" + feePaid + ", requestorId="
				+ requestorId + ", sendTo=" + sendTo + ", dependentName=" + dependentName + ", operation=" + operation
				+ ", claimedAmount=" + claimedAmount + ", dependentSerialNo=" + dependentSerialNo + ", status=" + status
				+ "]";
	}

}
