package com.omifco.messages.constants;

public interface MessageConstants {

	public static final String LOGIN_SUCCESS_CODE = "AUT_000";
	public static final String LOGIN_FAILURE_CODE = "AUT_001";
	public static final String LOGIN_FAILURE_MSG = "Invalid Credentials! Please try again.";
	
	public static final String MISSING_OPERATION_CODE = "LV_001";
	public static final String INSUFFICENT_LEAVE_CODE = "LVE_001";
	public static final String INSUFFICENT_ANNUAL_LEAVE_CODE = "LVE_002";
	public static final String INSUFFICENT_SICK_LEAVE_CODE = "LVE_003";
	public static final String INSUFFICENT_EMERGENCY_LEAVE_CODE = "LVE_004";
	public static final String EMERGENCY_LEAVE_LIMIT_CODE = "LVE_005";
	
	public static final String MISSING_OPERATION_MSG = "Operation Missing!1";
	public static final String INSUFFICENT_LEAVE_MSG = "Insufficient Leave Balance";
	public static final String INSUFFICENT_ANNUAL_LEAVE_MSG = "Your Annual leave balance is not sufficient.";
	public static final String INSUFFICENT_SICK_LEAVE_MSG = "Your Sick leave balance is not sufficient.";
	public static final String INSUFFICENT_EMERGENCY_LEAVE_MSG = "Your Emergency leave balance is not sufficient.";
	public static final String EMERGENCY_LEAVE_LIMIT_MSG = "You can't apply Emergency leave for more than 2 days.";
	
	public static final String LEAVE_APPLIED_CODE = "LVM_100"; 
	public static final String LEAVE_RECOMMENDED_CODE = "LVM_101";
	public static final String LEAVE_APPROVED_CODE = "LVM_102";
	public static final String LEAVE_ACCEPTED_CODE = "LVM_103";
	public static final String LEAVE_CANCELLED_CODE = "LVM_104";
	public static final String LEAVE_REJECTED_CODE = "LVM_105";
	
	public static final String LEAVE_APPLIED_MSG = "Leave Applied Successfully.";
	public static final String LEAVE_RECOMMENDED_MSG = "Leave Recommended Successfully.";
	public static final String LEAVE_APPROVED_MSG = "Leave Approved Successfully.";
	public static final String LEAVE_ACCEPTED_MSG = "Leave Accepted Successfully.";
	public static final String LEAVE_CANCELLED_MSG = "Leave Cancelled Successfully.";
	public static final String LEAVE_REJECTED_MSG = "Leave Rejected Successfully.";
	
	public static final String INVALID_LOOKUP_TYPE_CODE = "LOK_100";
	public static final String NO_REQUEST_FOUND = "NRQ_100";
	public static final String NO_REMINDERS_FOUND = "NRM_100";
	public static final String SOMETHING_WENT_WRONG = "SMT_100";
	public static final String NO_APPROVERS_FOUND = "NAP_100";
	public static final String NO_USER_EXIST = "NUS_100";
	public static final String PROFILE_UPDATED_CODE = "USR_100";
	public static final String PASSWORD_UPDATED_CODE = "USR_100";
	public static final String INVALID_OLD_PASS_CODE = "INP_100";
	public static final String TOKEN_UPDATED_CODE = "TOK_100";
	
	public static final String INVALID_LOOKUP_TYPE_MSG = "Invalid lookup type.";
	public static final String NO_REQUEST_FOUND_MSG = "No request found.";
	public static final String NO_REMINDERS_FOUND_MSG = "No reminders found.";
	public static final String SOMETHING_WENT_WRONG_MSG = "Something went wrong.";
	public static final String NO_APPROVERS_FOUND_MSG = "No approvers found.";
	public static final String NO_USER_EXIST_MSG = "No such user exist.";
	public static final String PROFILE_UPDATED_MSG = "Your profile has been updated successfully.";
	public static final String PASSWORD_UPDATED_MSG = "Your password has been updated.";
	public static final String INVALID_OLD_PASS_MSG = "Invalid old password.";
	public static final String TOKEN_UPDATED_MSG = "Device token has been updated successfully.";
	
	public static final String ENCASHMENT_SUBMITTION_CODE = "ENC_100";
	public static final String ENCASHMENT_RECOMMENDED_CODE = "ENC_101";
	public static final String ENCASHMENT_ACCEPTED_CODE = "ENC_102";
	public static final String ENCASHMENT_REJECTED_CODE = "ENC_103";
	public static final String ENCASHMENT_SUBMITTION_MSG = "Your leave encashment request has been submitted successfully.";
	public static final String ENCASHMENT_RECOMMENDED_MSG = "Encashment request Recommended successfully.";
	public static final String ENCASHMENT_ACCEPTED_MSG = "Encashment request Accepted successfully.";
	public static final String ENCASHMENT_REJECTED_MSG = "Encashment request Rejected successfully.";
	
	public static final String FEE_REIMBURSEMENT_MSG = "Reimbursement Applied Successfully.";
	public static final String REIMBURSE_REJECTED_MSG = "Reimburse Rejected Successfully.";
	public static final String REIMBURSE_RECOMMENDED_MSG = "Reimburse Recommended Successfully.";
	public static final String REIMBURSE_ACCEPTED_MSG = "Reimburse Accepted Successfully.";
	public static final String REIMBURSE_AMOUNTERROR_MSG = "Reimburseed Amount is greater than Maximum Admisible Amount";
	public static final String REIMBURSE_YEARERROR_MSG = "You have already submitted a reimbursement for this year";
	public static final String REIMBURSE_RECOMMENDED_CODE = "RMB_101";
	public static final String REIMBURSE_APPLIED_CODE = "RMB_100";
	public static final String REIMBURSE_REJECTED_CODE = "RMB_105";
	public static final String REIMBURSE_ACCEPTED_CODE = "RMB_103";
	public static final String REIMBURSE_AMOUNTERROR_CODE = "RMB_102";
	public static final String REIMBURSE_YEARERROR_CODE = "RMB_104";
	
	public static final String EMP_TOUR_APPLIED_CODE = "EMT_100";
	public static final String EMP_TOUR_RECOMMENDED_CODE = "EMT_101";
	public static final String EMP_TOUR_APPROVED_CODE = "EMT_102";
	public static final String EMP_TOUR_ACCEPTED_CODE = "EMT_103";
	public static final String EMP_TOUR_CANCELLED_CODE = "EMT_104";
	public static final String EMP_TOUR_REJECTED_CODE = "EMT_105";
	public static final String EMP_TOUR_APPLIED_MSG = "Tour Applied Successfully.";
	public static final String EMP_TOUR_RECOMMENDED_MSG = "Tour Recommended Successfully.";
	public static final String EMP_TOUR_APPROVED_MSG = "Tour Approved Successfully.";
	public static final String EMP_TOUR_ACCEPTED_MSG = "Tour Accepted Successfully.";
	public static final String EMP_TOUR_CANCELLED_MSG = "Tour Cancelled Successfully.";
	public static final String EMP_TOUR_REJECTED_MSG = "Tour Rejected Successfully.";
	
	public static final String ANNUAL_TRVL_APPLIED_CODE = "ATA_100";
	public static final String ANNUAL_TRVL_RECOMMENDED_CODE = "ATA_101";
	public static final String ANNUAL_TRVL_ACCEPTED_CODE = "ATA_102";
	public static final String ANNUAL_TRVL_CANCELLED_CODE = "ATA_103";
	public static final String ANNUAL_TRVL_REJECTED_CODE = "ATA_104";
	public static final String ANNUAL_TRVL_AMOUNT_ERROR_CODE = "ATA_105";
	public static final String ANNUAL_TRVL_APPLIED_MSG = "Annual travel allowance request applied successfully.";
	public static final String ANNUAL_TRVL_RECOMMENDED_MSG = "Annual travel allowance request recommended successfully.";
	public static final String ANNUAL_TRVL_ACCEPTED_MSG = "Annual travel allowance request accepted successfully.";
	public static final String ANNUAL_TRVL_CANCELLED_MSG = "Annual travel allowance request cancelled successfully.";
	public static final String ANNUAL_TRVL_REJECTED_MSG = "Annual travel allowance request rejected successfully.";
	public static final String ANNUAL_TRVL_AMOUNT_ERROR_MSG = "Claimed Amount cannot exceed Eligible Amount";


	public static final String BAGGAGE_CLAIM_SUBMITTION_CODE = "EBC_100";
	public static final String BAGGAGE_CLAIM_RECOMMENDED_CODE = "EBC_101";
	public static final String BAGGAGE_CLAIM_ACCEPTED_CODE = "EBC_102";
	public static final String BAGGAGE_CLAIM_REJECTED_CODE = "ENC_103";
	public static final String BAGGAGE_CLAIM_SUBMITTION_MSG = "Your excess Baggage claim request has been submitted successfully.";
	public static final String BAGGAGE_CLAIM_RECOMMENDED_MSG = "Your excess Baggage claim request Recommended successfully.";
	public static final String BAGGAGE_CLAIM_ACCEPTED_MSG = "Your excess Baggage claim request Accepted Successfully.";
	public static final String BAGGAGE_CLAIM_REJECTED_MSG = "Encashment request Rejected successfully.";
	
	public static final String MED_BILL_REIMB_APPLIED_CODE = "MBR_100";
	public static final String MED_BILL_REIMB_RECOMMENDED_CODE = "MBR_101";
	public static final String MED_BILL_REIMB_APPROVED_CODE = "MBR_102";	
	public static final String MED_BILL_REIMB_SENT_TO_FINANCE_CODE = "MBR_103";
	public static final String MED_BILL_REIMB_REJECTED_CODE ="MBR_104";
	public static final String MED_BILL_REIMB_AMOUNT_ERROR_CODE = "MBR_105";
	public static final String MED_BILL_REIMB_APPLIED_MSG = "Medical bill reimbursement request applied successfully.";
	public static final String MED_BILL_REIMB_RECOMMENDED_MSG ="Medical bill reimbursement request recommended successfully.";
	public static final String MED_BILL_REIMB_APPROVED_MSG = "Medical bill reimbursement request approved successfully.";
	public static final String MED_BILL_REIMB_SENT_TO_FINANCE_MSG = "Medical bill reimbursement request sent to finance successfully.";
	public static final String MED_BILL_REIMB_REJECTED_MSG ="Medical bill reimbursement request rejected successfully.";
	public static final String MED_BILL_REIMB_AMOUNT_ERROR_MSG = "Claimed Amount cannot exceed Eligible Amount";
}
