/**
 * 
 */
package com.omifco.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.omifco.dto.AnnualTrvlAlwnceDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.service.AnnualTrvlAlwnceService;
import com.omifco.service.UtilService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author Anigam
 *
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/annual-travel-allowance")
@Tag(name = "AnnualTravelAllowance", description = "Annual Travel Allowance API")
public class AnnualTrvlAlwnceController {

	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	@Autowired
	AnnualTrvlAlwnceService annualTrvlAlwnceService;
	
	@Autowired
	UtilService utilService;
	
	/**
	 * ping method is used to validate the connectivity
	 * of the API.
	 */
	@Operation(summary = "Validates the heart-beat of the API.", description = "Pings the API and check if its up and running.", tags = { "AnnualTravelAllowance" })
	@RequestMapping(method=RequestMethod.GET)
	public @ResponseBody String ping(){
		logger.info("Entering AnnualTrvlAlwnceController.ping() method.");
		return "Annual Travel Allowance API is up and running at end point /annual-travel-allowance";
	}
	
	@Operation(summary = "Apply Annual Travel Allowance Application", description = "Apply for Annual Travel Allowance in Company.", tags = { "AnnualTravelAllowance" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/apply", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO processAnnualTravelAllowance(@RequestBody AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO){
		logger.info("Entering AnnualTrvlAlwnceController.processAnnualTravelAllowance() method.");
		StatusDTO response = null;
		annualTrvlAlwnceDTO.setOperation("Apply");
		response = annualTrvlAlwnceService.processAnnualTravelAllowanceRequest(annualTrvlAlwnceDTO);
		logger.info("Exiting AnnualTrvlAlwnceController.processAnnualTravelAllowance() method.");
		return response;
	}
	
	@Operation(summary = "Recomend Annual Travel Allowance Application request", description = "Recommend Annual Travel Allowance Application request.", tags = { "AnnualTravelAllowance" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/recommend", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO recommendAnnualTravelAllowance(@RequestBody AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO){
		logger.info("Entering AnnualTrvlAlwnceController.recommendAnnualTravelAllowance() method.");
		StatusDTO response = null;
		annualTrvlAlwnceDTO.setOperation("Recommend");
		response = annualTrvlAlwnceService.processAnnualTravelAllowanceRequest(annualTrvlAlwnceDTO);
		logger.info("Exiting AnnualTrvlAlwnceController.recommendAnnualTravelAllowance() method.");
		return response;
	}
	
	@Operation(summary = "Approve Annual Travel Allowance Application request", description = "Approve Annual Travel Allowance Application request.", tags = { "AnnualTravelAllowance" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/accept", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO acceptAnnualTravelAllowance(@RequestBody AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO){
		logger.info("Entering AnnualTrvlAlwnceController.acceptAnnualTravelAllowance() method.");
		StatusDTO response = null;
		annualTrvlAlwnceDTO.setOperation("Accept");
		response = annualTrvlAlwnceService.processAnnualTravelAllowanceRequest(annualTrvlAlwnceDTO);
		logger.info("Exiting AnnualTrvlAlwnceController.acceptAnnualTravelAllowance() method.");
		return response;
	}
	
	@Operation(summary = "Reject Annual Travel Allowance Application request", description = "Reject Annual Travel Allowance Application request.", tags = { "AnnualTravelAllowance" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/reject", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO rejectAnnualTravelAllowance(@RequestBody AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO){
		logger.info("Entering AnnualTrvlAlwnceController.approveAnnualTravelAllowance() method.");
		StatusDTO response = null;
		annualTrvlAlwnceDTO.setOperation("Reject");
		response = annualTrvlAlwnceService.processAnnualTravelAllowanceRequest(annualTrvlAlwnceDTO);
		logger.info("Exiting AnnualTrvlAlwnceController.approveAnnualTravelAllowance() method.");
		return response;
	}
	
	@Operation(summary = "Get Eligibility Amount", description = "Get Eligibility Amount for Annual Travel Allowance Application request.", tags = { "AnnualTravelAllowance" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/getEligibilityAmount/{employeeId}", method=RequestMethod.GET)
	public  @ResponseBody double getEligibilityAmount(@PathVariable String employeeId){
		logger.info("Entering AnnualTrvlAlwnceController.getEligibilityAmount() method.");
		return annualTrvlAlwnceService.getEligibilityAmountRequest(employeeId);
	}
	/**
	 * getAllApprovers returns list of all approvers of an Employee
	 * based on the employeeId
	 * @param employeeId
	 * @return
	 */
	@Operation(summary = "Get all approvers", description = "Returns all approvers of an Employee.", tags = { "AnnualTravelAllowance" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = Map.class,hidden = true)))})
	@RequestMapping(value = "/getAllApprovers", method=RequestMethod.GET)
	public @ResponseBody Map<String,String> getAllApprovers(@RequestParam("employeeId") String employeeId){
		logger.info("Entering AnnualTrvlAlwnceController.getAllApprovers() method.");
		return utilService.getAllApprovers(employeeId,2);
	}
	
	
}
