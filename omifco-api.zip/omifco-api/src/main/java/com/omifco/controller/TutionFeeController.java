package com.omifco.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.omifco.dto.FeeReimbursementDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.entity.DependentDetailsEntity;
import com.omifco.service.TutionFeeService;
import com.omifco.service.UtilService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/tution-fee")
@Tag(name = "TutionFee", description = "Tution Fee API")
public class TutionFeeController {
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	
	@Autowired
	private TutionFeeService tutionfeeservice;
	
	@Autowired
	private UtilService utilService;
	
	/**
	 * applyReimburse is intended to reimburse school tution fees Request.
	 * @param feeReimburse
	 * @return
	 */
	@Operation(summary = "Apply for Re-imbursement", description = "Apply for Re-imbursement for tution fee.", tags = { "TutionFee" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/apply", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO processReimbursement(@RequestBody FeeReimbursementDTO feeReimburse){
		logger.info("Entering TutionFeeController.processReimbursement() method.");
		StatusDTO response = null;
		feeReimburse.setOperation("Apply");
		response = tutionfeeservice.processReimburse(feeReimburse);
		logger.info("Exiting TutionFeeController.processReimbursement() method.");
		return response;
	}
	
	/**
	 * rejectReimbursement is intended to invoke Reject Reimburse Request.
	 * @param 
	 * @return
	 */
	@Operation(summary = "Reject a Reimburse request", description = "Reject a Reimburse request.", tags = { "TutionFee" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/reject", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO rejectFeeClaim(@RequestBody FeeReimbursementDTO feeReimburse){
		logger.info("Entering TutionFeeController.rejectFeeClaim() method.");
		StatusDTO response = null;
		feeReimburse.setOperation("Reject");
		response = tutionfeeservice.processReimburse(feeReimburse);
		logger.info("Exiting TutionFeeController.rejectFeeClaim() method.");
		return response;
	}
	
	/**
	 * ping method is used to validate the connectivity
	 * of the API.
	 */
	@Operation(summary = "Validates the heart-beat of the API.", description = "Pings the API and check if its up and running.", tags = { "TutionFee" })
	@RequestMapping(method=RequestMethod.GET)
	public @ResponseBody String ping(){
		logger.info("Entering TutionFeeController.ping() method.");
		return "Tution Fee API is up and running at end point /tution-fee";
	}
	
	/**
	 * recommendFeeClaim is intended to invoke Recommend Reimburse Request.
	 * @param 
	 * @return
	 */
	@Operation(summary = "Recomend a Reimburse request", description = "Recommend a Reimburse request.", tags = { "TutionFee" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/recommend", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO recommendFeeClaim(@RequestBody FeeReimbursementDTO feeReimburse){
		logger.info("Entering TutionFeeController.recommendFeeClaim() method.");
		StatusDTO response = null;
		feeReimburse.setOperation("Recommend");
		response = tutionfeeservice.processReimburse(feeReimburse);
		logger.info("Exiting TutionFeeController.recommendFeeClaim() method.");
		return response;
	}
	
	/**
	 * acceptFeeClaim is intended to invoke Accept Reimburse Application Request.
	 * @param 
	 * @return
	 */
	@Operation(summary = "Accept Reimburse Application Request", description = "Accepts a Reimburse request.", tags = { "TutionFee" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/accept", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO acceptFeeClaim(@RequestBody FeeReimbursementDTO feeReimburse){
		logger.info("Entering TutionFeeController.acceptFeeClaim() method.");
		StatusDTO response = null;
		feeReimburse.setOperation("Accept");
		response = tutionfeeservice.processReimburse(feeReimburse);
		logger.info("Exiting TutionFeeController.acceptFeeClaim() method.");
		return response;
	}
	/**
	 * getDependentDetails is intended to invoke Dependent Details Request.
	 * @param 
	 * @return
	 */
	@Operation(summary = "Get Dependent Details", description = "Get Dependent Details of Employee for Dependent Dropdown.", tags = { "TutionFee" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/getDependentDetails/{employeeId}", method=RequestMethod.GET)
	public  @ResponseBody List<DependentDetailsEntity> getDependentDetails(@PathVariable String employeeId){
		logger.info("Entering TutionFeeServiceController.getDependentDetails() method.");
		List<DependentDetailsEntity> dependentDetails = tutionfeeservice.getDependentDetails(employeeId);
		logger.info("Exiting TutionFeeServiceController.getDependentDetails() method.");
		return dependentDetails;
	}
	
	/**
	 * getAllApprovers returns list of all approvers of an Employee
	 * based on the employeeId
	 * @param employeeId
	 * @return
	 */
	@Operation(summary = "Get all approvers", description = "Returns all approvers of an Employee.", tags = { "TutionFee" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = Map.class,hidden = true)))})
	@RequestMapping(value = "/getAllApprovers", method=RequestMethod.GET)
	public @ResponseBody Map<String,String> getAllApprovers(@RequestParam("employeeId") String employeeId){
		logger.info("Entering TutionFeeController.getAllApprovers() method.");
		return utilService.getAllApprovers(employeeId,2);
	}
	
}
