package com.omifco.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.omifco.dto.LeaveEncashmentDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.service.LeaveEncashmentService;
import com.omifco.service.UtilService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * LeaveEncashmentController is intended to maintain all API's related
 * to Leave Encashment Component.
 * 
 * @author Prolifics.
 *
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/leave-encashment")
@Tag(name = "LeaveEncashment", description = "Leave Encashment API")
public class LeaveEncashmentController {	
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	/**
	 * LeaveEncashmentService will be injected by Spring Framework.
	 */
	@Autowired
	private LeaveEncashmentService leaveEncashmentService;
	
	@Autowired
	private UtilService utilService;

	/**
	 * ping method is used to validate the connectivity
	 * of the API.
	 */
	@Operation(summary = "Validates the heart-beat of the API.", description = "Pings the API and check if its up and running.", tags = { "LeaveEncashment" })
	@RequestMapping(method=RequestMethod.GET)
	public @ResponseBody String ping(){
		logger.info("Entering LeaveEncashmentController.ping() method.");
		return "Leave Encashment API is up and running at end point /leave-encashment";
	}
	
	/**
	 * processLeaveEncashment is intended to invoke Leave Encashment Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Apply for leave encashment", description = "Apply for leave encashment for a no of days.", tags = { "LeaveEncashment" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/apply", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO processLeaveEncashment(@RequestBody LeaveEncashmentDTO encashmentRequest){
		logger.info("Entering LeaveEncashmentController.processLeaveEncashment() method.");
		StatusDTO response = null;
		encashmentRequest.setOperation("Apply");
		response = leaveEncashmentService.processLeaveEncashment(encashmentRequest);
		logger.info("Exiting LeaveEncashmentController.processLeaveEncashment() method.");
		return response;
	}
	
	/**
	 * recommendLeaveEncashment is intended to invoke Leave Encashment Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Recommend a leave encashment request", description = "Recommend a leave encashment request.", tags = { "LeaveEncashment" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/recommend", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO recommendLeaveEncashment(@RequestBody LeaveEncashmentDTO encashmentRequest){
		logger.info("Entering LeaveEncashmentController.recommendLeaveEncashment() method.");
		StatusDTO response = null;
		encashmentRequest.setOperation("Recommend");
		response = leaveEncashmentService.processLeaveEncashment(encashmentRequest);
		logger.info("Exiting LeaveEncashmentController.recommendLeaveEncashment() method.");
		return response;
	}
	
	/**
	 * acceptLeaveEncashment is intended to invoke Leave Encashment Application Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Accepts a leave encashment request", description = "Accepts a leave request.", tags = { "LeaveEncashment" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/accept", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO acceptLeaveEncashment(@RequestBody LeaveEncashmentDTO encashmentRequest){
		logger.info("Entering LeaveEncashmentController.acceptLeaveEncashment() method.");
		StatusDTO response = null;
		encashmentRequest.setOperation("Accept");
		response = leaveEncashmentService.processLeaveEncashment(encashmentRequest);
		logger.info("Exiting LeaveEncashmentController.acceptLeaveEncashment() method.");
		return response;
	}
	
	/**
	 * rejectLeaveEncashment is intended to invoke Leave Application Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Reject a leave request", description = "Reject a leave request.", tags = { "LeaveEncashment" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/reject", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO rejectLeaveEncashment(@RequestBody LeaveEncashmentDTO encashmentRequest){
		logger.info("Entering LeaveEncashmentController.rejectLeaveEncashment() method.");
		StatusDTO response = null;
		encashmentRequest.setOperation("Reject");
		response = leaveEncashmentService.processLeaveEncashment(encashmentRequest);
		logger.info("Exiting LeaveEncashmentController.rejectLeaveEncashment() method.");
		return response;
	}
	
	/**
	 * getAllApprovers returns list of all approvers of an Employee
	 * based on the employeeId
	 * @param employeeId
	 * @return
	 */
	@Operation(summary = "Get all approvers", description = "Returns all approvers of an Employee.", tags = { "LeaveApplication" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = Map.class,hidden = true)))})
	@RequestMapping(value = "/getAllApprovers", method=RequestMethod.GET)
	public @ResponseBody Map<String,String> getAllApprovers(@RequestParam("employeeId") String employeeId){
		logger.info("Entering LeaveEncashmentController.getAllApprovers() method.");
		return utilService.getAllApprovers(employeeId,2);
	}
	
	
	/**
	 * @param LeaveEncashmentService the leaveEncashmentService to set
	 */
	@Autowired
	public void setLeaveEncashmentService(LeaveEncashmentService leaveEncashmentService) {
		this.leaveEncashmentService = leaveEncashmentService;
	}
}
