package com.omifco.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.omifco.dto.ChangePasswordDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.entity.UserEntity;
import com.omifco.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * UserAuthenticationController is intended to maintain all API's related
 * to Login Component.
 * 
 * @author Prolifics.
 *
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/profile")
@Tag(name = "UserProfile", description = "User Profile API")
public class UserProfileController {
	
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	/**
	 * UserService will be injected by Spring Framework.
	 */
	@Autowired
	private UserService userService;

	/**
	 * ping method is used to validate the connectivity
	 * of the API.
	 */
	@Operation(summary = "Validates the heart-beat of the API.", description = "Pings the API and check if its up and running.", tags = { "UserProfile" })
	@RequestMapping(method=RequestMethod.GET)
	public @ResponseBody String ping(){
		logger.info("Entering UserProfileController.ping() method.");
		return "User Profile API is up and running at end point /profile";
	}
	
	/**
	 * updateUserProfile used to update the basic informations of a user's profile.
	 * 
	 * @param userEntity
	 * @return
	 */
	@Operation(summary = "Updates user profile.", description = "Updates basic informations of a user profile.", tags = { "UserProfile" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/update", method=RequestMethod.POST)
	public StatusDTO updateUserProfile(@RequestBody UserEntity userEntity) {
		logger.info("Entering UserProfileController.updateUserProfile() method.");
		StatusDTO statusDTO =userService.updateUserProfile(userEntity);
		logger.info("Exiting UserProfileController.updateUserProfile() method.");
		return statusDTO;
	}
	
	/**
	 * getUpdatedProfile retrieves user profile information
	 * 
	 * @param employeeId
	 */
	@Operation(summary = "Retrives user profile information.", description = "Retrives user profile information.", tags = { "UserProfile" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = UserEntity.class,hidden = true)))})
	@RequestMapping(value = "/get-profile/{employeeId}", method=RequestMethod.GET)
	public  @ResponseBody UserEntity getUpdatedProfile(@PathVariable String employeeId){
		logger.info("Entering UserProfileController.getUpdatedProfile() method.");
		UserEntity userEntity = userService.getUserProfile(employeeId);
		userEntity.setPassword(null);
		logger.info("Exiting UserProfileController.getUpdatedProfile() method.");
		return 	userEntity;
	}
	
	/**
	 * changePassword used to change the old password.
	 * 
	 * @param userName
	 * @return
	 */
	@Operation(summary = "Change user's profile password.", description = "Change user's profile password.", tags = { "UserProfile" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/change-password", method=RequestMethod.POST)
	public StatusDTO changePassword(@RequestBody ChangePasswordDTO changePasswordDTO) {
		logger.info("Entering UserProfileController.changePassword() method.");
		StatusDTO statusDTO =userService.changePassword(changePasswordDTO);
		logger.info("Exiting UserProfileController.changePassword() method.");
		return statusDTO;
	}
	
	
}
