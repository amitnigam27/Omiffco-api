package com.omifco.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.omifco.entity.LookupMasterEntity;
import com.omifco.service.LookupService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/lookup-service")
@Tag(name = "Lookups", description = "Master Lookup API.")
public class LookupController {
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	/**
	 * LeaveApplicationService will be injected by Spring Framework.
	 */
	@Autowired
	private LookupService lookupService;
	
	/**
	 * ping method is used to validate the connectivity
	 * of the API.
	 */
	@Operation(summary = "Validates the heart-beat of the API.", description = "Pings the API and check if its up and running.", tags = { "Lookups" })
	@RequestMapping(method=RequestMethod.GET)
	public @ResponseBody String ping(){
		logger.info("Entering LookupController.ping() method.");
		return "Lookup API is up and running at end point /lookup-service";
	}
	
	/**
	 * getLeaveTypes method is used to get all the available leave types
	 *  in the system.
	 */
	@Operation(summary = "Get master lookup data for drop-downs.", description = "It returns key-value pair for drop-downs.", tags = { "Lookups" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = LookupMasterEntity.class,hidden = true)))})
	@RequestMapping(value = "/lookups", method=RequestMethod.GET)
	public @ResponseBody List<LookupMasterEntity> getLookupsByType(@RequestParam("lookupType") String lookupType){
		logger.info("Entering LookupController.getLookupsByType() method.");
		return lookupService.getLookupsByType(lookupType);
	}


}
