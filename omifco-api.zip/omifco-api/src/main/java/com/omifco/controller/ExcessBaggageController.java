package com.omifco.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.omifco.dto.ExcessBaggageClaimDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.service.ExcessBaggageClaimService;
import com.omifco.service.UtilService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * ExcessBaggageController is intended to maintain all API's related
 * to Exxcess Baggage Claim.
 * 
 * @author Rajiv Singh.
 *
 */

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/excess-baggage")
@Tag(name = "ExcessBaggage", description = "Excess Baggage Claim API")
public class ExcessBaggageController {
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	
	@Autowired
	private ExcessBaggageClaimService excessBaggageCLaimService;
	
	@Autowired
	private UtilService utilService;
	/**
	 * ping method is used to validate the connectivity
	 * of the API.
	 */
	@Operation(summary = "Validates the heart-beat of the API.", description = "Pings the API and check if its up and running.", tags = { "ExcessBaggage" })
	@RequestMapping(method=RequestMethod.GET)
	public @ResponseBody String ping(){
		logger.info("Entering ExcessBaggageController.ping() method.");
		return "Excess Baggage API is up and running at end point /excess-baggage";
	}
	
	
	/**
	 * processExcessBaggage is intended to invoke Excess Baggage Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Apply for Excess Baggage Claim", description = "Apply for Excess Baggage Claim .", tags = { "ExcessBaggage" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/apply", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO processExcessBaggageClaim(@RequestBody ExcessBaggageClaimDTO excessBaggageClaimRequest){
		logger.info("Entering ExcessBaggageController.processExcessBaggageClaim() method.");
		StatusDTO response = null;
		excessBaggageClaimRequest.setOperation("Apply");
		response = excessBaggageCLaimService.processExcessBaggageClaim(excessBaggageClaimRequest);
		logger.info("Exiting ExcessBaggageController.processExcessBaggageClaim() method.");
		return response;
	}
	
	
	/**
	 * recommendLeaveEncashment is intended to invoke Leave Encashment Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Recommend a Baggage Claim request", description = "Recommend a Baggage Claim request.", tags = { "ExcessBaggage" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/recommend", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO recommendExcessBaggageClaim(@RequestBody ExcessBaggageClaimDTO excessBaggageClaimRequest){
		logger.info("Entering ExcessBaggageController.recommendExcessBaggageClaim() method.");
		StatusDTO response = null;
		excessBaggageClaimRequest.setOperation("Recommend");
		response = excessBaggageCLaimService.processExcessBaggageClaim(excessBaggageClaimRequest);
		logger.info("Exiting ExcessBaggageController.recommendExcessBaggageClaim() method.");
		return response;
	}
	
	@Operation(summary = "Approves a Baggage Claim request", description = "Approves a Baggage Claim request.", tags = { "ExcessBaggage" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/accept", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO approveExcessBaggageClaim(@RequestBody ExcessBaggageClaimDTO excessBaggageClaimRequest){
		logger.info("Entering ExcessBaggageController.acceptExcessBaggageClaim() method.");
		StatusDTO response = null;
		excessBaggageClaimRequest.setOperation("Accept");
		response = excessBaggageCLaimService.processExcessBaggageClaim(excessBaggageClaimRequest);
		logger.info("Exiting ExcessBaggageController.acceptExcessBaggageClaim() method.");
		return response;
	}
	
	@Operation(summary = "Reject a Baggage Claim request", description = "Reject a Baggage Claim request.", tags = { "ExcessBaggage" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/reject", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO rejectExcessBaggageClaimt(@RequestBody ExcessBaggageClaimDTO excessBaggageClaimRequest){
		logger.info("Entering ExcessBaggageController.rejectExcessBaggageClaim() method.");
		StatusDTO response = null;
		excessBaggageClaimRequest.setOperation("Reject");
		response = excessBaggageCLaimService.processExcessBaggageClaim(excessBaggageClaimRequest);
		logger.info("Exiting ExcessBaggageController.rejectExcessBaggageClaim() method.");
		return response;
	}
	
	@Operation(summary = "Get all approvers", description = "Returns all approvers of an Employee.", tags = { "ExcessBaggage" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = Map.class,hidden = true)))})
	@RequestMapping(value = "/getAllApprovers", method=RequestMethod.GET)
	public @ResponseBody Map<String,String> getAllApprovers(@RequestParam("employeeId") String employeeId){
		logger.info("Entering ExcessBaggageController.getAllApprovers() method.");
		return utilService.getAllApprovers(employeeId,2);
	}
	
}
