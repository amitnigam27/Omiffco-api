package com.omifco.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.service.UtilService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * ApplicationController is intended to maintain all API's related
 * to Applications in the System.
 * 
 * @author Prolifics.
 *
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/application")
@Tag(name = "Application", description = "Application API")
public class ApplicationController {
	
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	/**
	 * UserService will be injected by Spring Framework.
	 */
	@Autowired
	private UtilService utilService;

	/**
	 * ping method is used to validate the connectivity
	 * of the API.
	 */
	@Operation(summary = "Validates the heart-beat of the API.", description = "Pings the API and check if its up and running.", tags = { "Application" })
	@RequestMapping(method=RequestMethod.GET)
	public @ResponseBody String ping(){
		logger.info("Entering ApplicationController.ping() method.");
		return "Application API is up and running at end point /application";
	}
	
	/**
	 * retreiveRequests queries all the Application Requests of the 
	 * specified User and returns a list along with status of each of
	 * them.
	 * 
	 * @param empId
	 * 	<p>The Employee Id of the User.</p>
	 * @return
	 * 	<p>List of desired Application Requests.</p>
	 */
	@Operation(summary = "Retreive the application requests of the user.", description = "Fetches all the Application Requests raised by the User in the System.", tags = { "Application" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	        		content = @Content(schema = @Schema(implementation = ApplicationEntity.class,hidden = true)))})
	@RequestMapping(value = "/requests/{empId}", method=RequestMethod.GET)
	public  @ResponseBody List<ApplicationEntity> retreiveRequests(@PathVariable String empId){
		logger.info("Entering ApplicationController.retreiveRequests() method.");
		List<ApplicationEntity> response = utilService.getAllRequestsOfUser(empId);
		logger.info("Exiting ApplicationController.retreiveRequests() method.");
		return response;
	}
	
	/**
	 * retreiveReminders queries all the active Reminders of the 
	 * specified User which needs some actions to be taken.
	 * 
	 * @param empId
	 * 	<p>The Employee Id of the User.</p>
	 * @return
	 * 	<p>List of desired Reminders.</p>
	 */
	@Operation(summary = "Retreive the active reminders of the user.", description = "Fetches all the Reminders which requires desired action from the User.", tags = { "Application" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	        		content = @Content(schema = @Schema(implementation = NotificationEntity.class,hidden = true)))})
	@RequestMapping(value = "/reminders/{empId}", method=RequestMethod.GET)
	public  @ResponseBody List<NotificationEntity> retreiveReminders(@PathVariable String empId){
		logger.info("Entering ApplicationController.retreiveReminders() method.");
		List<NotificationEntity> response = utilService.getAllRemindersOfUser(empId);
		logger.info("Exiting ApplicationController.retreiveReminders() method.");
		return response;
	}
	
	/**
	 * retreiveNotifications queries all the Notifications of the 
	 * specified User in the System.
	 * 
	 * @param empId
	 * 	<p>The Employee Id of the User.</p>
	 * @return
	 * 	<p>List of desired Notifications.</p>
	 */
	@Operation(summary = "Retreive all Notifications of the user.", description = "Fetches all current and historical Notifications of the User.", tags = { "Application" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	        		content = @Content(schema = @Schema(implementation = NotificationEntity.class,hidden = true)))})
	@RequestMapping(value = "/notifications/{empId}", method=RequestMethod.GET)
	public  @ResponseBody List<NotificationEntity> retreiveNotifications(@PathVariable String empId){
		logger.info("Entering ApplicationController.retreiveNotifications() method.");
		List<NotificationEntity> response = utilService.getAllNotificationsOfUser(empId);
		logger.info("Exiting ApplicationController.retreiveNotifications() method.");
		return response;
	}
	
	/**
	 * fetchApplicationDetails fetches data of an already submitted application
	 *  all the Notifications of the 
	 * specified User in the System.
	 * 
	 * @param empId
	 * 	<p>The Employee Id of the User.</p>
	 * @return
	 * 	<p>List of desired Notifications.</p>
	 */
	@Operation(summary = "Fetches data of an Application.", description = "Fetches details of an already submitted Application.", tags = { "Application" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK")})
	@RequestMapping(value = "/{applicationType}/{metaInfo}", method=RequestMethod.GET)
	public  @ResponseBody Object fetchApplicationDetails(@PathVariable String applicationType, @PathVariable String metaInfo){
		logger.info("Entering ApplicationController.fetchApplicationDetails() method.");
		Object response = utilService.getApplicationDetails(applicationType, metaInfo);
		logger.info("Exiting ApplicationController.fetchApplicationDetails() method.");
		return response;
	}	
	
}
