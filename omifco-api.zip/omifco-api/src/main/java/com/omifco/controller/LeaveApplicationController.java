package com.omifco.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.omifco.dto.LeaveDTO;
import com.omifco.dto.LeaveSummaryDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.service.LeaveApplicationService;
import com.omifco.service.UtilService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * LeaveApplicationController is intended to maintain all API's related
 * to Leave Application Component.
 * 
 * @author Prolifics.
 *
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/leave-application")
@Tag(name = "LeaveApplication", description = "Leave Application API")
public class LeaveApplicationController {	
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	/**
	 * LeaveApplicationService will be injected by Spring Framework.
	 */
	@Autowired
	private LeaveApplicationService leaveApplicationService;
	
	@Autowired
	private UtilService utilService;

	/**
	 * ping method is used to validate the connectivity
	 * of the API.
	 */
	@Operation(summary = "Validates the heart-beat of the API.", description = "Pings the API and check if its up and running.", tags = { "LeaveApplication" })
	@RequestMapping(method=RequestMethod.GET)
	public @ResponseBody String ping(){
		logger.info("Entering LeaveApplicationController.ping() method.");
		return "Leave Application API is up and running at end point /leave-application";
	}
	
	/**
	 * getLeavesSummary returns summary of all the leaves
	 * based on the employeeId
	 * @param employeeId
	 * @return
	 */
	@Operation(summary = "Check Leave summary", description = "Check leave summary", tags = { "LeaveApplication" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = LeaveSummaryDTO.class,hidden = true)))})
	@RequestMapping(value = "/summary", method=RequestMethod.GET)
	public @ResponseBody LeaveSummaryDTO getLeavesSummary(@RequestParam("employeeId") String employeeId){
		logger.info("Entering LeaveApplicationController.getLeavesSummary() method.");
		return leaveApplicationService.getLeavesSummary(employeeId);
	}
	
	/**
	 * getAllApprovers returns list of all approvers of an Employee
	 * based on the employeeId
	 * @param employeeId
	 * @return
	 */
	@Operation(summary = "Get all approvers", description = "Returns all approvers of an Employee.", tags = { "LeaveApplication" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = Map.class,hidden = true)))})
	@RequestMapping(value = "/getAllApprovers", method=RequestMethod.GET)
	public @ResponseBody Map<String,String> getAllApprovers(@RequestParam("employeeId") String employeeId){
		logger.info("Entering LeaveApplicationController.getAllApprovers() method.");
		return utilService.getAllApprovers(employeeId,3);
	}	
	
	/**
	 * applyLeave is intended to invoke Leave Application Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Apply for leave", description = "Apply for leave for a specified period.", tags = { "LeaveApplication" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/apply", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO applyLeave(@RequestBody LeaveDTO leave){
		logger.info("Entering LeaveApplicationController.applyLeave() method.");
		StatusDTO response = null;
		leave.setOperation("Apply");
		response = leaveApplicationService.processLeave(leave);
		logger.info("Exiting LeaveApplicationController.applyLeave() method.");
		return response;
	}
	
	/**
	 * recommendLeave is intended to invoke Leave Application Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Recommend a leave request", description = "Recommend a leave request.", tags = { "LeaveApplication" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/recommend", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO recommendLeave(@RequestBody LeaveDTO leave){
		logger.info("Entering LeaveApplicationController.recommendLeave() method.");
		StatusDTO response = null;
		leave.setOperation("Recommend");
		response = leaveApplicationService.processLeave(leave);
		logger.info("Exiting LeaveApplicationController.recommendLeave() method.");
		return response;
	}
	
	/**
	 * approveLeave is intended to invoke Leave Application Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Approves a leave request", description = "Approves a leave request.", tags = { "LeaveApplication" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/approve", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO approveLeave(@RequestBody LeaveDTO leave){
		logger.info("Entering LeaveApplicationController.approveLeave() method.");
		StatusDTO response = null;
		leave.setOperation("Approve");
		response = leaveApplicationService.processLeave(leave);
		logger.info("Exiting LeaveApplicationController.approveLeave() method.");
		return response;
	}
	
	/**
	 * acceptLeave is intended to invoke Leave Application Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Accepts a leave request", description = "Accepts a leave request.", tags = { "LeaveApplication" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/accept", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO acceptLeave(@RequestBody LeaveDTO leave){
		logger.info("Entering LeaveApplicationController.acceptLeave() method.");
		StatusDTO response = null;
		leave.setOperation("Accept");
		response = leaveApplicationService.processLeave(leave);
		logger.info("Exiting LeaveApplicationController.acceptLeave() method.");
		return response;
	}
	
	/**
	 * rejectLeave is intended to invoke Leave Application Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Reject a leave request", description = "Reject a leave request.", tags = { "LeaveApplication" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/reject", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO rejectLeave(@RequestBody LeaveDTO leave){
		logger.info("Entering LeaveApplicationController.rejectLeave() method.");
		StatusDTO response = null;
		leave.setOperation("Reject");
		response = leaveApplicationService.processLeave(leave);
		logger.info("Exiting LeaveApplicationController.rejectLeave() method.");
		return response;
	}
	
	/**
	 * cancelLeave is intended to invoke Leave Application Request.
	 * @param leave
	 * @return
	 */
	@Operation(summary = "Cancel a leave request", description = "Cancel a leave request.", tags = { "LeaveApplication" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/cancel", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO cancelLeave(@RequestBody LeaveDTO leave){
		logger.info("Entering LeaveApplicationController.cancelLeave() method.");
		StatusDTO response = null;
		leave.setOperation("Cancel");
		response = leaveApplicationService.processLeave(leave);
		logger.info("Exiting LeaveApplicationController.cancelLeave() method.");
		return response;
	}

	/**
	 * @param leaveApplicationService the leaveApplicationService to set
	 */
	@Autowired
	public void setLeaveApplicationService(LeaveApplicationService leaveApplicationService) {
		this.leaveApplicationService = leaveApplicationService;
	}
}
