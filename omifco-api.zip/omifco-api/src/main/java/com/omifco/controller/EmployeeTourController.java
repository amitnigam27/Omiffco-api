package com.omifco.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.omifco.dto.EmployeeTourDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.service.EmployeeTourService;
import com.omifco.service.UtilService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/employee-tour")
@Tag(name = "EmployeeTour", description = "Employee Tour API")
public class EmployeeTourController {
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	@Autowired
	private EmployeeTourService employeeTourService;
	
	@Autowired
	private UtilService utilService;
	
	/**
	 * ping method is used to validate the connectivity
	 * of the API.
	 */
	@Operation(summary = "Validates the heart-beat of the API.", description = "Pings the API and check if its up and running.", tags = { "EmployeeTour" })
	@RequestMapping(method=RequestMethod.GET)
	public @ResponseBody String ping(){
		logger.info("Entering EmployeeTourController.ping() method.");
		return "Employee Tour API is up and running at end point /employee-tour";
	}
	
	
	@Operation(summary = "Apply Tour Application", description = "Apply for Tour in Company.", tags = { "EmployeeTour" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/apply", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO processEmployeeTour(@RequestBody EmployeeTourDTO employeeTourDTO){
		logger.info("Entering EmployeeTourController.processEmployeeTour() method.");
		StatusDTO response = null;
		employeeTourDTO.setOperation("Apply");
		response = employeeTourService.processTourRequest(employeeTourDTO);
		logger.info("Exiting EmployeeTourController.processEmployeeTour() method.");
		return response;
	}
	
	/**
	 * getAllApprovers returns list of all approvers of an Employee
	 * based on the employeeId
	 * @param employeeId
	 * @return
	 */
	@Operation(summary = "Get all approvers", description = "Returns all approvers of an Employee.", tags = { "EmployeeTour" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = Map.class,hidden = true)))})
	@RequestMapping(value = "/getAllApprovers", method=RequestMethod.GET)
	public @ResponseBody Map<String,String> getAllApprovers(@RequestParam("employeeId") String employeeId){
		logger.info("Entering EmployeeTourController.getAllApprovers() method.");
		return utilService.getAllApprovers(employeeId,3);
	}
	
	@Operation(summary = "Recomend Tour Application request", description = "Recommend a Tour request.", tags = { "EmployeeTour" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/recommend", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO recommendEmployeeTour(@RequestBody EmployeeTourDTO employeeTourDTO){
		logger.info("Entering EmployeeTourController.recommendEmployeeTour() method.");
		StatusDTO response = null;
		employeeTourDTO.setOperation("Recommend");
		response = employeeTourService.processTourRequest(employeeTourDTO);
		logger.info("Exiting EmployeeTourController.recommendEmployeeTour() method.");
		return response;
	}
	
	@Operation(summary = "Approve Tour Application request", description = "Reject a Tour request.", tags = { "EmployeeTour" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/approve", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO approveEmployeeTour(@RequestBody EmployeeTourDTO employeeTourDTO){
		logger.info("Entering EmployeeTourController.approveEmployeeTour() method.");
		StatusDTO response = null;
		employeeTourDTO.setOperation("Approve");
		response = employeeTourService.processTourRequest(employeeTourDTO);
		logger.info("Exiting EmployeeTourController.approveEmployeeTour() method.");
		return response;
	}
	
	@Operation(summary = "Accept Tour Application Request", description = "Accepts a Tour request.", tags = { "EmployeeTour" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/accept", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO acceptEmployeeTour(@RequestBody EmployeeTourDTO employeeTourDTO){
		logger.info("Entering TutionFeeController.acceptEmployeeTour() method.");
		StatusDTO response = null;
		employeeTourDTO.setOperation("Accept");
		response = employeeTourService.processTourRequest(employeeTourDTO);
		logger.info("Exiting TutionFeeController.acceptEmployeeTour() method.");
		return response;
	}
	
	@Operation(summary = "Reject Tour Application request", description = "Reject a Tour request.", tags = { "EmployeeTour" })
	@ApiResponses(value = { 
	        @ApiResponse(responseCode = "200", description = "OK",
	                content = @Content(schema = @Schema(implementation = StatusDTO.class,hidden = true)))})
	@RequestMapping(value = "/reject", method=RequestMethod.POST)
	public  @ResponseBody StatusDTO rejectEmployeeTour(@RequestBody EmployeeTourDTO employeeTourDTO){
		logger.info("Entering EmployeeTourController.rejectEmployeeTour() method.");
		StatusDTO response = null;
		employeeTourDTO.setOperation("Reject");
		response = employeeTourService.processTourRequest(employeeTourDTO);
		logger.info("Exiting EmployeeTourController.rejectEmployeeTour() method.");
		return response;
	}
}
