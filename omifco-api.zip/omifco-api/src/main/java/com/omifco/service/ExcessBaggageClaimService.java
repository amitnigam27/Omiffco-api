package com.omifco.service;

import com.omifco.dto.ExcessBaggageClaimDTO;
import com.omifco.dto.StatusDTO;

public interface ExcessBaggageClaimService {
	
	public StatusDTO processExcessBaggageClaim(ExcessBaggageClaimDTO excessBaggageClaimDTO);
	
	public Object getExcessBagaggeClaimDetails(String identifier);

}
