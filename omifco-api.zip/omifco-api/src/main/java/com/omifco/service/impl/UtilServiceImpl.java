package com.omifco.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.LookupMasterEntity;
import com.omifco.entity.NotificationEntity;
import com.omifco.repository.UtilRepository;
import com.omifco.service.AnnualTrvlAlwnceService;
import com.omifco.service.BaseService;
import com.omifco.service.EmployeeTourService;
import com.omifco.service.ExcessBaggageClaimService;
import com.omifco.service.LeaveApplicationService;
import com.omifco.service.LeaveEncashmentService;
import com.omifco.service.MedBillReimbService;
import com.omifco.service.TutionFeeService;
import com.omifco.service.UtilService;

/**
 * UtilServiceImpl : Implementation class of UtilService.
 * 
 * @author Prolifics
 *
 */
@Service
public class UtilServiceImpl extends BaseService implements UtilService {
	
	private UtilRepository utilRepository; 

	@Autowired
	private LeaveApplicationService leaveAppService;
	
	@Autowired
	private LeaveEncashmentService leaveEncashService;
	
	@Autowired
	private TutionFeeService tutionfeeservice;
	
	@Autowired
	private EmployeeTourService employeeTourService;
	
	@Autowired
	private AnnualTrvlAlwnceService annualTrvlAlwnceService;
	
	@Autowired
	private ExcessBaggageClaimService excessBaggageClaimService;
	
	@Autowired
	private MedBillReimbService medBillReimbService;
	
	/**
	 * getAllRequestsOfUser returns all Application Requests
	 * of a User.
	 * @param empId
	 * 	<p>Employee Id of the User.</p>
	 * @return
	 * 	<p>List of <strong>ApplicationEntity</strong> instances.
	 */
	@Override
	public List<ApplicationEntity> getAllRequestsOfUser(String empId){
		if(empId!=null && !empId.isEmpty()){
			return utilRepository.getAllRequestsOfUser(empId);
		}
		return null;
	}
	/**
	 * getAllRemindersOfUser returns all active Reminders
	 * of a User.
	 * @param empId
	 * 	<p>Employee Id of the User.</p>
	 * @return
	 * 	<p>List of <strong>NotificationEntity</strong> instances.
	 */
	@Override
	public List<NotificationEntity> getAllRemindersOfUser(String empId){
		if(empId!=null && !empId.isEmpty()){
			return utilRepository.getNotificationsOfUserByType(empId,true);
		}
		return null;
	}
	/**
	 * getAllNotificationsOfUser returns all current and historical
	 * Notifications of a User.
	 * @param empId
	 * 	<p>Employee Id of the User.</p>
	 * @return
	 * 	<p>List of <strong>NotificationEntity</strong> instances.
	 */
	@Override
	public List<NotificationEntity> getAllNotificationsOfUser(String empId){
		if(empId!=null && !empId.isEmpty()){
			return utilRepository.getNotificationsOfUserByType(empId,false);
		}
		return null;
	}
	
	/**
	 * getLookupsByType returns all Master Lookups
	 * of a specified type from the database.
	 * @param lookupType
	 * 	<p>The type of Lookup values desired.</p>
	 * @return
	 * 	<p>List of <strong>LookupMasterEntity</strong> instances.
	 */
	@Override
	public List<LookupMasterEntity> getLookupsByType(String lookupType){
		if(lookupType!=null && !lookupType.isEmpty()){
			return utilRepository.getLookupsByType(lookupType);
		}
		return null;
	}
	
	/**
	 * getApplicationDetails retrieves an application based on applicationType
	 * and identifier.
	 * 
	 * @param applicationType
	 * 	<p>The type of Application.</p>
	 * @param identifier
	 * 	<p>The identifier of the specific Application queried.</p>
	 * @return
	 */
	@Override
	public Object getApplicationDetails(String applicationType, String identifier){
		//Based on Application Type need to decide which Service (like LeaveApplicationService) will be triggered.
		//Call the necessary service from step 1, the method responsible to fetch Application using identifier as input.
		Object obj = new Object();
		switch (applicationType) {
			case "Leave Application":
				obj = leaveAppService.getLeaveDetails(identifier);
				break;
			case "Leave Encashment":
				obj = leaveEncashService.getLeaveEncashmentDetails(identifier);
				break;
			case "Tution Fee":
				obj = tutionfeeservice.getClaimsDetails(identifier);
				break;
			case "Employee Tour":
				obj = employeeTourService.getTourDetails(identifier);
				break;
			case "Annual Travel Allowance": 
				obj = annualTrvlAlwnceService.getAnnualTravelAllowanceDetails(identifier);
				break;
			case "Excess Baggage Claim": 
				obj = excessBaggageClaimService.getExcessBagaggeClaimDetails(identifier);
				break;
			case "Medical Bill": 
				obj = medBillReimbService.getMedBillReimburseDetails(identifier);
				break;
			default: 
				break;
		}
		
		return obj;
	}
	
	/**
	 * getAllApprovers returns the map of all approvers
	 * based on the employeeId
	 * @param employeeId
	 * @return
	 */
	@Override
	public Map<String, String> getAllApprovers(String employeeId,int levels) {
		return utilRepository.getAllApprovers(employeeId, levels);
	}
	
	
	/**
	 * @param utilRepository the utilRepository to set
	 */
	@Autowired
	public void setUtilRepository(UtilRepository utilRepository) {
		this.utilRepository = utilRepository;
	}

	
}
