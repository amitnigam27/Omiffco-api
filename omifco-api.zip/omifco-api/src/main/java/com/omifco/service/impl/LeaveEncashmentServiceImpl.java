package com.omifco.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.omifco.dto.LeaveEncashmentDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.LeaveEncashmentRepository;
import com.omifco.service.BaseService;
import com.omifco.service.LeaveEncashmentService;

/**
 * LeaveApplicationService holds all the Service methods that are 
 * utilized in the Leave Application Flow.
 *  
 * @author Prolifics
 *
 */
@Service
public class LeaveEncashmentServiceImpl extends BaseService implements LeaveEncashmentService, MessageConstants {
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	@Autowired
	private LeaveEncashmentRepository leaveEncashmentRepository;

	@Override
	public StatusDTO processLeaveEncashment(LeaveEncashmentDTO encashmentRequest) {
		logger.info("Entering into LeaveEncashmentServiceImpl.processLeaveEncashment()");
		StatusDTO status = null;
		if(encashmentRequest!=null && encashmentRequest.getOperation()!=null){
			String operation = encashmentRequest.getOperation();
			switch (operation) {
			case "Apply":
				leaveEncashmentRepository.insertEncashmentDetails(encashmentRequest);
				status = new StatusDTO(true,ENCASHMENT_SUBMITTION_CODE,ENCASHMENT_SUBMITTION_MSG);
				break;
			case "Recommend":
				leaveEncashmentRepository.updateEncashmentDetails(encashmentRequest);
				status = new StatusDTO(true,ENCASHMENT_RECOMMENDED_CODE,ENCASHMENT_RECOMMENDED_MSG);
				break;	
			case "Accept":
				leaveEncashmentRepository.updateEncashmentDetails(encashmentRequest);
				status = new StatusDTO(true,ENCASHMENT_ACCEPTED_CODE,ENCASHMENT_ACCEPTED_MSG);
				break;
			case "Reject":
				leaveEncashmentRepository.updateEncashmentDetails(encashmentRequest);
				status = new StatusDTO(true,ENCASHMENT_REJECTED_CODE,ENCASHMENT_REJECTED_MSG);
				break;				
			default:
				throw new OMIFCOBusinessException(MISSING_OPERATION_CODE, MISSING_OPERATION_MSG);
			}
		}
		
		logger.info("Exiting from LeaveEncashmentServiceImpl.processLeaveEncashment()");
		return status;
	}

	@Override
	public LeaveEncashmentDTO getLeaveEncashmentDetails(String metaInfo) {
		logger.info("Entering into LeaveEncashmentServiceImpl.getLeaveEncashmentDetails()");
		LeaveEncashmentDTO leaveEncashmentDTO = leaveEncashmentRepository.getEncashmentDetails(metaInfo);
		logger.info("Exiting from LeaveEncashmentServiceImpl.getLeaveEncashmentDetails()");
		return leaveEncashmentDTO;
	}
	
}
