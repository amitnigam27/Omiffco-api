package com.omifco.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.omifco.dto.AnnualTrvlAlwnceDTO;
import com.omifco.dto.ExcessBaggageClaimDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.ExcessBaggageClaimRepository;
import com.omifco.service.BaseService;
import com.omifco.service.ExcessBaggageClaimService;


/**
 * ExcessBaggageClaimService holds all the Service methods that are 
 * utilized in the Baggage Claim Flow.
 *  
 * @author Rajiv Singh
 *
 */
@Service
public class ExcessBaggageClaimServiceImpl extends BaseService implements ExcessBaggageClaimService, MessageConstants {

	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	
	@Autowired
	private ExcessBaggageClaimRepository excessBaggageClaimRepository;
	
	@Override
	public StatusDTO processExcessBaggageClaim(ExcessBaggageClaimDTO excessBaggageClaimRequest) {
		logger.info("Entering into ExcessBaggageClaimServiceImpl.processLeaveEncashment()");
		StatusDTO status = null;
		if(excessBaggageClaimRequest!=null && excessBaggageClaimRequest.getOperation()!=null){
			String operation = excessBaggageClaimRequest.getOperation();
			switch (operation) {
			case "Apply":
				excessBaggageClaimRepository.insertBaggageClaimDetails(excessBaggageClaimRequest);
				status = new StatusDTO(true,BAGGAGE_CLAIM_SUBMITTION_CODE,BAGGAGE_CLAIM_SUBMITTION_MSG);
				break;
			case "Recommend":
				excessBaggageClaimRepository.updateBaggageClaimDetails(excessBaggageClaimRequest);
				status = new StatusDTO(true,BAGGAGE_CLAIM_RECOMMENDED_CODE,BAGGAGE_CLAIM_RECOMMENDED_MSG);
				break;
			case "Accept":
				excessBaggageClaimRepository.updateBaggageClaimDetails(excessBaggageClaimRequest);
				status = new StatusDTO(true,BAGGAGE_CLAIM_ACCEPTED_CODE,BAGGAGE_CLAIM_ACCEPTED_MSG);
				break;
			case "Reject":
				excessBaggageClaimRepository.updateBaggageClaimDetails(excessBaggageClaimRequest);
				status = new StatusDTO(true,BAGGAGE_CLAIM_REJECTED_CODE,BAGGAGE_CLAIM_REJECTED_MSG);
				break;
			default:
				throw new OMIFCOBusinessException(MISSING_OPERATION_CODE, MISSING_OPERATION_MSG);
			}
		}
		
		logger.info("Exiting from ExcessBaggageServiceImpl.processBaggageClaim()");
		return status;
	} 


	@Override
	public Object getExcessBagaggeClaimDetails(String identifier) {
		logger.info("Entering into ExcessBaggageServiceImpl.getExcessBagaggeClaimDetails()");
		ExcessBaggageClaimDTO excessBaggageClaimDTO = excessBaggageClaimRepository.getExcessBagaggeClaimDetail(identifier);
		logger.info("Exiting from ExcessBagaggeServiceImpl.getExcessBagaggeClaimDetails()");
		return excessBaggageClaimDTO;
	}
	
	
}
