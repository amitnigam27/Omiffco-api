package com.omifco.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.omifco.dto.LeaveDTO;
import com.omifco.dto.LeaveSummaryDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.entity.ApplicationEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.LeaveApplicationRepository;
import com.omifco.service.BaseService;
import com.omifco.service.LeaveApplicationService;

/**
 * LeaveApplicationService holds all the Service methods that are 
 * utilized in the Leave Application Flow.
 *  
 * @author Prolifics
 *
 */
@Service
public class LeaveApplicationServiceImpl extends BaseService implements LeaveApplicationService, MessageConstants {
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	@Autowired
	private LeaveApplicationRepository leaveApplicationRepository;
	/**
	 * processLeave is intended to trigger a necessary action to take on
	 * a Leave Object. The action to take is determined by the "operation"
	 * property.
	 *  
	 * @param leave
	 * 	<p>The Leave Data Transfer Object.</p>
	 * @return
	 * 	<p>StatusDTO - Encapsulating Result of the invocation.</p>
	 */
	@Override
	public StatusDTO processLeave(LeaveDTO leave) {
		logger.info("Entering LeaveApplicationServiceImpl.processLeave() method.");
		StatusDTO status = null;
		if(leave!=null && leave.getOperation()!=null){
			String operation = leave.getOperation();
			switch (operation) {
			case "Apply":
				leaveApplicationRepository.insertLeaveDetails(leave);
				status = new StatusDTO(true,LEAVE_APPLIED_CODE,LEAVE_APPLIED_MSG);
				break;
			case "Recommend":
				leaveApplicationRepository.updateLeaveDetails(leave);
				status = new StatusDTO(true,LEAVE_RECOMMENDED_CODE,LEAVE_RECOMMENDED_MSG);
				break;	
			case "Approve":
				leaveApplicationRepository.updateLeaveDetails(leave);
				status = new StatusDTO(true,LEAVE_APPROVED_CODE,LEAVE_APPROVED_MSG);
				break;
			case "Accept":
				leaveApplicationRepository.updateLeaveDetails(leave);
				status = new StatusDTO(true,LEAVE_ACCEPTED_CODE,LEAVE_ACCEPTED_MSG);
				break;
			case "Reject":
				leaveApplicationRepository.updateLeaveDetails(leave);
				status = new StatusDTO(true,LEAVE_REJECTED_CODE,LEAVE_REJECTED_MSG);
				break;
			case "Cancel":
				leaveApplicationRepository.updateLeaveDetails(leave);
				status = new StatusDTO(true,LEAVE_CANCELLED_CODE,LEAVE_CANCELLED_MSG);
				break;				
			default:
				throw new OMIFCOBusinessException(MISSING_OPERATION_CODE, MISSING_OPERATION_MSG);
			}			
		}
		
		logger.info("Entering LeaveApplicationServiceImpl.processLeave() method.");
		return status;
	}
	

	/**
	 * getLeavesSummary returns summary of all the leaves
	 * based on the employeeId
	 * @param employeeId
	 * @return
	 */
	@Override
	public LeaveSummaryDTO getLeavesSummary(String employeeId) {
		LeaveSummaryDTO leaveSummaryDTO = leaveApplicationRepository.getLeaveBalanceSummaryById(employeeId);	
		return leaveSummaryDTO;
	}
	
	/**
	 * getLeaveDetails returns the details of an applied leave
	 * based on the documentNumber/metaInfo
	 * @param metaInfo
	 * @return
	 */
	@Override
	public LeaveDTO getLeaveDetails(String metaInfo) {
		return leaveApplicationRepository.getLeaveDetails(metaInfo);
	}

	/**
	 * getAppDetails retrieves an application based on applicationType
	 * and identifier.
	 * 
	 * @param applicationType
	 * 	<p>The type of Application.</p>
	 * @param identifier
	 * 	<p>The identifier of the specific Application queried.</p>
	 * @return
	 */
	@Override
	public List<ApplicationEntity> getAppDetails(String applicationType, String identifier) {
		return leaveApplicationRepository.getLeaveAppDetails(applicationType,identifier);
	}
	
}
