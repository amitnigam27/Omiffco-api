/**
 * 
 */
package com.omifco.service;

import java.util.List;

import com.omifco.dto.FeeReimbursementDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.entity.DependentDetailsEntity;

/**
 * @author Prolifics
 *
 */
public interface TutionFeeService {

	/**
	 * processReimburse is intended to trigger a necessary action to take on
	 * a FeeReimburse object. The action to take is determined by the "operation"
	 * property.
	*/
	public StatusDTO processReimburse(FeeReimbursementDTO feeReimbursementDTO);
	
	/**
	 *getDependentDetails is responsible to get the list of dependent details based on employeeId
	 *
	 *@param employeeId
	 */
	public List<DependentDetailsEntity> getDependentDetails(String employeeId);
	
	/**
	 *getClaimDetails is invoked to get the claim details based on claims Serial No.
	 *
	 *@param claimsSrNumber
	 */
	public FeeReimbursementDTO getClaimsDetails(String claimsSrNumber);
}
