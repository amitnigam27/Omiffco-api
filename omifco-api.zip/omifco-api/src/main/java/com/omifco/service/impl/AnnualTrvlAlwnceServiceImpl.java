/**
 * 
 */
package com.omifco.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.omifco.dto.AnnualTrvlAlwnceDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.AnnualTrvlAlwnceRepository;
import com.omifco.service.AnnualTrvlAlwnceService;
import com.omifco.service.BaseService;

/**
 * @author Anigam
 *
 */
@Service
public class AnnualTrvlAlwnceServiceImpl extends BaseService implements AnnualTrvlAlwnceService, MessageConstants{
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	

	@Autowired
	private AnnualTrvlAlwnceRepository annualTrvlAlwnceRepository;
	
	@Override
	public StatusDTO processAnnualTravelAllowanceRequest(AnnualTrvlAlwnceDTO annualTrvlAlwnce) {
		logger.info("Entering AnnualTrvlAlwnceServiceImpl.processAnnualTravelAllowanceRequest() method.");
		StatusDTO status = null;
		if(annualTrvlAlwnce!=null && annualTrvlAlwnce.getOperation()!=null){
			String operation = annualTrvlAlwnce.getOperation();
			switch (operation) {
			case "Apply":
				annualTrvlAlwnceRepository.insertAnnualTravelAllowanceDetails(annualTrvlAlwnce);
				status = new StatusDTO(true,ANNUAL_TRVL_APPLIED_CODE,ANNUAL_TRVL_APPLIED_MSG);
				break;
			case "Recommend":
				annualTrvlAlwnceRepository.updateAnnualTravelAllowanceDetails(annualTrvlAlwnce);
				status = new StatusDTO(true,ANNUAL_TRVL_RECOMMENDED_CODE,ANNUAL_TRVL_RECOMMENDED_MSG);
				break;	
			case "Accept":
				annualTrvlAlwnceRepository.updateAnnualTravelAllowanceDetails(annualTrvlAlwnce);
				status = new StatusDTO(true,ANNUAL_TRVL_ACCEPTED_CODE,ANNUAL_TRVL_ACCEPTED_MSG);
				break;
			case "Reject":
				annualTrvlAlwnceRepository.updateAnnualTravelAllowanceDetails(annualTrvlAlwnce);
				status = new StatusDTO(true,ANNUAL_TRVL_REJECTED_CODE,ANNUAL_TRVL_REJECTED_MSG);
				break;				
			default:
				throw new OMIFCOBusinessException(MISSING_OPERATION_CODE, MISSING_OPERATION_MSG);
			}			
		}
		logger.info("Exiting AnnualTrvlAlwnceServiceImpl.processAnnualTravelAllowanceRequest() method.");
		return status;
	}
	@Override
	public double getEligibilityAmountRequest(String employeeId){
		
		return annualTrvlAlwnceRepository.getEligibilityAmountByEmployeeId(employeeId);
	}
	
	@Override
	public Object getAnnualTravelAllowanceDetails(String identifier) {
		logger.info("Entering into AnnualTrvlAlwnceServiceImpl.getAnnualTravelAllowanceDetails()");
		AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO = annualTrvlAlwnceRepository.getAnnualTravelAllowanceDetails(identifier);
		logger.info("Exiting from AnnualTrvlAlwnceServiceImpl.getAnnualTravelAllowanceDetails()");
		return annualTrvlAlwnceDTO;
	}

}
