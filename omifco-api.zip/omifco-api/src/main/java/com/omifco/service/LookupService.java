package com.omifco.service;

import java.util.List;

import com.omifco.entity.LookupMasterEntity;

/**
 * LookupService holds only one Service method that returns 
 * key-value pair from Lookup Master table which further used for drop-downs.
 *  
 * @author Prolifics
 *
 */
public interface LookupService {
	
	/**
	 * get drop-down data by lookup type
	 * 
	 * @param lookupType
	 * @return List<LookupMasterEntity>
	 */
	List<LookupMasterEntity> getLookupsByType(String lookupType);
	
}
