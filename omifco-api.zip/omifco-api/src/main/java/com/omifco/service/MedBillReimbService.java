package com.omifco.service;

import com.omifco.dto.MedBillReimbDTO;
import com.omifco.dto.StatusDTO;

public interface MedBillReimbService {

	public StatusDTO processMedBillReimbursementRequest(MedBillReimbDTO medBillReimbDTO);
	
	public Object getMedBillReimburseDetails(String identifier);

	public double getAdmissibleAmountRequest(String employeeId);
}
