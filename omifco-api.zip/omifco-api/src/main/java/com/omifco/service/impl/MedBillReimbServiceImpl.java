package com.omifco.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.omifco.dto.MedBillReimbDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.MedBillReimbRepository;
import com.omifco.service.BaseService;
import com.omifco.service.MedBillReimbService;

@Service
public class MedBillReimbServiceImpl extends BaseService implements MedBillReimbService, MessageConstants {

	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private MedBillReimbRepository medBillReimbRepository;

	@Override
	public StatusDTO processMedBillReimbursementRequest(MedBillReimbDTO medBillReimbDTO) {
		logger.info("Entering MedBillReimbServiceImpl.processMedBillReimbursementRequest() method.");
		StatusDTO status = null;
		if (medBillReimbDTO != null && medBillReimbDTO.getOperation() != null) {
			String operation = medBillReimbDTO.getOperation();
			switch (operation) {
			case "Apply":
				medBillReimbRepository.insertMedBillReimbursementDetails(medBillReimbDTO);
				status = new StatusDTO(true, MED_BILL_REIMB_APPLIED_CODE, MED_BILL_REIMB_APPLIED_MSG);
				break;
			case "Recommend":
				medBillReimbRepository.updateMedBillReimbursementDetails(medBillReimbDTO);
				status = new StatusDTO(true, MED_BILL_REIMB_RECOMMENDED_CODE, MED_BILL_REIMB_RECOMMENDED_MSG);
				break;
			case "Approve":
				medBillReimbRepository.updateMedBillReimbursementDetails(medBillReimbDTO);
				status = new StatusDTO(true, MED_BILL_REIMB_APPROVED_CODE, MED_BILL_REIMB_APPROVED_MSG);
				break;
			case "SendToFinance":
				medBillReimbRepository.updateMedBillReimbursementDetails(medBillReimbDTO);
				status = new StatusDTO(true, MED_BILL_REIMB_SENT_TO_FINANCE_CODE, MED_BILL_REIMB_SENT_TO_FINANCE_MSG);
				break;
			case "Reject":
				medBillReimbRepository.updateMedBillReimbursementDetails(medBillReimbDTO);
				status = new StatusDTO(true, MED_BILL_REIMB_REJECTED_CODE, MED_BILL_REIMB_REJECTED_MSG);
				break;
			default:
				throw new OMIFCOBusinessException(MISSING_OPERATION_CODE, MISSING_OPERATION_MSG);
			}
		}
		logger.info("Exiting MedBillReimbServiceImpl.processMedBillReimbursementRequest() method.");
		return status;
	}

	
	@Override
	public Object getMedBillReimburseDetails(String identifier) {
		logger.info("Entering into MedBillReimbServiceImpl.getMedBillReimbursementDetails()");
		MedBillReimbDTO medBillReimbDTO = medBillReimbRepository.getMedBillReimbursementDetails(identifier);
		logger.info("Exiting from MedBillReimbServiceImpl.getMedBillReimbursementDetails()");
		return medBillReimbDTO;
	}


	@Override
	public double getAdmissibleAmountRequest(String employeeId) {
		// TODO Auto-generated method stub
		return medBillReimbRepository.getByAdmissibleAmountEmployeeId(employeeId);
	}

	
}
