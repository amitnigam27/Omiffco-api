/**
 * 
 */
package com.omifco.service;

import com.omifco.dto.AnnualTrvlAlwnceDTO;
import com.omifco.dto.StatusDTO;

/**
 * @author Anigam
 *
 */
public interface AnnualTrvlAlwnceService {

	public StatusDTO processAnnualTravelAllowanceRequest(AnnualTrvlAlwnceDTO annualTrvlAlwnceDTO);

	public double getEligibilityAmountRequest(String employeeId);
	
	public Object getAnnualTravelAllowanceDetails(String identifier);
}
