package com.omifco.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.omifco.dto.FeeReimbursementDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.entity.DependentDetailsEntity;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.TutionFeeRepository;
import com.omifco.service.BaseService;
import com.omifco.service.TutionFeeService;

/**
 * TutionFeeService holds all the Service methods that are 
 * utilized in the TutionFeeService Flow.
 *  
 * @author Prolifics
 *
 */

@Service
public class TutionFeeServiceImpl extends BaseService implements TutionFeeService, MessageConstants {
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	

	@Autowired
	private TutionFeeRepository tutionFeeRepository;

	@Override
	public StatusDTO processReimburse(FeeReimbursementDTO feeReimburse) {
		logger.info("Entering TutionFeeServiceImpl.processReimburse() method.");
		StatusDTO status = null;
		if(feeReimburse!=null && feeReimburse.getOperation()!=null){
			String operation = feeReimburse.getOperation();
			switch (operation) {
			case "Apply":
				tutionFeeRepository.insertTutionFeeDetails(feeReimburse);
				status = new StatusDTO(true,REIMBURSE_APPLIED_CODE,FEE_REIMBURSEMENT_MSG);
				break;
			case "Recommend":
				tutionFeeRepository.updateTutionFeeDetails(feeReimburse);
				status = new StatusDTO(true,REIMBURSE_RECOMMENDED_CODE,REIMBURSE_RECOMMENDED_MSG);
				break;	
			case "Accept":
				tutionFeeRepository.updateTutionFeeDetails(feeReimburse);
				status = new StatusDTO(true,REIMBURSE_ACCEPTED_CODE,REIMBURSE_ACCEPTED_MSG);
				break;
			case "Reject":
				tutionFeeRepository.updateTutionFeeDetails(feeReimburse);
				status = new StatusDTO(true,REIMBURSE_REJECTED_CODE,REIMBURSE_REJECTED_MSG);
				break;				
			default:
				throw new OMIFCOBusinessException(MISSING_OPERATION_CODE, MISSING_OPERATION_MSG);
			}			
		}
		logger.info("Exiting TutionFeeServiceImpl.processReimburse() method.");
		return status;
	}

	public List<DependentDetailsEntity> getDependentDetails(String employeeId){
		logger.info("Entering TutionFeeServiceImpl.getDependentDetails() method.");
		List<DependentDetailsEntity> dependents = tutionFeeRepository.getDependentDetails(employeeId);
		logger.info("Exiting TutionFeeServiceImpl.getDependentDetails() method.");
		return dependents;
	}
	
	@Override
	public FeeReimbursementDTO getClaimsDetails(String claimsSrNumber) {
		logger.info("Entering into TutionFeeServiceImpl.getClaimsDetails()");
		FeeReimbursementDTO feeReimbursementDTO = tutionFeeRepository.getClaimDetails(claimsSrNumber);
		logger.info("Exiting from TutionFeeServiceImpl.getClaimsDetails()");
		return feeReimbursementDTO;
	}
}
