/**
 * 
 */
package com.omifco.service;

import com.omifco.dto.EmployeeTourDTO;
import com.omifco.dto.StatusDTO;

/**
 * @author Anigam
 *
 */
public interface EmployeeTourService {
	
	public StatusDTO processTourRequest(EmployeeTourDTO employeeTourDTO);

	public Object getTourDetails(String identifier);

}
