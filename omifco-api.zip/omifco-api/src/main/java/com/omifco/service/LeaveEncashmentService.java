package com.omifco.service;

import com.omifco.dto.LeaveEncashmentDTO;
import com.omifco.dto.StatusDTO;

public interface LeaveEncashmentService {
	
	public StatusDTO processLeaveEncashment(LeaveEncashmentDTO encashmentRequest);

	public LeaveEncashmentDTO getLeaveEncashmentDetails(String metaInfo);

}
