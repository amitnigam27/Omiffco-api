package com.omifco.service;

import java.util.List;

import com.omifco.dto.LeaveDTO;
import com.omifco.dto.LeaveSummaryDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.entity.ApplicationEntity;

/**
 * LeaveApplicationService holds all the Service methods that are 
 * utilized in the Leave Application Flow.
 *  
 * @author Prolifics
 *
 */
public interface LeaveApplicationService {
	/**
	 * processLeave is intended to trigger a necessary action to take on
	 * a Leave Object. The action to take is determined by the "operation"
	 * property.
	 *  
	 * @param leave
	 * 	<p>The Leave Data Transfer Object.</p>
	 * @return
	 * 	<p>StatusDTO - Encapsulating Result of the invocation.</p>
	 */
	public StatusDTO processLeave(LeaveDTO leave);

	
	/**
	 * getLeavesSummary returns summary of all the leaves
	 * based on the employeeId
	 * @param employeeId
	 * @return
	 */
	public LeaveSummaryDTO getLeavesSummary(String employeeId);
	
	/**
	 * getLeaveDetails returns the details of an applied leave
	 * based on the documentNumber/metaInfo
	 * @param metaInfo
	 * @return
	 */
	public LeaveDTO getLeaveDetails(String metaInfo);
	/**
	 * getAppDetails retrieves an application based on applicationType
	 * and identifier.
	 * 
	 * @param applicationType
	 * 	<p>The type of Application.</p>
	 * @param identifier
	 * 	<p>The identifier of the specific Application queried.</p>
	 * @return
	 */

	public List<ApplicationEntity> getAppDetails(String applicationType, String identifier);
}
