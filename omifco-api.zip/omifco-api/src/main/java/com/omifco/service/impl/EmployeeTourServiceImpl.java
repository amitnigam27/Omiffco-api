/**
 * 
 */
package com.omifco.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.omifco.dto.EmployeeTourDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.exception.OMIFCOBusinessException;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.EmployeeTourRepository;
import com.omifco.service.BaseService;
import com.omifco.service.EmployeeTourService;

/**
 * @author Prolifics
 *
 */
@Service
public class EmployeeTourServiceImpl extends BaseService implements EmployeeTourService, MessageConstants {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());	

	@Autowired
	private EmployeeTourRepository employeeTourRepository;

	@Override
	public StatusDTO processTourRequest(EmployeeTourDTO employeeTourDTO) {
		logger.info("Entering EmployeeTourServiceImpl.processTourRequest() method.");
		StatusDTO status = null;
		if(employeeTourDTO!=null && employeeTourDTO.getOperation()!=null){
			String operation = employeeTourDTO.getOperation();
			switch (operation) {
			case "Apply":
				employeeTourRepository.insertEmployeeTourDetails(employeeTourDTO);
				status = new StatusDTO(true,EMP_TOUR_APPLIED_CODE,EMP_TOUR_APPLIED_MSG);
				break;
			case "Recommend":
				employeeTourRepository.updateEmployeeTourDetails(employeeTourDTO);
				status = new StatusDTO(true,EMP_TOUR_RECOMMENDED_CODE,EMP_TOUR_RECOMMENDED_MSG);
				break;	
			case "Approve":
				employeeTourRepository.updateEmployeeTourDetails(employeeTourDTO);
				status = new StatusDTO(true,EMP_TOUR_APPROVED_CODE,EMP_TOUR_APPROVED_MSG);
				break;
			case "Accept":
				employeeTourRepository.updateEmployeeTourDetails(employeeTourDTO);
				status = new StatusDTO(true,EMP_TOUR_ACCEPTED_CODE,EMP_TOUR_ACCEPTED_MSG);
				break;
			case "Reject":
				employeeTourRepository.updateEmployeeTourDetails(employeeTourDTO);
				status = new StatusDTO(true,EMP_TOUR_CANCELLED_CODE,EMP_TOUR_CANCELLED_MSG);
				break;				
			default:
				throw new OMIFCOBusinessException(MISSING_OPERATION_CODE, MISSING_OPERATION_MSG);
			}			
		}
		logger.info("Exiting EmployeeTourServiceImpl.processTourRequest() method.");
		return status;
	}

	@Override
	public Object getTourDetails(String identifier) {
		logger.info("Entering into EmployeeTourServiceImpl.getTourDetails()");
		EmployeeTourDTO employeeTourDTO = employeeTourRepository.getTourDetails(identifier);
		logger.info("Exiting from EmployeeTourServiceImpl.getTourDetails()");
		return employeeTourDTO;
	}
}
