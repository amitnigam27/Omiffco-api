package com.omifco.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.omifco.entity.LookupMasterEntity;
import com.omifco.messages.constants.MessageConstants;
import com.omifco.repository.UtilRepository;
import com.omifco.service.BaseService;
import com.omifco.service.LookupService;

/**
 * LeaveApplicationService holds all the Service methods that are 
 * utilized in the Leave Application Flow.
 *  
 * @author Prolifics
 *
 */
@Service
public class LookupServiceImpl extends BaseService implements LookupService, MessageConstants {
	/**
	 * The Logger instance.
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UtilRepository utilRepo;
	/**
	 * get drop-down data by lookup type
	 * 
	 * @param lookupType
	 * @return List<LookupMasterEntity>
	 */
	@Override
	public List<LookupMasterEntity> getLookupsByType(String lookupType) {
		logger.info("Entering getLookupsByType()");
		List<LookupMasterEntity> lookupMasterList = new ArrayList<LookupMasterEntity>();
		lookupMasterList = utilRepo.getLookupsByType(lookupType);
		logger.info("Exiting getLookupsByType()");
		return lookupMasterList;
	}	

	

}
