package com.omifco.compositeids;

import java.io.Serializable;
import java.util.Date;


public class WorkflowLeaveDetailsId implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private int unitCode;
	 
    private int documentCode;
    
    private int documentSerialNo;
    
    private Date periodFrom;
    
    /**
   	 * Default parameter less constructor. (DO NOT REMOVE IT)
   	 */
    public WorkflowLeaveDetailsId() {    }
    
    /**
   	 * Parameterized constructor to set values while using these composite ids as primary key.
   	 */
    public WorkflowLeaveDetailsId(int unitCode, int documentCode, int documentSerialNo, Date periodFrom) {
        this.unitCode = unitCode;
        this.documentCode = documentCode;
        this.documentSerialNo = documentSerialNo;
        this.periodFrom = periodFrom;
    }
    
    @Override
    public boolean equals(Object o) {
    	
    	if (o == this) return true;
    	
    	if (!(o instanceof WorkflowLeaveDetailsId)) {
            return false;
        }
    	
    	WorkflowLeaveDetailsId workflowLeaveHeaderId = (WorkflowLeaveDetailsId) o;
    	return workflowLeaveHeaderId.unitCode == unitCode &&	workflowLeaveHeaderId.documentCode == documentCode &&	workflowLeaveHeaderId.documentSerialNo == documentSerialNo 
    			&&	workflowLeaveHeaderId.periodFrom == periodFrom;
    }

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentCode
	 */
	public int getDocumentCode() {
		return documentCode;
	}

	/**
	 * @param documentCode the documentCode to set
	 */
	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	/**
	 * @return the documentSerialNo
	 */
	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	/**
	 * @param documentSerialNo the documentSerialNo to set
	 */
	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	/**
	 * @return the periodFrom
	 */
	public Date getPeriodFrom() {
		return periodFrom;
	}

	/**
	 * @param periodFrom the periodFrom to set
	 */
	public void setPeriodFrom(Date periodFrom) {
		this.periodFrom = periodFrom;
	}

	@Override
	public String toString() {
		return "WorkflowLeaveDetailsId [unitCode=" + unitCode + ", documentCode=" + documentCode + ", documentSerialNo="
				+ documentSerialNo + ", periodFrom=" + periodFrom + "]";
	}

	/*
	 * @Override public int hashCode() {
	 * 
	 * return 0; }
	 */

}
