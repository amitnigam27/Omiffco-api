/**
 * 
 */
package com.omifco.compositeids;

import java.io.Serializable;

/**
 * @author Anigam
 *
 */
public class MedBillReimbId implements Serializable {

	private static final long serialVersionUID = 1L;

	private int unitCode;

	private int billSerialNo;

	/**
	 * Default parameter less constructor. (DO NOT REMOVE IT)
	 */
	public MedBillReimbId() {
	}

	/**
	 * Parameterized constructor to set values while using these composite ids
	 * as primary key.
	 */
	public MedBillReimbId(int unitCode, int billSerialNo) {
		this.unitCode = unitCode;
		this.billSerialNo = billSerialNo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	// @Override
	// public int hashCode() {}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof MedBillReimbId)) {
			return false;
		}
		MedBillReimbId medBillReimbId = (MedBillReimbId) o;
		return medBillReimbId.unitCode == unitCode && medBillReimbId.billSerialNo == billSerialNo;
	}

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the billSerialNo
	 */
	public int getBillSerialNo() {
		return billSerialNo;
	}

	/**
	 * @param billSerialNo the billSerialNo to set
	 */
	public void setBillSerialNo(int billSerialNo) {
		this.billSerialNo = billSerialNo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MedBillReimbId [unitCode=" + unitCode + ", billSerialNo=" + billSerialNo + "]";
	}
		
}
