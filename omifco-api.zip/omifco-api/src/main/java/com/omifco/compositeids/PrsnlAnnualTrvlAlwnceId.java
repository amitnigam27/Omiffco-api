/**
 * 
 */
package com.omifco.compositeids;

import java.io.Serializable;

/**
 * @author Anigam
 *
 */
public class PrsnlAnnualTrvlAlwnceId implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private int unitCode;
	 
    private int hrmsSeqNo;
    
    /**
	 * Default parameter less constructor. (DO NOT REMOVE IT)
	 */
	public PrsnlAnnualTrvlAlwnceId() {
	}

	/**
	 * Parameterized constructor to set values while using these composite ids as primary key.
	 */
	public PrsnlAnnualTrvlAlwnceId(int unitCode, int hrmsSeqNo) {
		this.unitCode = unitCode;
		this.hrmsSeqNo = hrmsSeqNo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
//	@Override
//	public int hashCode() {
//		
//	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof PrsnlAnnualTrvlAlwnceId)) {
			return false;
		}
		PrsnlAnnualTrvlAlwnceId prsnlAnnualTrvlAlwnceId = (PrsnlAnnualTrvlAlwnceId) o;
		return prsnlAnnualTrvlAlwnceId.unitCode== unitCode && prsnlAnnualTrvlAlwnceId.hrmsSeqNo == hrmsSeqNo;
	}

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the hrmsSeqNo
	 */
	public int getHrmsSeqNo() {
		return hrmsSeqNo;
	}

	/**
	 * @param hrmsSeqNo the hrmsSeqNo to set
	 */
	public void setHrmsSeqNo(int hrmsSeqNo) {
		this.hrmsSeqNo = hrmsSeqNo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PrsnlAnnualTrvlAlwnceId [unitCode=" + unitCode + ", hrmsSeqNo=" + hrmsSeqNo + "]";
	}
    
}
