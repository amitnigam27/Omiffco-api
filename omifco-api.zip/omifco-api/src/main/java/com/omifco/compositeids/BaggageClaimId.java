package com.omifco.compositeids;

import java.io.Serializable;

public class BaggageClaimId implements Serializable {

	
	private static final long serialVersionUID = 1L;

	private int unitCode;
	 
    private int billNumber;
    
    
    
    /**
   	 * Default parameter less constructor. (DO NOT REMOVE IT)
   	 */
    public BaggageClaimId() {    }
    
    /**
   	 * Parameterized constructor to set values while using these composite ids as primary key.
   	 */
    public BaggageClaimId(int unitCode, int billNumber) {
        this.unitCode = unitCode;
        this.billNumber = billNumber;
    }
    
    @Override
    public boolean equals(Object o) {
    	
    	if (o == this) return true;
    	
    	if (!(o instanceof BaggageClaimId)) {
            return false;
        }
    	
    	BaggageClaimId baggageClaimId = (BaggageClaimId) o;
    	return baggageClaimId.unitCode == unitCode &&	baggageClaimId.billNumber == billNumber;
    }

	/** 
	 * @return the unitCode
	 */


	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	@Override
	public String toString() {
		return "BaggageClaimId [unitCode=" + unitCode + ", billNumber=" + billNumber + "]";
	}
	

	/*
	 * @Override public int hashCode() {
	 * 
	 * return 0; }
	 */
    
}
