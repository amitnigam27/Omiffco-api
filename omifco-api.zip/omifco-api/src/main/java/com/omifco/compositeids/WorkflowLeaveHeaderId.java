package com.omifco.compositeids;

import java.io.Serializable;


public class WorkflowLeaveHeaderId implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private int unitCode;
	 
    private int documentCode;
    
    private int documentSerialNo;
    
    /**
   	 * Default parameter less constructor. (DO NOT REMOVE IT)
   	 */
    public WorkflowLeaveHeaderId() {    }
    
    /**
   	 * Parameterized constructor to set values while using these composite ids as primary key.
   	 */
    public WorkflowLeaveHeaderId(int unitCode, int documentCode, int documentSerialNo) {
        this.unitCode = unitCode;
        this.documentCode = documentCode;
        this.documentSerialNo = documentSerialNo;
    }
    
    @Override
    public boolean equals(Object o) {
    	
    	if (o == this) return true;
    	
    	if (!(o instanceof WorkflowLeaveHeaderId)) {
            return false;
        }
    	
    	WorkflowLeaveHeaderId workflowLeaveHeaderId = (WorkflowLeaveHeaderId) o;
    	return workflowLeaveHeaderId.unitCode == unitCode &&	workflowLeaveHeaderId.documentCode == documentCode &&	workflowLeaveHeaderId.documentSerialNo == documentSerialNo;
    }

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentCode
	 */
	public int getDocumentCode() {
		return documentCode;
	}

	/**
	 * @param documentCode the documentCode to set
	 */
	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	/**
	 * @return the documentSerialNo
	 */
	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	/**
	 * @param documentSerialNo the documentSerialNo to set
	 */
	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	/*
	 * @Override public int hashCode() {
	 * 
	 * return 0; }
	 */
    
	
    
    

}
