package com.omifco.compositeids;

import java.io.Serializable;


public class DependentDetailsId implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String employeeId;
	      
    private int dependentSerialNo;

    /**
   	 * Default parameter less constructor. (DO NOT REMOVE IT)
   	 */
	public DependentDetailsId(){	}
	
	/**
   	 * Parameterized constructor to set values while using these composite ids as primary key.
   	 */
    public DependentDetailsId(String employeeId, int dependentSerialNo) {
		this.employeeId = employeeId;
		this.dependentSerialNo = dependentSerialNo;
	}

//	@Override
//	public int hashCode() {
//	
//	}

	@Override
	public boolean equals(Object o) {
		if (o == this) return true;
		if (!(o instanceof DependentDetailsId)) {
            return false;
        }
    	
    	DependentDetailsId dependentDetailsId = (DependentDetailsId) o;
    	return dependentDetailsId.employeeId == employeeId &&	dependentDetailsId.dependentSerialNo == dependentSerialNo;
    
	}
	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}
	
	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	/**
	 * @return the dependentSerialNo
	 */
	public int getdependentSerialNo() {
		return dependentSerialNo;
	}

	/**
	 * @param dependentSerialNo the dependentSerialNo to set
	 */
	public void setdependentSerialNo(int dependentSerialNo) {
		this.dependentSerialNo = dependentSerialNo;
	}

	@Override
	public String toString() {
		return "DependentDetailsId [employeeId=" + employeeId + ", dependentSerialNo=" + dependentSerialNo + "]";
	}
    
    
}
