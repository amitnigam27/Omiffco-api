package com.omifco.compositeids;

import java.io.Serializable;

public class PrsnlSchlTutionFeeId implements Serializable {

private static final long serialVersionUID = 1L;
	
	private int unitCode;
	      
	private String employeeId;
	
	private int claimSerialNo;

    /**
   	 * Default parameter less constructor. (DO NOT REMOVE IT)
   	 */
	public PrsnlSchlTutionFeeId() { 	}

	/**
   	 * Parameterized constructor to set values while using these composite ids as primary key.
   	 */
	public PrsnlSchlTutionFeeId(int unitCode, String employeeId, int claimSerialNo) {
		this.unitCode = unitCode;
		this.employeeId = employeeId;
		this.claimSerialNo = claimSerialNo;
	}

//	@Override
//	public int hashCode() {
//	}

	@Override
	public boolean equals(Object o) {
		if (o == this) return true;
		if (!(o instanceof PrsnlSchlTutionFeeId)) {
            return false;
        }
		PrsnlSchlTutionFeeId prsnlSchlTutionFeeId = (PrsnlSchlTutionFeeId) o;
		return prsnlSchlTutionFeeId.unitCode == unitCode && prsnlSchlTutionFeeId.employeeId == employeeId && prsnlSchlTutionFeeId.claimSerialNo==claimSerialNo;
	}

	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the claimSerialNo
	 */
	public int getClaimSerialNo() {
		return claimSerialNo;
	}

	/**
	 * @param claimSerialNo the claimSerialNo to set
	 */
	public void setClaimSerialNo(int claimSerialNo) {
		this.claimSerialNo = claimSerialNo;
	}

	@Override
	public String toString() {
		return "PrsnlSchlTutionFeeId [unitCode=" + unitCode + ", employeeId=" + employeeId + "]";
	}
	
}
