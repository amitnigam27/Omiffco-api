package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.TimeLeaveHeaderId;

@Entity
@Table(name = "TIM_EMP_LEAVE_HDRS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(TimeLeaveHeaderId.class)
public class TimeLeaveHeaderEntity {
	
	@Id
	@Column(name="UNIT_CODE",updatable = false)
    private int unitCode;
	
	@Id
	@Column(name="DOCCUMENT_NO",updatable = false)
    private int documentNumber;
	
	@Column(name="PERSONAL_NO",updatable = false)
    private String employeeId;
	
	@Column(name="APPLICATION_DATE",updatable = false)
    private Date applicationDate;
	
	@Column(name="RECOMEND_BY")
    private String recommendBy;
	
	@Column(name="RECOMEND_DATE")
    private Date recommendDate;
	
	@Column(name="APPROVED_BY")
    private String approvedBy;
	
	@Column(name="APPROVED_DATE")
    private Date approvedDate;
	
	@Column(name="REAMRKS")
    private String remarks;
	
	@Column(name="LEAVE_STATUS")
    private String leaveStatus;
	
	@Column(name="CREATED_BY",updatable = false)
    private String createdBy;
	
	@Column(name="DATETIME_CREATED",updatable = false)
    private Date createdDate;
	
	@Column(name="MODIFIED_BY")
    private String modifiedBy;
	
	@Column(name="DATETIME_MODIFIED")
    private Date modifiedDate;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentNumber
	 */
	public int getDocumentNumber() {
		return documentNumber;
	}

	/**
	 * @param documentNumber the documentNumber to set
	 */
	public void setDocumentNumber(int documentNumber) {
		this.documentNumber = documentNumber;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the applicationDate
	 */
	public Date getApplicationDate() {
		return applicationDate;
	}

	/**
	 * @param applicationDate the applicationDate to set
	 */
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	/**
	 * @return the recommendBy
	 */
	public String getRecommendBy() {
		return recommendBy;
	}

	/**
	 * @param recommendBy the recommendBy to set
	 */
	public void setRecommendBy(String recommendBy) {
		this.recommendBy = recommendBy;
	}

	/**
	 * @return the recommendDate
	 */
	public Date getRecommendDate() {
		return recommendDate;
	}

	/**
	 * @param recommendDate the recommendDate to set
	 */
	public void setRecommendDate(Date recommendDate) {
		this.recommendDate = recommendDate;
	}

	/**
	 * @return the approvedBy
	 */
	public String getApprovedBy() {
		return approvedBy;
	}

	/**
	 * @param approvedBy the approvedBy to set
	 */
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	/**
	 * @return the approvedDate
	 */
	public Date getApprovedDate() {
		return approvedDate;
	}

	/**
	 * @param approvedDate the approvedDate to set
	 */
	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the leaveStatus
	 */
	public String getLeaveStatus() {
		return leaveStatus;
	}

	/**
	 * @param leaveStatus the leaveStatus to set
	 */
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "TimeLeaveHeaderEntity [unitCode=" + unitCode + ", documentNumber=" + documentNumber + ", employeeId="
				+ employeeId + ", applicationDate=" + applicationDate + ", recommendBy=" + recommendBy
				+ ", recommendDate=" + recommendDate + ", approvedBy=" + approvedBy + ", approvedDate=" + approvedDate
				+ ", remarks=" + remarks + ", leaveStatus=" + leaveStatus + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", modifiedBy=" + modifiedBy + ", modifiedDate=" + modifiedDate
				+ "]";
	}

}
