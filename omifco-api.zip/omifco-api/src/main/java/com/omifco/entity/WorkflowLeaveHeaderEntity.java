package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveHeaderId;

@Entity
@Table(name = "WFL_TIM_EMP_LEAVE_HDRS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(WorkflowLeaveHeaderId.class)
public class WorkflowLeaveHeaderEntity {
	
	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_CODE")
    private int documentCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_SNO")
    private int documentSerialNo;
	
	@Column(name="APPLICATION_TYPE")
    private String applicationType;
	
	@Column(name="CAN_WF_DOCCUMENT_SNO")
    private int cancelledDocumentSno;
	
	@Column(name="CAN_HRMS_DOCCUMENT_NO")
    private int cancelledDocumentNumber;
	
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="APPLICATION_DATE")
    private Date applicationDate;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentCode
	 */
	public int getDocumentCode() {
		return documentCode;
	}

	/**
	 * @param documentCode the documentCode to set
	 */
	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	/**
	 * @return the documentSerialNo
	 */
	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	/**
	 * @param documentSerialNo the documentSerialNo to set
	 */
	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	/**
	 * @return the applicationType
	 */
	public String getApplicationType() {
		return applicationType;
	}

	/**
	 * @param applicationType the applicationType to set
	 */
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	/**
	 * @return the cancelledDocumentSno
	 */
	public int getCancelledDocumentSno() {
		return cancelledDocumentSno;
	}

	/**
	 * @param cancelledDocumentSno the cancelledDocumentSno to set
	 */
	public void setCancelledDocumentSno(int cancelledDocumentSno) {
		this.cancelledDocumentSno = cancelledDocumentSno;
	}

	/**
	 * @return the cancelledDocumentNumber
	 */
	public int getCancelledDocumentNumber() {
		return cancelledDocumentNumber;
	}

	/**
	 * @param cancelledDocumentNumber the cancelledDocumentNumber to set
	 */
	public void setCancelledDocumentNumber(int cancelledDocumentNumber) {
		this.cancelledDocumentNumber = cancelledDocumentNumber;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the applicationDate
	 */
	public Date getApplicationDate() {
		return applicationDate;
	}

	/**
	 * @param applicationDate the applicationDate to set
	 */
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	@Override
	public String toString() {
		return "WorkflowLeaveHeader [unitCode=" + unitCode + ", documentCode=" + documentCode + ", documentSerialNo="
				+ documentSerialNo + ", applicationType=" + applicationType + ", cancelledDocumentSno="
				+ cancelledDocumentSno + ", cancelledDocumentNumber=" + cancelledDocumentNumber + ", employeeId="
				+ employeeId + ", applicationDate=" + applicationDate + "]";
	}

}
