package com.omifco.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "USER_APPROVER_CHAIN")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class LineManagerEntity {
	
	@Id
	@Column(name="APPROVER_CHAIN_ID")
    private int id;
	
	@Column(name="APPROVER_ID")
    private String lineManagerId;
	
	@Column(name="EMPLOYEE_ID")
    private String employeeId;
	
	@Column(name="FINAL_APPROVER")
    private String finalApprover;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the lineManagerId
	 */
	public String getLineManagerId() {
		return lineManagerId;
	}

	/**
	 * @param lineManagerId the lineManagerId to set
	 */
	public void setLineManagerId(String lineManagerId) {
		this.lineManagerId = lineManagerId;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the finalApprover
	 */
	public String getFinalApprover() {
		return finalApprover;
	}

	/**
	 * @param finalApprover the finalApprover to set
	 */
	public void setFinalApprover(String finalApprover) {
		this.finalApprover = finalApprover;
	}

	@Override
	public String toString() {
		return "LineManagerEntity [id=" + id + ", lineManagerId=" + lineManagerId + ", employeeId=" + employeeId
				+ ", finalApprover=" + finalApprover + "]";
	}

}
