package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.BaggageClaimId;

@Entity
@Table(name="PRSNL_EXCESS_BAGGAGE_CLAIM_DTLS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(BaggageClaimId.class)
public class PrsnlExcessBaggageClaimDtlsEntity {

	
	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="BILL_SNO")
    private int billNumber;
	
	@Column(name="DEPENDENT_SNO")
    private int dependentSNo;
	
	@Column(name="BILL_DETAIL_SNO")
    private int billDetailSNo;
	
	@Column(name="CLAIM_AMOUNT")
    private int claimAmount;
	
	@Column(name="ADMISSIBLE_AMOUNT")
    private double admissibleAmount;
	
	@Column(name="RECEIPT_NO")
    private int receiptNo;
	
	@Column(name="RECEIPT_DATE")
    private Date receiptDate;
	
	@Column(name="EXCESS_WT")
    private int excessWeight;
	
	@Column(name="CREATED_BY")
    private String createdBy;
	
	@Column(name="DATETIME_CREATED")
    private Date dateTimeCreated;

	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	public int getDependentSNo() {
		return dependentSNo;
	}

	public void setDependentSNo(int dependentSNo) {
		this.dependentSNo = dependentSNo;
	}

	public int getBillDetailSNo() {
		return billDetailSNo;
	}

	public void setBillDetailSNo(int billDetailSNo) {
		this.billDetailSNo = billDetailSNo;
	}

	public int getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(int claimAmount) {
		this.claimAmount = claimAmount;
	}

	public double getAdmissibleAmount() {
		return admissibleAmount;
	}

	public void setAdmissibleAmount(double admissibleAmount) {
		this.admissibleAmount = admissibleAmount;
	}

	public int getReceiptNo() {
		return receiptNo;
	}

	public void setReceiptNo(int receiptNo) {
		this.receiptNo = receiptNo;
	}

	public Date getReceiptDate() {
		return receiptDate;
	}

	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}

	public int getExcessWeight() {
		return excessWeight;
	}

	public void setExcessWeight(int excessWeight) {
		this.excessWeight = excessWeight;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getDateTimeCreated() {
		return dateTimeCreated;
	}

	public void setDateTimeCreated(Date dateTimeCreated) {
		this.dateTimeCreated = dateTimeCreated;
	}

	@Override
	public String toString() {
		return "PrsnlExcessBaggageClaimDtlsEntity [unitCode=" + unitCode + ", billNumber=" + billNumber
				+ ", dependentSNo=" + dependentSNo + ", billDetailSNo=" + billDetailSNo + ", claimAmount=" + claimAmount
				+ ", admissibleAmount=" + admissibleAmount + ", receiptNo=" + receiptNo + ", receiptDate=" + receiptDate
				+ ", excessWeight=" + excessWeight + ", createdBy=" + createdBy + ", dateTimeCreated=" + dateTimeCreated
				+ "]";
	}
	
	
	
	
}
