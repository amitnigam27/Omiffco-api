package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.TimeLeaveDetailsId;

@Entity
@Table(name="TIM_EMP_TOUR_HDRS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(TimeLeaveDetailsId.class)
public class TimEmployeeTourHeaderEntity {
	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="DOCCUMENT_NO")
    private int documentNumber;
	
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="APPLICATION_DATE")
    private Date applicationDate;
	
	@Column(name="TOUR_START_DATE")
    private Date tourStartDate;
	
	@Column(name="TOUR_START_TIME")
    private Date tourStartTime;
	
	@Column(name="TOUR_END_DATE")
    private Date tourEndDate;
	
	@Column(name="TOUR_END_TIME")
    private Date tourEndTime;
	
	@Column(name="TOUR_TYPE")
    private String tourType;
	
	@Column(name="PLACES_OF_VISIT")
    private String placesOfVisit;
	
	@Column(name="GRADE_CODE")
    private String gradeCode;
	
	@Column(name="TOUR_PURPOSE")
    private String tourPurpose;
	
	@Column(name="EXCEPTION_IFANY")
    private String exceptionIfAny;
	
	@Column(name="ORIG_REVISED")
    private String origRevised;
	
	@Column(name="ORIG_DOCCUMENT_NO")
    private String origDocumentNumber;
	
	@Column(name="RECOMEND_BY")
    private String recommendBy;
	
	@Column(name="RECOMEND_DATE")
	private Date recommendDate;
	
	@Column(name="APPROVED_BY ")
    private String approvedBy;
	
	@Column(name="APPROVED_DATE")
    private Date approvedDate;
	
	@Column(name="REAMRKS")
    private String remarks;
	
	@Column(name="TOUR_STATUS")
    private String tourStatus;
	
	@Column(name="INB_LEAVE_FROM")
    private Date leaveFrom;
	
	@Column(name="INB_LEAVE_TO")
    private Date leaveTo;
	
	@Column(name="CREATED_BY")
    private String createdBy;
	
	@Column(name="DATETIME_CREATED")
	private Date createdDate;

	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public int getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(int documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Date getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	public Date getTourStartDate() {
		return tourStartDate;
	}

	public void setTourStartDate(Date tourStartDate) {
		this.tourStartDate = tourStartDate;
	}

	public Date getTourStartTime() {
		return tourStartTime;
	}

	public void setTourStartTime(Date tourStartTime) {
		this.tourStartTime = tourStartTime;
	}

	public Date getTourEndDate() {
		return tourEndDate;
	}

	public void setTourEndDate(Date tourEndDate) {
		this.tourEndDate = tourEndDate;
	}

	public Date getTourEndTime() {
		return tourEndTime;
	}

	public void setTourEndTime(Date tourEndTime) {
		this.tourEndTime = tourEndTime;
	}

	public String getTourType() {
		return tourType;
	}

	public void setTourType(String tourType) {
		this.tourType = tourType;
	}

	public String getPlacesOfVisit() {
		return placesOfVisit;
	}

	public void setPlacesOfVisit(String placesOfVisit) {
		this.placesOfVisit = placesOfVisit;
	}

	public String getGradeCode() {
		return gradeCode;
	}

	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}

	public String getTourPurpose() {
		return tourPurpose;
	}

	public void setTourPurpose(String tourPurpose) {
		this.tourPurpose = tourPurpose;
	}

	public String getExceptionIfAny() {
		return exceptionIfAny;
	}

	public void setExceptionIfAny(String exceptionIfAny) {
		this.exceptionIfAny = exceptionIfAny;
	}

	public String getOrigRevised() {
		return origRevised;
	}

	public void setOrigRevised(String origRevised) {
		this.origRevised = origRevised;
	}

	public String getOrigDocumentNumber() {
		return origDocumentNumber;
	}

	public void setOrigDocumentNumber(String origDocumentNumber) {
		this.origDocumentNumber = origDocumentNumber;
	}

	public String getRecommendBy() {
		return recommendBy;
	}

	public void setRecommendBy(String recommendBy) {
		this.recommendBy = recommendBy;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getTourStatus() {
		return tourStatus;
	}

	public void setTourStatus(String tourStatus) {
		this.tourStatus = tourStatus;
	}

	

	public Date getLeaveFrom() {
		return leaveFrom;
	}

	public void setLeaveFrom(Date leaveFrom) {
		this.leaveFrom = leaveFrom;
	}

	public Date getLeaveTo() {
		return leaveTo;
	}

	public void setLeaveTo(Date leaveTo) {
		this.leaveTo = leaveTo;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getRecommendDate() {
		return recommendDate;
	}

	public void setRecommendDate(Date recommendDate) {
		this.recommendDate = recommendDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TimEmployeeTourHeaderEntity [unitCode=" + unitCode + ", documentNumber=" + documentNumber
				+ ", employeeId=" + employeeId + ", applicationDate=" + applicationDate + ", tourStartDate="
				+ tourStartDate + ", tourStartTime=" + tourStartTime + ", tourEndDate=" + tourEndDate + ", tourEndTime="
				+ tourEndTime + ", tourType=" + tourType + ", placesOfVisit=" + placesOfVisit + ", gradeCode="
				+ gradeCode + ", tourPurpose=" + tourPurpose + ", exceptionIfAny=" + exceptionIfAny + ", origRevised="
				+ origRevised + ", origDocumentNumber=" + origDocumentNumber + ", recommendBy=" + recommendBy
				+ ", recommendDate=" + recommendDate + ", approvedBy=" + approvedBy + ", approvedDate=" + approvedDate
				+ ", remarks=" + remarks + ", tourStatus=" + tourStatus + ", leaveFrom=" + leaveFrom + ", leaveTo="
				+ leaveTo + ", createdBy=" + createdBy + ", createdDate=" + createdDate + "]";
	}
	
	
}
