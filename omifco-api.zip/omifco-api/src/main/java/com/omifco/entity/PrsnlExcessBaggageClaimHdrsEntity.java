package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.BaggageClaimId;

@Entity
@Table(name="PRSNL_EXCESS_BAGGAGE_CLAIM_HDRS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(BaggageClaimId.class)
public class PrsnlExcessBaggageClaimHdrsEntity {

	
	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="BILL_SNO")
    private int billNumber;
	
	@Column(name="PERSONAL_NO")
    private String employeeId; 
	
	@Column(name="CLAIM_DATE")
    private Date claimDate;
	
	@Column(name="CLAIM_CODE")
    private String claimCode;
	
	@Column(name="CURRENCY_CODE")
    private String currencyCode;
	
	@Column(name="CURRENCY_RATE")
    private double currencyRate;
	
	@Column(name="EXCESS_WT")
    private int excessWeight;
	
	@Column(name="ADMISSIBLE_AMOUNT")
    private double admissibleAmount;
	
	@Column(name="RECOMEND_BY")
    private String recomendBy;
	
	@Column(name="RECOMEND_DATE")
    private Date recomendDate;
	
	@Column(name="APPROVED_BY")
    private String approvedBy;
	
	@Column(name="APPROVED_DATE")
    private Date approvedDate;
	
	@Column(name="CREATED_BY")
    private String createdBy;
	
	@Column(name="DATETIME_CREATED")
    private Date dateTimeCreated;
	
	@Column(name="MODIFIED_BY")
    private String modifiedBy;
	
	@Column(name="DATETIME_MODIFIED")
    private Date dateTimeModified;

	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Date getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(Date claimDate) {
		this.claimDate = claimDate;
	}

	public String getClaimCode() {
		return claimCode;
	}

	public void setClaimCode(String claimCode) {
		this.claimCode = claimCode;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public double getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(double currencyRate) {
		this.currencyRate = currencyRate;
	}

	public int getExcessWeight() {
		return excessWeight;
	}

	public void setExcessWeight(int excessWeight) {
		this.excessWeight = excessWeight;
	}

	public double getAdmissibleAmount() {
		return admissibleAmount;
	}

	public void setAdmissibleAmount(double admissibleAmount) {
		this.admissibleAmount = admissibleAmount;
	}

	public String getRecomendBy() {
		return recomendBy;
	}

	public void setRecomendBy(String recomendBy) {
		this.recomendBy = recomendBy;
	}

	public Date getRecomendDate() {
		return recomendDate;
	}

	public void setRecomendDate(Date recomendDate) {
		this.recomendDate = recomendDate;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getDateTimeCreated() {
		return dateTimeCreated;
	}

	public void setDateTimeCreated(Date dateTimeCreated) {
		this.dateTimeCreated = dateTimeCreated;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getDateTimeModified() {
		return dateTimeModified;
	}

	public void setDateTimeModified(Date dateTimeModified) {
		this.dateTimeModified = dateTimeModified;
	}

	@Override
	public String toString() {
		return "PrsnlExcessBaggageClaimHdrsEntity [unitCode=" + unitCode + ", billNumber=" + billNumber
				+ ", employeeId=" + employeeId + ", claimDate=" + claimDate + ", claimCode=" + claimCode
				+ ", currencyCode=" + currencyCode + ", currencyRate=" + currencyRate + ", excessWeight=" + excessWeight
				+ ", admissibleAmount=" + admissibleAmount + ", recomendBy=" + recomendBy + ", recomendDate="
				+ recomendDate + ", approvedBy=" + approvedBy + ", approvedDate=" + approvedDate + ", createdBy="
				+ createdBy + ", dateTimeCreated=" + dateTimeCreated + ", modifiedBy=" + modifiedBy
				+ ", dateTimeModified=" + dateTimeModified + "]";
	}
	
	
}
