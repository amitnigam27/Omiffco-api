package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveHeaderId;

@Entity
@Table(name = "WFL_MED_BILL_REIMB_DTLS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(WorkflowLeaveHeaderId.class)
public class WorkflowMedBillReimbDetailsEntity {

	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_CODE")
    private int documentCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_SNO")
    private int documentSerialNo;
	
	@Column(name="BILL_DETAIL_SNO")
    private int billDetailSerialNo;
	
	@Column(name="DEPENDENT_SNO")
    private int dependentSerialNo;
	
	@Column(name="RECEIPT_NO")
    private String receiptNo;
	
	@Column(name="RECEIPT_DATE")
    private Date receiptDate;
	
	@Column(name="CLAIM_AMOUNT")
    private double claimAmount;
	
	@Column(name="ADMISSIBLE_AMOUNT")
    private double admissibleAmount;
	
	@Column(name="REIMB_TYPE")
    private String reimbType;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentCode
	 */
	public int getDocumentCode() {
		return documentCode;
	}

	/**
	 * @param documentCode the documentCode to set
	 */
	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	/**
	 * @return the documentSerialNo
	 */
	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	/**
	 * @param documentSerialNo the documentSerialNo to set
	 */
	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	/**
	 * @return the billDetailSerialNo
	 */
	public int getBillDetailSerialNo() {
		return billDetailSerialNo;
	}

	/**
	 * @param billDetailSerialNo the billDetailSerialNo to set
	 */
	public void setBillDetailSerialNo(int billDetailSerialNo) {
		this.billDetailSerialNo = billDetailSerialNo;
	}

	/**
	 * @return the dependentSerialNo
	 */
	public int getDependentSerialNo() {
		return dependentSerialNo;
	}

	/**
	 * @param dependentSerialNo the dependentSerialNo to set
	 */
	public void setDependentSerialNo(int dependentSerialNo) {
		this.dependentSerialNo = dependentSerialNo;
	}

	/**
	 * @return the receiptNo
	 */
	public String getReceiptNo() {
		return receiptNo;
	}

	/**
	 * @param receiptNo the receiptNo to set
	 */
	public void setReceiptNo(String receiptNo) {
		this.receiptNo = receiptNo;
	}

	/**
	 * @return the receiptDate
	 */
	public Date getReceiptDate() {
		return receiptDate;
	}

	/**
	 * @param receiptDate the receiptDate to set
	 */
	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}

	/**
	 * @return the claimAmount
	 */
	public double getClaimAmount() {
		return claimAmount;
	}

	/**
	 * @param claimAmount the claimAmount to set
	 */
	public void setClaimAmount(double claimAmount) {
		this.claimAmount = claimAmount;
	}

	/**
	 * @return the admissibleAmount
	 */
	public double getAdmissibleAmount() {
		return admissibleAmount;
	}

	/**
	 * @param admissibleAmount the admissibleAmount to set
	 */
	public void setAdmissibleAmount(double admissibleAmount) {
		this.admissibleAmount = admissibleAmount;
	}

	/**
	 * @return the reimbType
	 */
	public String getReimbType() {
		return reimbType;
	}

	/**
	 * @param reimbType the reimbType to set
	 */
	public void setReimbType(String reimbType) {
		this.reimbType = reimbType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WorkflowMedBillReimbDetailsEntity [unitCode=" + unitCode + ", documentCode=" + documentCode
				+ ", documentSerialNo=" + documentSerialNo + ", billDetailSerialNo=" + billDetailSerialNo
				+ ", dependentSerialNo=" + dependentSerialNo + ", receiptNo=" + receiptNo + ", receiptDate="
				+ receiptDate + ", claimAmount=" + claimAmount + ", admissibleAmount=" + admissibleAmount
				+ ", reimbType=" + reimbType + "]";
	}
	
	
}
