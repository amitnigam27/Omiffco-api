package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.TimeLeaveDetailsId;

@Entity
@Table(name="TIM_EMP_TOUR_DTLS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(TimeLeaveDetailsId.class)
public class TimEmployeeTourDetailsEntity {
	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="DOCCUMENT_NO")
    private int documentNumber;
	
	@Column(name="DTLS_SNO")
    private int detailsSNumber;
	
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="STATION_FROM")
    private String stationFrom;
	
	@Column(name="DEPARTURE_DATE")
    private Date departureDate;
	
	@Column(name="DEPARTURE_TIME")
    private Date departureTime;
	
	@Column(name="STATION_TO")
    private String stationTo;
	
	@Column(name="ARIVAL_DATE")
    private Date arrivalDate;
	
	@Column(name="ARIVAL_TIME")
    private Date arrivalTime;
	
	@Column(name="MODE_OF_TRAVEL")
    private String travelMode;
	
	@Column(name="CREATED_BY")
    private String createdBy;
	
	@Column(name="DATETIME_CREATED")
    private Date createdDate;

	
	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}





	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}





	/**
	 * @return the documentNumber
	 */
	public int getDocumentNumber() {
		return documentNumber;
	}





	/**
	 * @param documentNumber the documentNumber to set
	 */
	public void setDocumentNumber(int documentNumber) {
		this.documentNumber = documentNumber;
	}





	/**
	 * @return the detailsSNumber
	 */
	public int getDetailsSNumber() {
		return detailsSNumber;
	}





	/**
	 * @param detailsSNumber the detailsSNumber to set
	 */
	public void setDetailsSNumber(int detailsSNumber) {
		this.detailsSNumber = detailsSNumber;
	}





	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}





	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}





	/**
	 * @return the stationFrom
	 */
	public String getStationFrom() {
		return stationFrom;
	}





	/**
	 * @param stationFrom the stationFrom to set
	 */
	public void setStationFrom(String stationFrom) {
		this.stationFrom = stationFrom;
	}





	/**
	 * @return the departureDate
	 */
	public Date getDepartureDate() {
		return departureDate;
	}





	/**
	 * @param departureDate the departureDate to set
	 */
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}





	/**
	 * @return the departureTime
	 */
	public Date getDepartureTime() {
		return departureTime;
	}





	/**
	 * @param departureTime the departureTime to set
	 */
	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}





	/**
	 * @return the stationTo
	 */
	public String getStationTo() {
		return stationTo;
	}





	/**
	 * @param stationTo the stationTo to set
	 */
	public void setStationTo(String stationTo) {
		this.stationTo = stationTo;
	}





	/**
	 * @return the arrivalDate
	 */
	public Date getArrivalDate() {
		return arrivalDate;
	}





	/**
	 * @param arrivalDate the arrivalDate to set
	 */
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}





	/**
	 * @return the arrivalTime
	 */
	public Date getArrivalTime() {
		return arrivalTime;
	}





	/**
	 * @param arrivalTime the arrivalTime to set
	 */
	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}





	/**
	 * @return the travelMode
	 */
	public String getTravelMode() {
		return travelMode;
	}





	/**
	 * @param travelMode the travelMode to set
	 */
	public void setTravelMode(String travelMode) {
		this.travelMode = travelMode;
	}





	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}





	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}





	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}





	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}





	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TimEmployeeTourDetailsEntity [unitCode=" + unitCode + ", documentNumber=" + documentNumber
				+ ", detailsSNumber=" + detailsSNumber + ", employeeId=" + employeeId + ", stationFrom=" + stationFrom
				+ ", departureDate=" + departureDate + ", departureTime=" + departureTime + ", stationTo=" + stationTo
				+ ", arrivalDate=" + arrivalDate + ", arrivalTime=" + arrivalTime + ", travelMode=" + travelMode
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + "]";
	}
	
	
}
