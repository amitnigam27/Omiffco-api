package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveHeaderId;

@Entity
@Table(name="WFL_TIM_EMP_TOUR_HDRS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(WorkflowLeaveHeaderId.class)
public class WorkflowTimEmployeeTourHeaderEntity {
	@Id
	@Column(name="UNIT_CODE")
	private int unitCode;

	@Id
	@Column(name="WF_DOCCUMENT_CODE")
	private int documentCode;

	@Id
	@Column(name="WF_DOCCUMENT_SNO")
	private int documentSerialNo;

	@Column(name="CAN_WF_DOCCUMENT_SNO")
	private int canDocumentSerialNo;

	@Column(name="CAN_HRMS_DOCCUMENT_NO")
	private int canHrmsDocumentCode;

	@Column(name="PERSONAL_NO")
	private String employeeId;

	@Column(name="APPLICATION_TYPE")
	private String applicationType;

	@Column(name="TOUR_START_DATE")
	private Date tourStartDate;

	@Column(name="TOUR_END_DATE")
	private Date tourEndDate;

	@Column(name="APPLICATION_DATE")
	private Date applicationDate;

	@Column(name="TOUR_START_TIME")
	private Date tourStartTime;

	@Column(name="TOUR_END_TIME")
	private Date tourEndTime;

	@Column(name="TOUR_TYPE")
	private String tourType;

	@Column(name="PLACES_OF_VISIT")
	private String placesOfVisit;

	@Column(name="GRADE_CODE")
	private String gradeCode;

	@Column(name="TOUR_PURPOSE")
	private String tourPurpose;

	@Column(name="EXCEPTION_IFANY")
	private String exceptionIfAny;

	@Column(name="ORIG_REVISED")
	private String origRevised;

	@Column(name="ORIG_DOCCUMENT_NO")
	private String origDocumentNumber;

	@Column(name="TOUR_STATUS")
	private String tourStatus;

	@Column(name="INB_LEAVE_FROM")
	private Date leaveFrom;

	@Column(name="INB_LEAVE_TO")
	private Date leaveTo;

	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public int getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}



	public int getCanDocumentSerialNo() {
		return canDocumentSerialNo;
	}

	public void setCanDocumentSerialNo(int canDocumentSerialNo) {
		this.canDocumentSerialNo = canDocumentSerialNo;
	}

	public int getCanHrmsDocumentCode() {
		return canHrmsDocumentCode;
	}

	public void setCanHrmsDocumentCode(int canHrmsDocumentCode) {
		this.canHrmsDocumentCode = canHrmsDocumentCode;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public Date getTourStartDate() {
		return tourStartDate;
	}

	public void setTourStartDate(Date tourStartDate) {
		this.tourStartDate = tourStartDate;
	}

	public Date getTourEndDate() {
		return tourEndDate;
	}

	public void setTourEndDate(Date tourEndDate) {
		this.tourEndDate = tourEndDate;
	}

	public Date getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	public Date getTourStartTime() {
		return tourStartTime;
	}

	public void setTourStartTime(Date tourStartTime) {
		this.tourStartTime = tourStartTime;
	}

	public Date getTourEndTime() {
		return tourEndTime;
	}

	public void setTourEndTime(Date tourEndTime) {
		this.tourEndTime = tourEndTime;
	}

	public String getTourType() {
		return tourType;
	}

	public void setTourType(String tourType) {
		this.tourType = tourType;
	}

	public String getPlacesOfVisit() {
		return placesOfVisit;
	}

	public void setPlacesOfVisit(String placesOfVisit) {
		this.placesOfVisit = placesOfVisit;
	}

	public String getGradeCode() {
		return gradeCode;
	}

	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}

	public String getTourPurpose() {
		return tourPurpose;
	}

	public void setTourPurpose(String tourPurpose) {
		this.tourPurpose = tourPurpose;
	}

	public String getExceptionIfAny() {
		return exceptionIfAny;
	}

	public void setExceptionIfAny(String exceptionIfAny) {
		this.exceptionIfAny = exceptionIfAny;
	}

	public String getOrigRevised() {
		return origRevised;
	}

	public void setOrigRevised(String origRevised) {
		this.origRevised = origRevised;
	}

	public String getOrigDocumentNumber() {
		return origDocumentNumber;
	}

	public void setOrigDocumentNumber(String origDocumentNumber) {
		this.origDocumentNumber = origDocumentNumber;
	}

	public String getTourStatus() {
		return tourStatus;
	}

	public void setTourStatus(String tourStatus) {
		this.tourStatus = tourStatus;
	}

	public Date getLeaveFrom() {
		return leaveFrom;
	}

	public void setLeaveFrom(Date leaveFrom) {
		this.leaveFrom = leaveFrom;
	}

	public Date getLeaveTo() {
		return leaveTo;
	}

	public void setLeaveTo(Date leaveTo) {
		this.leaveTo = leaveTo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WorkflowTimEmployeeTourHeaderEntity [unitCode=" + unitCode + ", documentCode=" + documentCode
				+ ", documentSerialNo=" + documentSerialNo + ", canDocumentSerialNo=" + canDocumentSerialNo
				+ ", canHrmsDocumentCode=" + canHrmsDocumentCode + ", employeeId=" + employeeId + ", applicationType="
				+ applicationType + ", tourStartDate=" + tourStartDate + ", tourEndDate=" + tourEndDate
				+ ", applicationDate=" + applicationDate + ", tourStartTime=" + tourStartTime + ", tourEndTime="
				+ tourEndTime + ", tourType=" + tourType + ", placesOfVisit=" + placesOfVisit + ", gradeCode="
				+ gradeCode + ", tourPurpose=" + tourPurpose + ", exceptionIfAny=" + exceptionIfAny + ", origRevised="
				+ origRevised + ", origDocumentNumber=" + origDocumentNumber + ", tourStatus=" + tourStatus
				+ ", leaveFrom=" + leaveFrom + ", leaveTo=" + leaveTo + "]";
	}

}
