package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveHeaderId;

@Entity
@Table(name="WFL_PRS_EXCESS_BAG_CLAIM_DTLS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(WorkflowLeaveHeaderId.class)
public class WorkFlowExcessBaggageClaimsDetailsEntity {

	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_CODE")
    private int documentCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_SNO")
    private int documentSerialNo;
	
	@Column(name="DEPENDENT_SNO")
    private int dependentSNo;
	
	@Column(name="ADMISSIBLE_AMOUNT")
    private double admissibleAmount;
	
	@Column(name="BILL_DETAIL_SNO")
    private int billDetailSNo;
	
	@Column(name="RECEIPT_NO")
    private int receiptNo;
	
	@Column(name="RECEIPT_DATE")
    private Date receiptDate;
	
	@Column(name="EXCESS_WT")
    private int excessWeight;
	
	@Column(name="CLAIM_AMOUNT")
    private int claimAmount;

	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public int getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	public int getDependentSNo() {
		return dependentSNo;
	}

	public void setDependentSNo(int dependentSNo) {
		this.dependentSNo = dependentSNo;
	}

	public double getAdmissibleAmount() {
		return admissibleAmount;
	}

	public void setAdmissibleAmount(double admissibleAmount) {
		this.admissibleAmount = admissibleAmount;
	}

	public int getBillDetailSNo() {
		return billDetailSNo;
	}

	public void setBillDetailSNo(int billDetailSNo) {
		this.billDetailSNo = billDetailSNo;
	}

	public int getReceiptNo() {
		return receiptNo;
	}

	public void setReceiptNo(int receiptNo) {
		this.receiptNo = receiptNo;
	}

	public Date getReceiptDate() {
		return receiptDate;
	}

	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}

	public int getExcessWeight() {
		return excessWeight;
	}

	public void setExcessWeight(int excessWeight) {
		this.excessWeight = excessWeight;
	}

	public int getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(int claimAmount) {
		this.claimAmount = claimAmount;
	}

	@Override
	public String toString() {
		return "WorkFlowExcessBaggageClaimsDetailsEntity [unitCode=" + unitCode + ", documentCode=" + documentCode
				+ ", documentSerialNo=" + documentSerialNo + ", dependentSNo=" + dependentSNo + ", admissibleAmount="
				+ admissibleAmount + ", billDetailSNo=" + billDetailSNo + ", receiptNo=" + receiptNo + ", receiptDate="
				+ receiptDate + ", excessWeight=" + excessWeight + ", claimAmount=" + claimAmount + "]";
	}
	
	
}
