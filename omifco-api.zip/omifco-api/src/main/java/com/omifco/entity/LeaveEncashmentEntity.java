/**
 * 
 */
package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.TimeLeaveDetailsId;

@Entity
@Table(name = "TIM_EMP_LEAVE_ENCASH")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(TimeLeaveDetailsId.class)
public class LeaveEncashmentEntity {

	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="DOCCUMENT_NO")
    private int documentNumber;
	
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="EMP_ENCASHMENT_NO")
    private int encashmentNo;
	
	@Column(name="APPLICATION_DATE")
    private Date applicationDate;
	
	@Column(name="LV_TYPE_CODE")
    private String leaveTypeCode;
	
	@Column(name="DAYS_ENCASHED")
    private double daysEncashed;
	
	@Column(name="RECOMEND_BY")
    private String recommendBy;
	
	@Column(name="RECOMEND_DATE")
    private Date recommendDate;
	
	@Column(name="APPROVED_BY")
    private String approvedBy;
	
	@Column(name="APPROVED_DATE")
    private Date approvedDate;
	
	@Column(name="REMARKS")
    private String remarks;
	
	@Column(name="ENCASH_STATUS")
    private String encashStatus;
	
	@Column(name="PAYMENT_DATE")
	private Date paymentDate;
	
	@Column(name="PAYMENT_MODE")
    private String paymentMode;
	
	@Column(name="PAYMENT_BY")
    private String paymentBy;
	
	@Column(name="AMOUNT")
    private double amount;
	
	@Column(name="ARREAR")
    private double arrear;
	
	@Column(name="SALARY_PROCESSED")
    private boolean salaryProcessed;
	
	@Column(name="SALARY_MONTH")
    private String salaryMonth;
	
	@Column(name="CREATED_BY",updatable = false)
    private String createdBy;
	
	@Column(name="DATETIME_CREATED",updatable = false)
    private Date createdDate;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentNumber
	 */
	public int getDocumentNumber() {
		return documentNumber;
	}

	/**
	 * @param documentNumber the documentNumber to set
	 */
	public void setDocumentNumber(int documentNumber) {
		this.documentNumber = documentNumber;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the encashmentNo
	 */
	public int getEncashmentNo() {
		return encashmentNo;
	}

	/**
	 * @param encashmentNo the encashmentNo to set
	 */
	public void setEncashmentNo(int encashmentNo) {
		this.encashmentNo = encashmentNo;
	}

	/**
	 * @return the applicationDate
	 */
	public Date getApplicationDate() {
		return applicationDate;
	}

	/**
	 * @param applicationDate the applicationDate to set
	 */
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	/**
	 * @return the leaveTypeCode
	 */
	public String getLeaveTypeCode() {
		return leaveTypeCode;
	}

	/**
	 * @param leaveTypeCode the leaveTypeCode to set
	 */
	public void setLeaveTypeCode(String leaveTypeCode) {
		this.leaveTypeCode = leaveTypeCode;
	}

	/**
	 * @return the daysEncashed
	 */
	public double getDaysEncashed() {
		return daysEncashed;
	}

	/**
	 * @param daysEncashed the daysEncashed to set
	 */
	public void setDaysEncashed(double daysEncashed) {
		this.daysEncashed = daysEncashed;
	}

	/**
	 * @return the recommendBy
	 */
	public String getRecommendBy() {
		return recommendBy;
	}

	/**
	 * @param recommendBy the recommendBy to set
	 */
	public void setRecommendBy(String recommendBy) {
		this.recommendBy = recommendBy;
	}

	/**
	 * @return the recommendDate
	 */
	public Date getRecommendDate() {
		return recommendDate;
	}

	/**
	 * @param recommendDate the recommendDate to set
	 */
	public void setRecommendDate(Date recommendDate) {
		this.recommendDate = recommendDate;
	}

	/**
	 * @return the approvedBy
	 */
	public String getApprovedBy() {
		return approvedBy;
	}

	/**
	 * @param approvedBy the approvedBy to set
	 */
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	/**
	 * @return the approvedDate
	 */
	public Date getApprovedDate() {
		return approvedDate;
	}

	/**
	 * @param approvedDate the approvedDate to set
	 */
	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the encashStatus
	 */
	public String getEncashStatus() {
		return encashStatus;
	}

	/**
	 * @param encashStatus the encashStatus to set
	 */
	public void setEncashStatus(String encashStatus) {
		this.encashStatus = encashStatus;
	}

	/**
	 * @return the paymentDate
	 */
	public Date getPaymentDate() {
		return paymentDate;
	}

	/**
	 * @param paymentDate the paymentDate to set
	 */
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	/**
	 * @return the paymentMode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}

	/**
	 * @param paymentMode the paymentMode to set
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	/**
	 * @return the paymentBy
	 */
	public String getPaymentBy() {
		return paymentBy;
	}

	/**
	 * @param paymentBy the paymentBy to set
	 */
	public void setPaymentBy(String paymentBy) {
		this.paymentBy = paymentBy;
	}

	/**
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/**
	 * @return the arrear
	 */
	public double getArrear() {
		return arrear;
	}

	/**
	 * @param arrear the arrear to set
	 */
	public void setArrear(double arrear) {
		this.arrear = arrear;
	}

	/**
	 * @return the salaryProcessed
	 */
	public boolean isSalaryProcessed() {
		return salaryProcessed;
	}

	/**
	 * @param salaryProcessed the salaryProcessed to set
	 */
	public void setSalaryProcessed(boolean salaryProcessed) {
		this.salaryProcessed = salaryProcessed;
	}

	/**
	 * @return the salaryMonth
	 */
	public String getSalaryMonth() {
		return salaryMonth;
	}

	/**
	 * @param salaryMonth the salaryMonth to set
	 */
	public void setSalaryMonth(String salaryMonth) {
		this.salaryMonth = salaryMonth;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "LeaveEncashmentEntity [unitCode=" + unitCode + ", documentNumber=" + documentNumber + ", employeeId="
				+ employeeId + ", encashmentNo=" + encashmentNo + ", applicationDate=" + applicationDate
				+ ", leaveTypeCode=" + leaveTypeCode + ", daysEncashed=" + daysEncashed + ", recommendBy=" + recommendBy
				+ ", recommendDate=" + recommendDate + ", approvedBy=" + approvedBy + ", approvedDate=" + approvedDate
				+ ", remarks=" + remarks + ", encashStatus=" + encashStatus + ", paymentDate=" + paymentDate
				+ ", paymentMode=" + paymentMode + ", paymentBy=" + paymentBy + ", amount=" + amount + ", arrear="
				+ arrear + ", salaryProcessed=" + salaryProcessed + ", salaryMonth=" + salaryMonth + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + "]";
	}
	
}
