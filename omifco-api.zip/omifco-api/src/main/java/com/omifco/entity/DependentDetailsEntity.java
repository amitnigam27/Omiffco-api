package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.DependentDetailsId;

@Entity
@Table(name = "DEPENDENT_DTLS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(DependentDetailsId.class)
public class DependentDetailsEntity {
	
	@Id
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Id
	@Column(name="DEPENDENT_SNO")
    private int dependentSerialNo;

	@Column(name="NAME")
	private String name;
	
	@Column(name="CLASS")
    private String classNo;

	@Column(name="ADMISIBLE_FEE_CLAIM_AMOUNT")
    private double admisibleFeeClaimAmount;
	
	@Column(name="AGE")
    private int age;
	
	@Column(name="SCHOOL_NAME")
    private String schoolName;
	
	@Column(name="SCHOOL_ADDRESS")
    private String schoolAddress;
	
	@Column(name="CREATED_BY",updatable = false)
    private String createdBy;
	
	@Column(name="DATETIME_CREATED",updatable = false)
    private Date createdDate;

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public int getDependentSerialNo() {
		return dependentSerialNo;
	}

	public void setDependentSerialNo(int dependentSerialNo) {
		this.dependentSerialNo = dependentSerialNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public double getAdmisibleFeeClaimAmount() {
		return admisibleFeeClaimAmount;
	}

	public void setAdmisibleFeeClaimAmount(double admisibleFeeClaimAmount) {
		this.admisibleFeeClaimAmount = admisibleFeeClaimAmount;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolAddress() {
		return schoolAddress;
	}

	public void setSchoolAddress(String schoolAddress) {
		this.schoolAddress = schoolAddress;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "DependentDetailsEntity [employeeId=" + employeeId + ", dependentSerialNo=" + dependentSerialNo
				+ ", name=" + name + ", classNo=" + classNo + ", admisibleFeeClaimAmount=" + admisibleFeeClaimAmount
				+ ", age=" + age + ", schoolName=" + schoolName + ", schoolAddress=" + schoolAddress + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + "]";
	}

}
