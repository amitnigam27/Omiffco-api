package com.omifco.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EMP_ROLE")
public class EmployeeRoleEntity {
	
	@Id
	@Column(name="ROLE_ID")
    private int roleId;
	
	@Column(name="ROLE")
    private String role;

	/**
	 * @return the roleId
	 */
	public int getRoleId() {
		return roleId;
	}


	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}


	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}


	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}


	@Override
	public String toString() {
		return "EmployeeRoleEntity [roleId=" + roleId + ", role=" + role + "]";
	}	
}
