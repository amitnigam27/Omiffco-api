package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveDetailsId;

@Entity
@Table(name = "WFL_TIM_EMP_LEAVE_DTLS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(WorkflowLeaveDetailsId.class)
public class WorkflowLeaveDetailsEntity {
	
	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_CODE")
    private int documentCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_SNO")
    private int documentSerialNo;
	
	@Id
	@Column(name="PERIOD_FROM")
    private Date periodFrom;
	
	@Column(name="PERIOD_TO")
    private Date periodTo;
	
	@Column(name="LV_TYPE_CODE")
    private String leaveTypeCode;
	
	@Column(name="LV_PAY_FLAG")
    private int leavePayFlag;
	
	@Column(name="LEAVE_DAYS")
    private int leaveDays;
	
	@Column(name="ABSENT_DAYS")
    private int absentDays;
	
	@Column(name="LV_PURPOSE_CODE")
    private int leavePurposeCode;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentCode
	 */
	public int getDocumentCode() {
		return documentCode;
	}

	/**
	 * @param documentCode the documentCode to set
	 */
	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	/**
	 * @return the documentSerialNo
	 */
	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	/**
	 * @param documentSerialNo the documentSerialNo to set
	 */
	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	/**
	 * @return the periodFrom
	 */
	public Date getPeriodFrom() {
		return periodFrom;
	}

	/**
	 * @param periodFrom the periodFrom to set
	 */
	public void setPeriodFrom(Date periodFrom) {
		this.periodFrom = periodFrom;
	}

	/**
	 * @return the periodTo
	 */
	public Date getPeriodTo() {
		return periodTo;
	}

	/**
	 * @param periodTo the periodTo to set
	 */
	public void setPeriodTo(Date periodTo) {
		this.periodTo = periodTo;
	}

	/**
	 * @return the leaveTypeCode
	 */
	public String getLeaveTypeCode() {
		return leaveTypeCode;
	}

	/**
	 * @param leaveTypeCode the leaveTypeCode to set
	 */
	public void setLeaveTypeCode(String leaveTypeCode) {
		this.leaveTypeCode = leaveTypeCode;
	}

	/**
	 * @return the leavePayFlag
	 */
	public int getLeavePayFlag() {
		return leavePayFlag;
	}

	/**
	 * @param leavePayFlag the leavePayFlag to set
	 */
	public void setLeavePayFlag(int leavePayFlag) {
		this.leavePayFlag = leavePayFlag;
	}

	/**
	 * @return the leaveDays
	 */
	public int getLeaveDays() {
		return leaveDays;
	}

	/**
	 * @param leaveDays the leaveDays to set
	 */
	public void setLeaveDays(int leaveDays) {
		this.leaveDays = leaveDays;
	}

	/**
	 * @return the absentDays
	 */
	public int getAbsentDays() {
		return absentDays;
	}

	/**
	 * @param absentDays the absentDays to set
	 */
	public void setAbsentDays(int absentDays) {
		this.absentDays = absentDays;
	}

	/**
	 * @return the leavePurposeCode
	 */
	public int getLeavePurposeCode() {
		return leavePurposeCode;
	}

	/**
	 * @param leavePurposeCode the leavePurposeCode to set
	 */
	public void setLeavePurposeCode(int leavePurposeCode) {
		this.leavePurposeCode = leavePurposeCode;
	}

	@Override
	public String toString() {
		return "WorkflowLeaveDetailsEntity [unitCode=" + unitCode + ", documentCode=" + documentCode
				+ ", documentSerialNo=" + documentSerialNo + ", periodFrom=" + periodFrom + ", periodTo=" + periodTo
				+ ", leaveTypeCode=" + leaveTypeCode + ", leavePayFlag=" + leavePayFlag + ", leaveDays=" + leaveDays
				+ ", absentDays=" + absentDays + ", leavePurposeCode=" + leavePurposeCode + "]";
	}

}
