package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveHeaderId;

@Entity
@Table(name="WFL_PRS_EXCESS_BAG_CLAIM_HDRS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(WorkflowLeaveHeaderId.class)
public class WorkFlowExcessBaggageClaimHdrsEntity {

	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_CODE")
    private int documentCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_SNO")
    private int documentSerialNo; 
	
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="CLAIM_DATE")
    private Date claimDate;
	
	@Column(name="CLAIM_CODE")
    private String claimCode;
	
	@Column(name="CLAIM_YEAR")
    private String claimYear;
	
	@Column(name="APPLICATION_TYPE")
    private String applicationType;
	
	@Column(name="ADMISSIBLE_AMOUNT")
    private double admissibleAmount;
	
	@Column(name="CURRENCY_CODE")
    private String currencyCode;
	
	@Column(name="CURRENCY_RATE")
    private double currencyRate;
	
	@Column(name="EXCESS_WT")
    private int excessWeight;

	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public int getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Date getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(Date claimDate) {
		this.claimDate = claimDate;
	}

	public String getClaimCode() {
		return claimCode;
	}

	public void setClaimCode(String claimCode) {
		this.claimCode = claimCode;
	}

	public String getClaimYear() {
		return claimYear;
	}

	public void setClaimYear(String claimYear) {
		this.claimYear = claimYear;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public double getAdmissibleAmount() {
		return admissibleAmount;
	}

	public void setAdmissibleAmount(double admissibleAmount) {
		this.admissibleAmount = admissibleAmount;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public double getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(double currencyRate) {
		this.currencyRate = currencyRate;
	}

	public int getExcessWeight() {
		return excessWeight;
	}

	public void setExcessWeight(int excessWeight) {
		this.excessWeight = excessWeight;
	}

	@Override
	public String toString() {
		return "WorkFlowExcessBaggageClaimHdrsEntity [unitCode=" + unitCode + ", documentCode=" + documentCode
				+ ", documentSerialNo=" + documentSerialNo + ", employeeId=" + employeeId + ", claimDate=" + claimDate
				+ ", claimCode=" + claimCode + ", claimYear=" + claimYear + ", applicationType=" + applicationType
				+ ", admissibleAmount=" + admissibleAmount + ", currencyCode=" + currencyCode + ", currencyRate="
				+ currencyRate + ", excessWeight=" + excessWeight + "]";
	}
	
	
}
