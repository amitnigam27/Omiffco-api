package com.omifco.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveHeaderId;

@Entity
@Table(name = "WFL_MED_BILL_REIMB_HDRS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(WorkflowLeaveHeaderId.class)
public class WorkflowMedBillReimbHeaderEntity {

	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_CODE")
    private int documentCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_SNO")
    private int documentSerialNo;
	
	@Column(name="APPLICATION_TYPE")
    private String applicationType;
	
	@Column(name="BILL_TYPE")
    private String billType;
	
	@Column(name="SANCTION_NO")
    private String sanctionNo;
	
	@Column(name="DIR_PAY_TO_HOSP")
    private boolean dirPayToHosp;
	
	@Column(name="HOSPITAL_CODE")
    private String hospitalCode;
	
	@Column(name="CLAIMED_AMOUNT")
    private double claimedAmount;
	
	@Column(name="ADMISSIBLE_AMOUNT")
    private double admissibleAmount;
	
	@Column(name="CURRENCY_CODE")
    private String currencyCode;
	
	@Column(name="CURRENCY_RATE")
    private double currencyRate;
	
	@Column(name="APPROVED_AMOUNT")
    private double approvedAmount;
	
	@Column(name="ADVANCE_ADJUSTED", nullable = true)
    private double advanceAdjusted;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentCode
	 */
	public int getDocumentCode() {
		return documentCode;
	}

	/**
	 * @param documentCode the documentCode to set
	 */
	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	/**
	 * @return the documentSerialNo
	 */
	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	/**
	 * @param documentSerialNo the documentSerialNo to set
	 */
	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	/**
	 * @return the applicationType
	 */
	public String getApplicationType() {
		return applicationType;
	}

	/**
	 * @param applicationType the applicationType to set
	 */
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	/**
	 * @return the billType
	 */
	public String getBillType() {
		return billType;
	}

	/**
	 * @param billType the billType to set
	 */
	public void setBillType(String billType) {
		this.billType = billType;
	}

	/**
	 * @return the sanctionNo
	 */
	public String getSanctionNo() {
		return sanctionNo;
	}

	/**
	 * @param sanctionNo the sanctionNo to set
	 */
	public void setSanctionNo(String sanctionNo) {
		this.sanctionNo = sanctionNo;
	}

	/**
	 * @return the dirPayToHosp
	 */
	public boolean isDirPayToHosp() {
		return dirPayToHosp;
	}

	/**
	 * @param dirPayToHosp the dirPayToHosp to set
	 */
	public void setDirPayToHosp(boolean dirPayToHosp) {
		this.dirPayToHosp = dirPayToHosp;
	}

	/**
	 * @return the hospitalCode
	 */
	public String getHospitalCode() {
		return hospitalCode;
	}

	/**
	 * @param hospitalCode the hospitalCode to set
	 */
	public void setHospitalCode(String hospitalCode) {
		this.hospitalCode = hospitalCode;
	}

	/**
	 * @return the claimedAmount
	 */
	public double getClaimedAmount() {
		return claimedAmount;
	}

	/**
	 * @param claimedAmount the claimedAmount to set
	 */
	public void setClaimedAmount(double claimedAmount) {
		this.claimedAmount = claimedAmount;
	}

	/**
	 * @return the admissibleAmount
	 */
	public double getAdmissibleAmount() {
		return admissibleAmount;
	}

	/**
	 * @param admissibleAmount the admissibleAmount to set
	 */
	public void setAdmissibleAmount(double admissibleAmount) {
		this.admissibleAmount = admissibleAmount;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the currencyRate
	 */
	public double getCurrencyRate() {
		return currencyRate;
	}

	/**
	 * @param currencyRate the currencyRate to set
	 */
	public void setCurrencyRate(double currencyRate) {
		this.currencyRate = currencyRate;
	}

	/**
	 * @return the approvedAmount
	 */
	public double getApprovedAmount() {
		return approvedAmount;
	}

	/**
	 * @param approvedAmount the approvedAmount to set
	 */
	public void setApprovedAmount(double approvedAmount) {
		this.approvedAmount = approvedAmount;
	}

	/**
	 * @return the advanceAdjusted
	 */
	public double getAdvanceAdjusted() {
		return advanceAdjusted;
	}

	/**
	 * @param advanceAdjusted the advanceAdjusted to set
	 */
	public void setAdvanceAdjusted(double advanceAdjusted) {
		this.advanceAdjusted = advanceAdjusted;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WorkflowMedBillReimbHeaderEntity [unitCode=" + unitCode + ", documentCode=" + documentCode
				+ ", documentSerialNo=" + documentSerialNo + ", applicationType=" + applicationType + ", billType="
				+ billType + ", sanctionNo=" + sanctionNo + ", dirPayToHosp=" + dirPayToHosp + ", hospitalCode="
				+ hospitalCode + ", claimedAmount=" + claimedAmount + ", admissibleAmount=" + admissibleAmount
				+ ", currencyCode=" + currencyCode + ", currencyRate=" + currencyRate + ", approvedAmount="
				+ approvedAmount + ", advanceAdjusted=" + advanceAdjusted + "]";
	}
	
}
