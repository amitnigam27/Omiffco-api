package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "APPLICATION")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class ApplicationEntity {
	
	@Id
	@Column(name="APPLICATION_ID")
    private int appId;
	
	@Column(name="APPLICATION_TYPE")
    private String appType;
	
	@Column(name="EMPLOYEE_ID")
    private String employeeId;
	
	@Column(name="REQUESTED_DATE")
    private Date requestedDate;
	
	@Column(name="APPLICATION_STATUS")
    private String appStatus;
	
	@Column(name="META_INFO")
    private int metaInfo;

	/**
	 * @return the appId
	 */
	public int getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(int appId) {
		this.appId = appId;
	}

	/**
	 * @return the appType
	 */
	public String getAppType() {
		return appType;
	}

	/**
	 * @param appType the appType to set
	 */
	public void setAppType(String appType) {
		this.appType = appType;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the requestedDate
	 */
	public Date getRequestedDate() {
		return requestedDate;
	}

	/**
	 * @param requestedDate the requestedDate to set
	 */
	public void setRequestedDate(Date requestedDate) {
		this.requestedDate = requestedDate;
	}

	/**
	 * @return the appStatus
	 */
	public String getAppStatus() {
		return appStatus;
	}

	/**
	 * @param appStatus the appStatus to set
	 */
	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}

	/**
	 * @return the metaInfo
	 */
	public int getMetaInfo() {
		return metaInfo;
	}

	/**
	 * @param metaInfo the metaInfo to set
	 */
	public void setMetaInfo(int metaInfo) {
		this.metaInfo = metaInfo;
	}

	@Override
	public String toString() {
		return "ApplicationEntity [appId=" + appId + ", appType=" + appType + ", employeeId=" + employeeId
				+ ", requestedDate=" + requestedDate + ", appStatus=" + appStatus + ", metaInfo=" + metaInfo + "]";
	}	
}
