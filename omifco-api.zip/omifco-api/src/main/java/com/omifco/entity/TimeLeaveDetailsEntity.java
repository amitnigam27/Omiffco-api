package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.TimeLeaveDetailsId;

@Entity
@Table(name = "TIM_EMP_LEAVE_DTLS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(TimeLeaveDetailsId.class)
public class TimeLeaveDetailsEntity {
	
	@Id
	@Column(name="UNIT_CODE",updatable = false)
    private int unitCode;
	
	@Id
	@Column(name="DOCCUMENT_NO",updatable = false)
    private int documentNumber;
	
	@Column(name="PERSONAL_NO",updatable = false)
    private String employeeId;
	
	@Column(name="PERIOD_FROM",updatable = false)
    private Date periodFrom;
	
	@Column(name="PERIOD_TO",updatable = false)
    private Date periodTo;
	
	@Column(name="LV_TYPE_CODE",updatable = false)
    private String leaveTypeCode;
	
	@Column(name="LV_PAY_FLAG",updatable = false)
    private int leavePayFlag;
	
	@Column(name="LEAVE_DAYS",updatable = false)
    private double leaveDays;
	
	@Column(name="ABSENT_DAYS")
    private double absentDays;
	
	@Column(name="LEAVE_STATUS")
    private String leaveStatus;
	
	@Column(name="LV_PURPOSE_CODE",updatable = false)
    private int leavePurposeCode;
	
	@Column(name="CREATED_BY",updatable = false)
    private String createdBy;
	
	@Column(name="DATETIME_CREATED",updatable = false)
    private Date createdDate;
	
	@Column(name="MODIFIED_BY")
    private String modifiedBy;
	
	@Column(name="DATETIME_MODIFIED")
    private Date modifiedDate;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentNumber
	 */
	public int getDocumentNumber() {
		return documentNumber;
	}

	/**
	 * @param documentNumber the documentNumber to set
	 */
	public void setDocumentNumber(int documentNumber) {
		this.documentNumber = documentNumber;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the periodFrom
	 */
	public Date getPeriodFrom() {
		return periodFrom;
	}

	/**
	 * @param periodFrom the periodFrom to set
	 */
	public void setPeriodFrom(Date periodFrom) {
		this.periodFrom = periodFrom;
	}

	/**
	 * @return the periodTo
	 */
	public Date getPeriodTo() {
		return periodTo;
	}

	/**
	 * @param periodTo the periodTo to set
	 */
	public void setPeriodTo(Date periodTo) {
		this.periodTo = periodTo;
	}

	/**
	 * @return the leaveTypeCode
	 */
	public String getLeaveTypeCode() {
		return leaveTypeCode;
	}

	/**
	 * @param leaveTypeCode the leaveTypeCode to set
	 */
	public void setLeaveTypeCode(String leaveTypeCode) {
		this.leaveTypeCode = leaveTypeCode;
	}

	/**
	 * @return the leavePayFlag
	 */
	public int getLeavePayFlag() {
		return leavePayFlag;
	}

	/**
	 * @param leavePayFlag the leavePayFlag to set
	 */
	public void setLeavePayFlag(int leavePayFlag) {
		this.leavePayFlag = leavePayFlag;
	}

	/**
	 * @return the leaveDays
	 */
	public double getLeaveDays() {
		return leaveDays;
	}

	/**
	 * @param leaveDays the leaveDays to set
	 */
	public void setLeaveDays(double leaveDays) {
		this.leaveDays = leaveDays;
	}

	/**
	 * @return the absentDays
	 */
	public double getAbsentDays() {
		return absentDays;
	}

	/**
	 * @param absentDays the absentDays to set
	 */
	public void setAbsentDays(double absentDays) {
		this.absentDays = absentDays;
	}

	/**
	 * @return the leaveStatus
	 */
	public String getLeaveStatus() {
		return leaveStatus;
	}

	/**
	 * @param leaveStatus the leaveStatus to set
	 */
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}

	/**
	 * @return the leavePurposeCode
	 */
	public int getLeavePurposeCode() {
		return leavePurposeCode;
	}

	/**
	 * @param leavePurposeCode the leavePurposeCode to set
	 */
	public void setLeavePurposeCode(int leavePurposeCode) {
		this.leavePurposeCode = leavePurposeCode;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "TimeLeaveDetailsEntity [unitCode=" + unitCode + ", documentNumber=" + documentNumber + ", employeeId="
				+ employeeId + ", periodFrom=" + periodFrom + ", periodTo=" + periodTo + ", leaveTypeCode="
				+ leaveTypeCode + ", leavePayFlag=" + leavePayFlag + ", leaveDays=" + leaveDays + ", absentDays="
				+ absentDays + ", leaveStatus=" + leaveStatus + ", leavePurposeCode=" + leavePurposeCode
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", modifiedBy=" + modifiedBy
				+ ", modifiedDate=" + modifiedDate + "]";
	}

}
