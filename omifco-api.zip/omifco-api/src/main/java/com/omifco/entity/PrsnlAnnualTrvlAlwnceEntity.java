/**
 * 
 */
package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.PrsnlAnnualTrvlAlwnceId;

/**
 * @author Anigam
 *
 */
@Entity
@Table(name="PRS_ANNUAL_TRAVEL_ALLOWANCE")
@IdClass(PrsnlAnnualTrvlAlwnceId.class)
@JsonIgnoreProperties(ignoreUnknown=true)
@JsonInclude(Include.NON_NULL)
public class PrsnlAnnualTrvlAlwnceEntity {
	
	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="HRMS_SEQ_NO")
    private int hrmsSeqNo;
	
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="CLAIM_YEAR")
    private int claimYear;
	
	@Column(name="CLAIM_DATE")
    private Date claimDate;
	
	@Column(name="CLAIM_AMOUNT")
    private double claimAmount;
	
	@Column(name="APPROVED_AMOUNT")
    private double approvedAmount;
	
	@Column(name="ELIGIBLE_AMOUNT")
    private double eligibleAmount;
	
	@Column(name="RECOMEND_BY")
    private String recommendBy;
	
	@Column(name="RECOMEND_DATE")
    private Date recommendDate;
	
	@Column(name="APPROVED_BY")
    private String approvedBy;
	
	@Column(name="APPROVED_DATE")
    private Date approvedDate;
	
	@Column(name="CREATED_BY",updatable = false)
    private String createdBy;
	
	@Column(name="DATETIME_CREATED",updatable = false)
    private Date createdDate;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the hrmsSeqNo
	 */
	public int getHrmsSeqNo() {
		return hrmsSeqNo;
	}

	/**
	 * @param hrmsSeqNo the hrmsSeqNo to set
	 */
	public void setHrmsSeqNo(int hrmsSeqNo) {
		this.hrmsSeqNo = hrmsSeqNo;
	}

	/**
	 * @return the claimYear
	 */
	public int getClaimYear() {
		return claimYear;
	}

	/**
	 * @param claimYear the claimYear to set
	 */
	public void setClaimYear(int claimYear) {
		this.claimYear = claimYear;
	}

	/**
	 * @return the claimDate
	 */
	public Date getClaimDate() {
		return claimDate;
	}

	/**
	 * @param claimDate the claimDate to set
	 */
	public void setClaimDate(Date claimDate) {
		this.claimDate = claimDate;
	}

	/**
	 * @return the claimAmount
	 */
	public double getClaimAmount() {
		return claimAmount;
	}

	/**
	 * @param claimAmount the claimAmount to set
	 */
	public void setClaimAmount(double claimAmount) {
		this.claimAmount = claimAmount;
	}

	/**
	 * @return the approvedAmount
	 */
	public double getApprovedAmount() {
		return approvedAmount;
	}

	/**
	 * @param approvedAmount the approvedAmount to set
	 */
	public void setApprovedAmount(double approvedAmount) {
		this.approvedAmount = approvedAmount;
	}

	/**
	 * @return the eligibleAmount
	 */
	public double getEligibleAmount() {
		return eligibleAmount;
	}

	/**
	 * @param eligibleAmount the eligibleAmount to set
	 */
	public void setEligibleAmount(double eligibleAmount) {
		this.eligibleAmount = eligibleAmount;
	}

	/**
	 * @return the recommendBy
	 */
	public String getRecommendBy() {
		return recommendBy;
	}

	/**
	 * @param recommendBy the recommendBy to set
	 */
	public void setRecommendBy(String recommendBy) {
		this.recommendBy = recommendBy;
	}

	/**
	 * @return the recommendDate
	 */
	public Date getRecommendDate() {
		return recommendDate;
	}

	/**
	 * @param recommendDate the recommendDate to set
	 */
	public void setRecommendDate(Date recommendDate) {
		this.recommendDate = recommendDate;
	}

	/**
	 * @return the approvedBy
	 */
	public String getApprovedBy() {
		return approvedBy;
	}

	/**
	 * @param approvedBy the approvedBy to set
	 */
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	/**
	 * @return the approvedDate
	 */
	public Date getApprovedDate() {
		return approvedDate;
	}

	/**
	 * @param approvedDate the approvedDate to set
	 */
	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PrsnlAnnualTrvlAlwnceEntity [unitCode=" + unitCode + ", hrmsSeqNo=" + hrmsSeqNo + ", employeeId="
				+ employeeId + ", claimYear=" + claimYear + ", claimDate=" + claimDate + ", claimAmount=" + claimAmount
				+ ", approvedAmount=" + approvedAmount + ", eligibleAmount=" + eligibleAmount + ", recommendBy="
				+ recommendBy + ", recommendDate=" + recommendDate + ", approvedBy=" + approvedBy + ", approvedDate="
				+ approvedDate + ", createdBy=" + createdBy + ", createdDate=" + createdDate + "]";
	}
	
	
}
