package com.omifco.entity;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveHeaderId;

@Entity
@Table(name="WFL_TIM_EMP_TOUR_DTLS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(WorkflowLeaveHeaderId.class)
public class WorkFlowTimEmployeeTourDetailsEntity {

	@Id
	@Column(name="UNIT_CODE")
	private int unitCode;

	@Id
	@Column(name="WF_DOCCUMENT_CODE")
	private int documentCode;

	@Id
	@Column(name="WF_DOCCUMENT_SNO")
	private int documentSerialNo;

	@Column(name="DTLS_SNO")
	private int detailsSNumber;

	@Column(name="STATION_FROM")
	private String stationFrom;

	@Column(name="DEPARTURE_DATE")
	private Date departureDate;

	@Column(name="DEPARTURE_TIME")
	private Date departureTime;

	@Column(name="STATION_TO")
	private String stationTo;

	@Column(name="ARIVAL_DATE")
	private Date arrivalDate;

	@Column(name="ARIVAL_TIME")
	private Date arrivalTime;

	@Column(name="MODE_OF_TRAVEL")
	private String travelMode;

	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}


	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public int getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	public int getDetailsSNumber() {
		return detailsSNumber;
	}

	public void setDetailsSNumber(int detailsSNumber) {
		this.detailsSNumber = detailsSNumber;
	}

	public String getStationFrom() {
		return stationFrom;
	}

	public void setStationFrom(String stationFrom) {
		this.stationFrom = stationFrom;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}

	public String getStationTo() {
		return stationTo;
	}

	public void setStationTo(String stationTo) {
		this.stationTo = stationTo;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public Date getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getTravelMode() {
		return travelMode;
	}

	public void setTravelMode(String travelMode) {
		this.travelMode = travelMode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WorkFlowTimEmployeeTourDetailsEntity [unitCode=" + unitCode + ", documentCode=" + documentCode
				+ ", documentSerialNo=" + documentSerialNo + ", detailsSNumber=" + detailsSNumber + ", stationFrom="
				+ stationFrom + ", departureDate=" + departureDate + ", departureTime=" + departureTime + ", stationTo="
				+ stationTo + ", arrivalDate=" + arrivalDate + ", arrivalTime=" + arrivalTime + ", travelMode="
				+ travelMode + "]";
	}



}
