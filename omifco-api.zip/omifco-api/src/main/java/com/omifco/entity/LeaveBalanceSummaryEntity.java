package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TIM_EMP_LEAVE_OPBAL")
public class LeaveBalanceSummaryEntity {
	
	@Id
	@Column(name="LEAVE_OPBAL_ID",updatable = false)
    private int id;
	
	@Column(name="PERSONAL_NO",updatable = false)
    private String employeeId;
	
	@Column(name="ACCRUAL_YEAR",updatable = false)
    private String accrualYear;
	
	@Column(name="LV_TYPE_CODE",updatable = false)
    private String leaveTypeCode;

	@Column(name="LV_PAY_FLAG",updatable = false)
    private int payFlag;
	
	@Column(name="OPENING_DATE",updatable = false)
    private Date openingDate;
	
	@Column(name="OPENING_LEAVE_BAL",updatable = false)
    private double openingLeaveBalance;
	
	@Column(name="OPENING_ENCASHABLE",updatable = false)
    private double openingEncahableLeave;
	
	@Column(name="VALIDITY_MONTHS",updatable = false)
    private int validity;
	
	@Column(name="LEAVE_TAKEN_BV")
    private double leaveTakenBV;
	
	@Column(name="LEAVE_TAKEN_AV")
    private double leaveTakenAV;
	
	@Column(name="ACCRUAL_DATE",updatable = false)
    private Date accrualDate;
	
	@Column(name="LEAVES_ACCRUED",updatable = false)
    private double accruedLeaves;
	
	@Column(name="BALANCE_DAYS")
    private double balanceDays;
	
	@Column(name="UNIT_CODE",updatable = false)
    private int unitCode;
	
	@Column(name="CREATED_BY",updatable = false)
    private String createdBy;
	
	@Column(name="DATETIME_CREATED",updatable = false)
    private Date dateOfCreation;
	
	@Column(name="MODIFIED_BY")
    private String modifiedBy;
	
	@Column(name="DATETIME_MODIFIED")
    private Date dateOfModification;
	
	@Column(name="LAPSED_LEAVES")
    private double lapsedLeaves;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the accrualYear
	 */
	public String getAccrualYear() {
		return accrualYear;
	}

	/**
	 * @param accrualYear the accrualYear to set
	 */
	public void setAccrualYear(String accrualYear) {
		this.accrualYear = accrualYear;
	}

	/**
	 * @return the leaveTypeCode
	 */
	public String getLeaveTypeCode() {
		return leaveTypeCode;
	}

	/**
	 * @param leaveTypeCode the leaveTypeCode to set
	 */
	public void setLeaveTypeCode(String leaveTypeCode) {
		this.leaveTypeCode = leaveTypeCode;
	}

	/**
	 * @return the payFlag
	 */
	public int getPayFlag() {
		return payFlag;
	}

	/**
	 * @param payFlag the payFlag to set
	 */
	public void setPayFlag(int payFlag) {
		this.payFlag = payFlag;
	}

	/**
	 * @return the openingDate
	 */
	public Date getOpeningDate() {
		return openingDate;
	}

	/**
	 * @param openingDate the openingDate to set
	 */
	public void setOpeningDate(Date openingDate) {
		this.openingDate = openingDate;
	}

	/**
	 * @return the openingLeaveBalance
	 */
	public double getOpeningLeaveBalance() {
		return openingLeaveBalance;
	}

	/**
	 * @param openingLeaveBalance the openingLeaveBalance to set
	 */
	public void setOpeningLeaveBalance(double openingLeaveBalance) {
		this.openingLeaveBalance = openingLeaveBalance;
	}

	/**
	 * @return the openingEncahableLeave
	 */
	public double getOpeningEncahableLeave() {
		return openingEncahableLeave;
	}

	/**
	 * @param openingEncahableLeave the openingEncahableLeave to set
	 */
	public void setOpeningEncahableLeave(double openingEncahableLeave) {
		this.openingEncahableLeave = openingEncahableLeave;
	}

	/**
	 * @return the validity
	 */
	public int getValidity() {
		return validity;
	}

	/**
	 * @param validity the validity to set
	 */
	public void setValidity(int validity) {
		this.validity = validity;
	}

	/**
	 * @return the leaveTakenBV
	 */
	public double getLeaveTakenBV() {
		return leaveTakenBV;
	}

	/**
	 * @param leaveTakenBV the leaveTakenBV to set
	 */
	public void setLeaveTakenBV(double leaveTakenBV) {
		this.leaveTakenBV = leaveTakenBV;
	}

	/**
	 * @return the leaveTakenAV
	 */
	public double getLeaveTakenAV() {
		return leaveTakenAV;
	}

	/**
	 * @param leaveTakenAV the leaveTakenAV to set
	 */
	public void setLeaveTakenAV(double leaveTakenAV) {
		this.leaveTakenAV = leaveTakenAV;
	}

	/**
	 * @return the accrualDate
	 */
	public Date getAccrualDate() {
		return accrualDate;
	}

	/**
	 * @param accrualDate the accrualDate to set
	 */
	public void setAccrualDate(Date accrualDate) {
		this.accrualDate = accrualDate;
	}

	/**
	 * @return the accruedLeaves
	 */
	public double getAccruedLeaves() {
		return accruedLeaves;
	}

	/**
	 * @param accruedLeaves the accruedLeaves to set
	 */
	public void setAccruedLeaves(double accruedLeaves) {
		this.accruedLeaves = accruedLeaves;
	}

	/**
	 * @return the balanceDays
	 */
	public double getBalanceDays() {
		return balanceDays;
	}

	/**
	 * @param balanceDays the balanceDays to set
	 */
	public void setBalanceDays(double balanceDays) {
		this.balanceDays = balanceDays;
	}

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the dateOfCreation
	 */
	public Date getDateOfCreation() {
		return dateOfCreation;
	}

	/**
	 * @param dateOfCreation the dateOfCreation to set
	 */
	public void setDateOfCreation(Date dateOfCreation) {
		this.dateOfCreation = dateOfCreation;
	}

	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return the dateOfModification
	 */
	public Date getDateOfModification() {
		return dateOfModification;
	}

	/**
	 * @param dateOfModification the dateOfModification to set
	 */
	public void setDateOfModification(Date dateOfModification) {
		this.dateOfModification = dateOfModification;
	}

	/**
	 * @return the lapsedLeaves
	 */
	public double getLapsedLeaves() {
		return lapsedLeaves;
	}

	/**
	 * @param lapsedLeaves the lapsedLeaves to set
	 */
	public void setLapsedLeaves(double lapsedLeaves) {
		this.lapsedLeaves = lapsedLeaves;
	}

	@Override
	public String toString() {
		return "LeaveSummaryEntity [id=" + id + ", employeeId=" + employeeId + ", accrualYear=" + accrualYear
				+ ", leaveTypeCode=" + leaveTypeCode + ", payFlag=" + payFlag + ", openingDate=" + openingDate
				+ ", openingLeaveBalance=" + openingLeaveBalance + ", openingEncahableLeave=" + openingEncahableLeave
				+ ", validity=" + validity + ", leaveTakenBV=" + leaveTakenBV + ", leaveTakenAV=" + leaveTakenAV
				+ ", accrualDate=" + accrualDate + ", accruedLeaves=" + accruedLeaves + ", balanceDays=" + balanceDays
				+ ", unitCode=" + unitCode + ", createdBy=" + createdBy + ", dateOfCreation=" + dateOfCreation
				+ ", modifiedBy=" + modifiedBy + ", dateOfModification=" + dateOfModification + ", lapsedLeaves="
				+ lapsedLeaves + "]";
	}

	
}
