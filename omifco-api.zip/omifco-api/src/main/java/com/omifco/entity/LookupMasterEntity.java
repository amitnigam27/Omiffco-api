package com.omifco.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "LOOKUP_MASTER")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class LookupMasterEntity {
	
	@Id
	@Column(name="LOOKUP_ID")
    private int id;
	
	@Column(name="LOOKUP_TYPE")
    private String lookupType;
	
	@Column(name="LOOKUP_CODE")
    private String lookupCode;
	
	@Column(name="LOOKUP_NAME")
    private String lookupName;
	
	@Column(name="IS_ACTIVE")
    private boolean isActive;
	
	@Column(name="RELATED_TO")
    private String relatedTo;

	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the lookupType
	 */
	public String getLookupType() {
		return lookupType;
	}

	/**
	 * @param lookupType the lookupType to set
	 */
	public void setLookupType(String lookupType) {
		this.lookupType = lookupType;
	}

	/**
	 * @return the lookupCode
	 */
	public String getLookupCode() {
		return lookupCode;
	}

	/**
	 * @param lookupCode the lookupCode to set
	 */
	public void setLookupCode(String lookupCode) {
		this.lookupCode = lookupCode;
	}

	/**
	 * @return the lookupName
	 */
	public String getLookupName() {
		return lookupName;
	}

	/**
	 * @param lookupName the lookupName to set
	 */
	public void setLookupName(String lookupName) {
		this.lookupName = lookupName;
	}

	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the relatedTo
	 */
	public String getRelatedTo() {
		return relatedTo;
	}

	/**
	 * @param relatedTo the relatedTo to set
	 */
	public void setRelatedTo(String relatedTo) {
		this.relatedTo = relatedTo;
	}

	@Override
	public String toString() {
		return "LookupMasterEntity [id=" + id + ", lookupType=" + lookupType + ", lookupCode=" + lookupCode
				+ ", lookupName=" + lookupName + ", isActive=" + isActive + ", relatedTo=" + relatedTo + "]";
	}

	
}
