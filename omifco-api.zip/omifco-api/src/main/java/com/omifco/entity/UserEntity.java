package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.omifco.dto.StatusDTO;

@Entity
@Table(name = "USER_INFO")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserEntity {
	
	@Id
	@Column(name="EMPLOYEE_ID")
    private String employeeID;
	
	@Column(name="EMP_PASSWORD")
    private String password;
	
	@Column(name="EMP_EMAIL")
    private String email;
	
	@Column(name="EMP_NAME")
    private String employeeName;
	
	@Column(name="EMP_DOB")
    private Date dob;
	
	@Column(name="EMP_CONTACT")
    private String contact;
	
	@Column(name="EMP_GENDER")
    private String gender;
	
	@Column(name="EMP_MARTIALSTATUS")
    private String martialStatus;
	
	@Column(name="EMP_DEPARTMENT")
    private String department;
	
	@Column(name="EMP_DESIGNATION")
    private String designation;
	
	@Column(name="EMP_DEVICE")
    private String device;
	
	@Column(name="EMP_DEVICE_TOKEN")
    private String deviceToken;
	
	@Transient
	@JsonProperty("status")
	private StatusDTO statusDto;
	
	@ManyToOne(optional = false)
    @JoinColumn(name="ROLE_ID")
	private EmployeeRoleEntity role;
	
	@Transient
	private String token;

	/**
	 * @return the employeeID
	 */
	public String getEmployeeID() {
		return employeeID;
	}



	/**
	 * @param employeeID the employeeID to set
	 */
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}



	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}



	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}



	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}



	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}



	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}



	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}



	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}



	/**
	 * @param dob the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}



	/**
	 * @return the contact
	 */
	public String getContact() {
		return contact;
	}



	/**
	 * @param contact the contact to set
	 */
	public void setContact(String contact) {
		this.contact = contact;
	}



	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}



	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}



	/**
	 * @return the martialStatus
	 */
	public String getMartialStatus() {
		return martialStatus;
	}



	/**
	 * @param martialStatus the martialStatus to set
	 */
	public void setMartialStatus(String martialStatus) {
		this.martialStatus = martialStatus;
	}



	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}



	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}



	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}



	/**
	 * @param designation the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}



	/**
	 * @return the statusDto
	 */
	public StatusDTO getStatusDto() {
		return statusDto;
	}



	/**
	 * @param statusDto the statusDto to set
	 */
	public void setStatusDto(StatusDTO statusDto) {
		this.statusDto = statusDto;
	}



	/**
	 * @return the role
	 */
	public EmployeeRoleEntity getRole() {
		return role;
	}



	/**
	 * @param role the role to set
	 */
	public void setRole(EmployeeRoleEntity role) {
		this.role = role;
	}

	/**
	 * @return the device
	 */
	public String getDevice() {
		return device;
	}

	/**
	 * @param device the device to set
	 */
	public void setDevice(String device) {
		this.device = device;
	}



	/**
	 * @return the deviceToken
	 */
	public String getDeviceToken() {
		return deviceToken;
	}

	/**
	 * @param deviceToken the deviceToken to set
	 */
	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	@Override
	public String toString() {
		return "UserEntity [employeeID=" + employeeID + ", password=" + password + ", email=" + email
				+ ", employeeName=" + employeeName + ", dob=" + dob + ", contact=" + contact + ", gender=" + gender
				+ ", martialStatus=" + martialStatus + ", department=" + department + ", designation=" + designation
				+ ", device=" + device + ", deviceToken=" + deviceToken + ", statusDto=" + statusDto + ", role=" + role
				+ ", token=" + token + "]";
	}


	

}
