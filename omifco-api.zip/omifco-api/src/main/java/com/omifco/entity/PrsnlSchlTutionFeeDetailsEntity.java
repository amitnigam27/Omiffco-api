package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.PrsnlSchlTutionFeeId;


@Entity
@Table(name = "PRS_SCHOOL_TUT_FEE_DTLS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(PrsnlSchlTutionFeeId.class)
public class PrsnlSchlTutionFeeDetailsEntity {
	
	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="CLAIM_YEAR")
    private int claimYear;
	
	@Id
	@Column(name="CLAIM_SRNO")
    private int claimSerialNo;
	
	@Column(name="DEPENDENT_SNO")
    private int dependentSerialNo;
	
	@Column(name="ADMISIBLE_AMOUNT")
    private double admisibleAmount;
	
	@Column(name="CLAIMED_AMOUNT")
    private double claimedAmount;
	
	@Column(name="CLASS")
    private String classNo;
	
	@Column(name="FEE_PAID")
    private double feePaid;

	@Column(name="AGE")
    private int age;
	
	@Column(name="STATUS")
    private String status;
	
	@Column(name="CREATED_BY",updatable = false)
    private String createdBy;
	
	@Column(name="DATETIME_CREATED",updatable = false)
    private Date createdDate;

	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public int getClaimYear() {
		return claimYear;
	}

	public void setClaimYear(int claimYear) {
		this.claimYear = claimYear;
	}

	public int getClaimSerialNo() {
		return claimSerialNo;
	}

	public void setClaimSerialNo(int claimSerialNo) {
		this.claimSerialNo = claimSerialNo;
	}

	public int getDependentSerialNo() {
		return dependentSerialNo;
	}

	public void setDependentSerialNo(int dependentSerialNo) {
		this.dependentSerialNo = dependentSerialNo;
	}

	public double getAdmisibleAmount() {
		return admisibleAmount;
	}

	public void setAdmisibleAmount(double admisibleAmount) {
		this.admisibleAmount = admisibleAmount;
	}

	public double getClaimedAmount() {
		return claimedAmount;
	}

	public void setClaimedAmount(double claimedAmount) {
		this.claimedAmount = claimedAmount;
	}

	public String getclassNo() {
		return classNo;
	}

	public void setclassNo(String classNo) {
		this.classNo = classNo;
	}

	public double getFeePaid() {
		return feePaid;
	}

	public void setFeePaid(double feePaid) {
		this.feePaid = feePaid;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "PrsnlSchlTutionFeeDetailsEntity [unitCode=" + unitCode + ", employeeId=" + employeeId + ", claimYear="
				+ claimYear + ", claimSerialNo=" + claimSerialNo + ", dependentSerialNo=" + dependentSerialNo
				+ ", admisibleAmount=" + admisibleAmount + ", claimedAmount=" + claimedAmount + ", classNo=" + classNo
				+ ", feePaid=" + feePaid + ", age=" + age + ", status=" + status + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + "]";
	}

}
