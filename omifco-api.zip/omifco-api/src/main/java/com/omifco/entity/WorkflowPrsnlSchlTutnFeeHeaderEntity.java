package com.omifco.entity;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveHeaderId;


@Entity
@Table(name = "WFL_PRS_SCHOOL_TUT_FEE_HDRS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(WorkflowLeaveHeaderId.class)
public class WorkflowPrsnlSchlTutnFeeHeaderEntity {
	 	
	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_CODE")
    private int documentCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_SNO")
    private int documentSerialNo;
	
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="CLAIM_YEAR")
    private int claimYear;
	
	@Column(name="CLAIM_SRNO")
    private int claimSerialNo;

	@Column(name="CLAIM_DATE")
    private Date claimDate;
	
	@Column(name="CLAIM_AMOUNT")
    private double claimAmount;
	
	@Column(name="CLAIMED_MEMBERS")
    private int claimedMembers;
	
	@Column(name="APPLICATION_TYPE")
    private String applicationType;
	
	@Column(name="RECOMEND_BY")
    private String recommendBy;
	
	@Column(name="RECOMEND_DATE")
    private Date recommendDate;
	
	@Column(name="APPROVED_BY")
    private String approvedBy;
	
	@Column(name="APPROVED_DATE")
    private Date approvedDate;
	
	@Column(name="APPROVED_AMOUNT")
    private double approvedAmount;
	
	@Column(name="EDUCATIONAL_YEAR")
    private int educationalYear;
	
	@Column(name="SCHOOL_NAME")
    private String schoolName;
	
	@Column(name="SCHOOL_ADDRESS")
    private String schoolAddress;
	
	@Column(name="CREATED_BY",updatable = false)
    private String createdBy;
	
	@Column(name="DATETIME_CREATED",updatable = false)
    private Date createdDate;

	public int getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	public int getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public int getClaimYear() {
		return claimYear;
	}

	public void setClaimYear(int claimYear) {
		this.claimYear = claimYear;
	}
	
	public int getClaimSerialNo() {
		return claimSerialNo;
	}

	public void setClaimSerialNo(int claimSerialNo) {
		this.claimSerialNo = claimSerialNo;
	}

	public Date getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(Date claimDate) {
		this.claimDate = claimDate;
	}

	public double getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(double claimAmount) {
		this.claimAmount = claimAmount;
	}

	public int getClaimedMembers() {
		return claimedMembers;
	}

	public void setClaimedMembers(int claimedMembers) {
		this.claimedMembers = claimedMembers;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getRecommendBy() {
		return recommendBy;
	}

	public void setRecommendBy(String recommendBy) {
		this.recommendBy = recommendBy;
	}

	public Date getRecommendDate() {
		return recommendDate;
	}

	public void setRecommendDate(Date recommendDate) {
		this.recommendDate = recommendDate;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public double getApprovedAmount() {
		return approvedAmount;
	}

	public void setApprovedAmount(double approvedAmount) {
		this.approvedAmount = approvedAmount;
	}

	public int getEducationalYear() {
		return educationalYear;
	}

	public void setEducationalYear(int educationalYear) {
		this.educationalYear = educationalYear;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolAddress() {
		return schoolAddress;
	}

	public void setSchoolAddress(String schoolAddress) {
		this.schoolAddress = schoolAddress;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "WorkflowPrsnlSchlTutnFeeHeaderEntity [unitCode=" + unitCode + ", documentCode=" + documentCode
				+ ", documentSerialNo=" + documentSerialNo + ", employeeId=" + employeeId + ", claimYear=" + claimYear
				+ ", claimSerialNo=" + claimSerialNo + ", claimDate=" + claimDate + ", claimAmount=" + claimAmount
				+ ", claimedMembers=" + claimedMembers + ", applicationType=" + applicationType + ", recommendBy="
				+ recommendBy + ", recommendDate=" + recommendDate + ", approvedBy=" + approvedBy + ", approvedDate="
				+ approvedDate + ", approvedAmount=" + approvedAmount + ", educationalYear=" + educationalYear
				+ ", schoolName=" + schoolName + ", schoolAddress=" + schoolAddress + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + "]";
	}
	
}
