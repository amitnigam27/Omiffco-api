/**
 * 
 */
package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.WorkflowLeaveHeaderId;

/**
 * @author Prolifics
 *
 */
@Entity
@Table(name = "WFL_PRS_ANNUAL_TRAV_ALLOWANCE")
@IdClass(WorkflowLeaveHeaderId.class)
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkflowPrsnlAnnualTrvlAlwnceEntity {

	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_CODE")
    private int documentCode;
	
	@Id
	@Column(name="WF_DOCCUMENT_SNO")
    private int documentSerialNo;
	
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="CLAIM_CODE")
    private String claimCode;
	
	@Column(name="CLAIM_YEAR")
    private int claimYear;
	
	@Column(name="CLAIM_DATE")
    private Date claimDate;
	
	@Column(name="CLAIM_AMOUNT")
    private double claimAmount;
	
	@Column(name="APPROVED_AMOUNT")
    private double approvedAmount;
	
	@Column(name="ELIGIBILTY_AMOUNT")
    private double eligibilityAmount;
	
	@Column(name="APPLICATION_TYPE")
    private String applicationType;
	
	@Column(name="APPLICATION_DATE")
    private Date applicationDate;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the documentCode
	 */
	public int getDocumentCode() {
		return documentCode;
	}

	/**
	 * @param documentCode the documentCode to set
	 */
	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	/**
	 * @return the documentSerialNo
	 */
	public int getDocumentSerialNo() {
		return documentSerialNo;
	}

	/**
	 * @param documentSerialNo the documentSerialNo to set
	 */
	public void setDocumentSerialNo(int documentSerialNo) {
		this.documentSerialNo = documentSerialNo;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the claimCode
	 */
	public String getClaimCode() {
		return claimCode;
	}

	/**
	 * @param claimCode the claimCode to set
	 */
	public void setClaimCode(String claimCode) {
		this.claimCode = claimCode;
	}

	/**
	 * @return the claimYear
	 */
	public int getClaimYear() {
		return claimYear;
	}

	/**
	 * @param claimYear the claimYear to set
	 */
	public void setClaimYear(int claimYear) {
		this.claimYear = claimYear;
	}

	/**
	 * @return the claimDate
	 */
	public Date getClaimDate() {
		return claimDate;
	}

	/**
	 * @param claimDate the claimDate to set
	 */
	public void setClaimDate(Date claimDate) {
		this.claimDate = claimDate;
	}

	/**
	 * @return the claimAmount
	 */
	public double getClaimAmount() {
		return claimAmount;
	}

	/**
	 * @param claimAmount the claimAmount to set
	 */
	public void setClaimAmount(double claimAmount) {
		this.claimAmount = claimAmount;
	}

	/**
	 * @return the approvedAmount
	 */
	public double getApprovedAmount() {
		return approvedAmount;
	}

	/**
	 * @param approvedAmount the approvedAmount to set
	 */
	public void setApprovedAmount(double approvedAmount) {
		this.approvedAmount = approvedAmount;
	}

	/**
	 * @return the eligibilityAmount
	 */
	public double getEligibilityAmount() {
		return eligibilityAmount;
	}

	/**
	 * @param eligibilityAmount the eligibilityAmount to set
	 */
	public void setEligibilityAmount(double eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	/**
	 * @return the applicationType
	 */
	public String getApplicationType() {
		return applicationType;
	}

	/**
	 * @param applicationType the applicationType to set
	 */
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	/**
	 * @return the applicationDate
	 */
	public Date getApplicationDate() {
		return applicationDate;
	}

	/**
	 * @param applicationDate the applicationDate to set
	 */
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WorkflowPrsnlAnnualTrvlAlwnceEntity [unitCode=" + unitCode + ", documentCode=" + documentCode
				+ ", documentSerialNo=" + documentSerialNo + ", employeeId=" + employeeId + ", claimCode=" + claimCode
				+ ", claimYear=" + claimYear + ", claimDate=" + claimDate + ", claimAmount=" + claimAmount
				+ ", approvedAmount=" + approvedAmount + ", eligibilityAmount=" + eligibilityAmount
				+ ", applicationType=" + applicationType + ", applicationDate=" + applicationDate + "]";
	}
	
	
}
