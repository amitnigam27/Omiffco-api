package com.omifco.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.omifco.compositeids.MedBillReimbId;

@Entity
@Table(name = "MED_BILL_REIMB_HDRS")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@IdClass(MedBillReimbId.class)
public class MedBillReimbHeaderEntity {

	@Id
	@Column(name="UNIT_CODE")
    private int unitCode;
	
	@Id
	@Column(name="BILL_SNO")
    private int billSerialNo;
	
	@Column(name="CLAIM_DATE")
    private Date claimDate;
	
	@Column(name="PERSONAL_NO")
    private String employeeId;
	
	@Column(name="BILL_TYPE")
    private String billType;
	
	@Column(name="SANCTION_NO")
    private String sanctionNo;
	
	@Column(name="DIR_PAY_TO_HOSP")
    private boolean dirPayToHosp;
	
	@Column(name="HOSPITAL_CODE")
    private String hospitalCode;
	
	@Column(name="CLAIMED_AMOUNT")
    private double claimedAmount;
	
	@Column(name="ADMISSIBLE_AMOUNT")
    private double admissibleAmount;
	
	@Column(name="CURRENCY_CODE")
    private String currencyCode;
	
	@Column(name="CURRENCY_RATE")
    private double currencyRate;
	
	@Column(name="APPROVED_AMOUNT")
    private double approvedAmount;
	
	@Column(name="ADVANCE_ADJUSTED")
    private double advanceAdjusted;
	
	@Column(name="RECOMEND_BY")
    private String recommendBy;
	
	@Column(name="RECOMEND_DATE")
    private Date recommendDate;
	
	@Column(name="APPROVED_BY")
    private String approvedBy;
	
	@Column(name="APPROVED_DATE")
    private Date approvedDate;
	
	@Column(name="SEND_TO_FINANCE")
    private boolean sendToFinance;
	
	@Column(name="SENT_TO_FIN_DATE")
    private Date sentToFinDate;
	
	@Column(name="FIN_RECEIVE_DATE")
    private Date finReceiveDate;
	
	@Column(name="PAY_RELEASE_DATE")
    private Date payReleaseDate;
	
	@Column(name="CREATED_BY",updatable = false)
    private String createdBy;
	
	@Column(name="DATETIME_CREATED",updatable = false)
    private Date createdDate;

	/**
	 * @return the unitCode
	 */
	public int getUnitCode() {
		return unitCode;
	}

	/**
	 * @param unitCode the unitCode to set
	 */
	public void setUnitCode(int unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * @return the billSerialNo
	 */
	public int getBillSerialNo() {
		return billSerialNo;
	}

	/**
	 * @param billSerialNo the billSerialNo to set
	 */
	public void setBillSerialNo(int billSerialNo) {
		this.billSerialNo = billSerialNo;
	}

	/**
	 * @return the claimDate
	 */
	public Date getClaimDate() {
		return claimDate;
	}

	/**
	 * @param claimDate the claimDate to set
	 */
	public void setClaimDate(Date claimDate) {
		this.claimDate = claimDate;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the billType
	 */
	public String getBillType() {
		return billType;
	}

	/**
	 * @param billType the billType to set
	 */
	public void setBillType(String billType) {
		this.billType = billType;
	}

	/**
	 * @return the sanctionNo
	 */
	public String getSanctionNo() {
		return sanctionNo;
	}

	/**
	 * @param sanctionNo the sanctionNo to set
	 */
	public void setSanctionNo(String sanctionNo) {
		this.sanctionNo = sanctionNo;
	}

	/**
	 * @return the dirPayToHosp
	 */
	public boolean isDirPayToHosp() {
		return dirPayToHosp;
	}

	/**
	 * @param dirPayToHosp the dirPayToHosp to set
	 */
	public void setDirPayToHosp(boolean dirPayToHosp) {
		this.dirPayToHosp = dirPayToHosp;
	}

	/**
	 * @return the hospitalCode
	 */
	public String getHospitalCode() {
		return hospitalCode;
	}

	/**
	 * @param hospitalCode the hospitalCode to set
	 */
	public void setHospitalCode(String hospitalCode) {
		this.hospitalCode = hospitalCode;
	}

	/**
	 * @return the claimedAmount
	 */
	public double getClaimedAmount() {
		return claimedAmount;
	}

	/**
	 * @param claimedAmount the claimedAmount to set
	 */
	public void setClaimedAmount(double claimedAmount) {
		this.claimedAmount = claimedAmount;
	}

	/**
	 * @return the admissibleAmount
	 */
	public double getAdmissibleAmount() {
		return admissibleAmount;
	}

	/**
	 * @param admissibleAmount the admissibleAmount to set
	 */
	public void setAdmissibleAmount(double admissibleAmount) {
		this.admissibleAmount = admissibleAmount;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the currencyRate
	 */
	public double getCurrencyRate() {
		return currencyRate;
	}

	/**
	 * @param currencyRate the currencyRate to set
	 */
	public void setCurrencyRate(double currencyRate) {
		this.currencyRate = currencyRate;
	}

	/**
	 * @return the approvedAmount
	 */
	public double getApprovedAmount() {
		return approvedAmount;
	}

	/**
	 * @param approvedAmount the approvedAmount to set
	 */
	public void setApprovedAmount(double approvedAmount) {
		this.approvedAmount = approvedAmount;
	}

	/**
	 * @return the advanceAdjusted
	 */
	public double getAdvanceAdjusted() {
		return advanceAdjusted;
	}

	/**
	 * @param advanceAdjusted the advanceAdjusted to set
	 */
	public void setAdvanceAdjusted(double advanceAdjusted) {
		this.advanceAdjusted = advanceAdjusted;
	}

	/**
	 * @return the recommendBy
	 */
	public String getRecommendBy() {
		return recommendBy;
	}

	/**
	 * @param recommendBy the recommendBy to set
	 */
	public void setRecommendBy(String recommendBy) {
		this.recommendBy = recommendBy;
	}

	/**
	 * @return the recommendDate
	 */
	public Date getRecommendDate() {
		return recommendDate;
	}

	/**
	 * @param recommendDate the recommendDate to set
	 */
	public void setRecommendDate(Date recommendDate) {
		this.recommendDate = recommendDate;
	}

	/**
	 * @return the approvedBy
	 */
	public String getApprovedBy() {
		return approvedBy;
	}

	/**
	 * @param approvedBy the approvedBy to set
	 */
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	/**
	 * @return the approvedDate
	 */
	public Date getApprovedDate() {
		return approvedDate;
	}

	/**
	 * @param approvedDate the approvedDate to set
	 */
	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	/**
	 * @return the sendToFinance
	 */
	public boolean isSendToFinance() {
		return sendToFinance;
	}

	/**
	 * @param sendToFinance the sendToFinance to set
	 */
	public void setSendToFinance(boolean sendToFinance) {
		this.sendToFinance = sendToFinance;
	}

	/**
	 * @return the sentToFinDate
	 */
	public Date getSentToFinDate() {
		return sentToFinDate;
	}

	/**
	 * @param sentToFinDate the sentToFinDate to set
	 */
	public void setSentToFinDate(Date sentToFinDate) {
		this.sentToFinDate = sentToFinDate;
	}

	/**
	 * @return the finReceiveDate
	 */
	public Date getFinReceiveDate() {
		return finReceiveDate;
	}

	/**
	 * @param finReceiveDate the finReceiveDate to set
	 */
	public void setFinReceiveDate(Date finReceiveDate) {
		this.finReceiveDate = finReceiveDate;
	}

	/**
	 * @return the payReleaseDate
	 */
	public Date getPayReleaseDate() {
		return payReleaseDate;
	}

	/**
	 * @param payReleaseDate the payReleaseDate to set
	 */
	public void setPayReleaseDate(Date payReleaseDate) {
		this.payReleaseDate = payReleaseDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MedBillReimbHeaderEntity [unitCode=" + unitCode + ", billSerialNo=" + billSerialNo + ", claimDate="
				+ claimDate + ", employeeId=" + employeeId + ", billType=" + billType + ", sanctionNo=" + sanctionNo
				+ ", dirPayToHosp=" + dirPayToHosp + ", hospitalCode=" + hospitalCode + ", claimedAmount="
				+ claimedAmount + ", admissibleAmount=" + admissibleAmount + ", currencyCode=" + currencyCode
				+ ", currencyRate=" + currencyRate + ", approvedAmount=" + approvedAmount + ", advanceAdjusted="
				+ advanceAdjusted + ", recommendBy=" + recommendBy + ", recommendDate=" + recommendDate
				+ ", approvedBy=" + approvedBy + ", approvedDate=" + approvedDate + ", sendToFinance=" + sendToFinance
				+ ", sentToFinDate=" + sentToFinDate + ", finReceiveDate=" + finReceiveDate + ", payReleaseDate="
				+ payReleaseDate + ", createdBy=" + createdBy + ", createdDate=" + createdDate + "]";
	}
	
	 
}
