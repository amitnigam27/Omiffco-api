package com.omifco.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.omifco.ApplicationConfiguration;
import com.omifco.dto.ChangePasswordDTO;
import com.omifco.dto.DeviceTokenDTO;
import com.omifco.dto.LeaveDTO;
import com.omifco.dto.LeaveSummaryDTO;
import com.omifco.dto.StatusDTO;
import com.omifco.entity.ApplicationEntity;
import com.omifco.entity.LookupMasterEntity;
import com.omifco.entity.UserEntity;
import com.omifco.service.LeaveApplicationService;
import com.omifco.service.LookupService;
import com.omifco.service.UserService;

/**
 * 
 * Test Class to test User Service.
 */
public class UserServiceTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		ctx.register(ApplicationConfiguration.class);
		ctx.refresh();
		
		//testAuthentication(ctx);	
		//testLookupService(ctx);
		//testLeaveSummary(ctx);
		//testLeaveAppData(ctx);
		//testApplyLeave(ctx);
		//testRecommendLeave(ctx);
		//testApproveLeave(ctx);
		//testAcceptLeave(ctx);
		//testRejectLeave(ctx);
		//testCancelLeave(ctx);
		//testGetLeaveDetails(ctx);
		//testGetAllApprovers(ctx);
		//testupdateUserProfile(ctx);
		//testChangePassword(ctx);
		//testGetEmployeeDetails(ctx);
		//testUpdateDeviceToken(ctx);
		
		/*UserServiceTest userServiceTest = new UserServiceTest();
		String fromDate="2020-03-17";  
		String toDate="2020-03-21";  
		try {
			Date fromD=new SimpleDateFormat("yyyy-mm-dd").parse(fromDate);
			Date toD=new SimpleDateFormat("yyyy-mm-dd").parse(toDate);
			System.out.println(userServiceTest.calculateNoOfDays(fromD,toD));
		} catch (ParseException e) {
			e.printStackTrace();
		}*/
		
		
		
	}
	
	private static void testGetEmployeeDetails(AnnotationConfigApplicationContext ctx) {
		UserService userService = ctx.getBean(UserService.class); 
		UserEntity entity = userService.getUserProfile("1111");
		doJsonize(entity);
		
	}

	private static void testChangePassword(AnnotationConfigApplicationContext ctx) {
		UserService userService = ctx.getBean(UserService.class); 
		ChangePasswordDTO changePass = new ChangePasswordDTO();
		changePass.setEmployeeId("1111");
		//changePass.setOldPassword("1111");
		changePass.setNewPassword("2222");
		StatusDTO status = userService.processForgotPassword(changePass.getEmployeeId(), changePass.getNewPassword());
		doJsonize(status);
		
	}
	
	private static void testUpdateDeviceToken(AnnotationConfigApplicationContext ctx) {
		UserService userService = ctx.getBean(UserService.class); 
		DeviceTokenDTO deviceToken = new DeviceTokenDTO();
		deviceToken.setUserId("1111");
		deviceToken.setDeviceType("Android");
		deviceToken.setDevicetoken("jhksdksdchlksjkjjgvhsxknhbcsd=");
		StatusDTO status = userService.updateDeviceToken(deviceToken);
		doJsonize(status);
		
	}

	private int calculateNoOfDays(Date fromDate, Date toDate) {
		LocalDate fromLocal = fromDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate toLocal = toDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int days = (int)ChronoUnit.DAYS.between(fromLocal, toLocal);
		days = days +1;
		return days;
	}

	private static void testupdateUserProfile(AnnotationConfigApplicationContext ctx) {
		UserService userService = ctx.getBean(UserService.class); 
		UserEntity entity = new UserEntity();
		entity.setEmployeeID("1111");
		entity.setMartialStatus("MARRIED");
		entity.setContact("1234567890");
		StatusDTO status = userService.updateUserProfile(entity);
		doJsonize(status);
	}
	
	private static void testLookupService(AnnotationConfigApplicationContext ctx) {
		LookupService lookupService = ctx.getBean(LookupService.class); 
		List<LookupMasterEntity> entity = lookupService.getLookupsByType("ApplicationType");
		doJsonize(entity);
	}

	private static void testLeaveSummary(AnnotationConfigApplicationContext ctx) {
		LeaveApplicationService leaveApplicationService = ctx.getBean(LeaveApplicationService.class); 
		LeaveSummaryDTO leaveSummaryDTO = leaveApplicationService.getLeavesSummary("1011");
		doJsonize(leaveSummaryDTO);	
	}
	
	private static void testLeaveAppData(AnnotationConfigApplicationContext ctx) {
		LeaveApplicationService leaveApplicationService = ctx.getBean(LeaveApplicationService.class); 
		List<ApplicationEntity> appList = leaveApplicationService.getAppDetails("Leave Application", "101");
		doJsonize(appList);	
	}
	
	private static void testApplyLeave(AnnotationConfigApplicationContext ctx) {
		LeaveApplicationService leaveApplicationService = ctx.getBean(LeaveApplicationService.class); 
		LeaveDTO leaveDTO = new LeaveDTO();
		leaveDTO.setEmployeeId("1011");
		leaveDTO.setFromDate(new Date());
		leaveDTO.setToDate(getNextDate(new Date()));
		leaveDTO.setLeaveFlag(1);
		leaveDTO.setLeavePurpose("11");
		leaveDTO.setLeaveType("AL");
		leaveDTO.setOperation("Apply");
		leaveDTO.setSendTo("4302");	
		leaveDTO.setRequestorId("1011");
		StatusDTO statusDTO = leaveApplicationService.processLeave(leaveDTO);
		doJsonize(statusDTO);	
	}
	
	private static void testRecommendLeave(AnnotationConfigApplicationContext ctx) {
		LeaveApplicationService leaveApplicationService = ctx.getBean(LeaveApplicationService.class); 
		LeaveDTO leaveDTO = new LeaveDTO();
		leaveDTO.setEmployeeId("1011");
		leaveDTO.setOperation("Recommend");
		leaveDTO.setSendTo("3042");
		leaveDTO.setDocNumber("101");
		leaveDTO.setRequestorId("4302");
		leaveDTO.setRemarks("Recommended - Enjoy");
		StatusDTO statusDTO = leaveApplicationService.processLeave(leaveDTO);
		doJsonize(statusDTO);	
	}
	
	private static void testApproveLeave(AnnotationConfigApplicationContext ctx) {
		LeaveApplicationService leaveApplicationService = ctx.getBean(LeaveApplicationService.class); 
		LeaveDTO leaveDTO = new LeaveDTO();
		leaveDTO.setEmployeeId("1011");
		leaveDTO.setOperation("Approve");
		leaveDTO.setSendTo("2054");
		leaveDTO.setDocNumber("101");
		leaveDTO.setRequestorId("3042");
		leaveDTO.setRemarks("Approved - Say congrats from our side too.");
		StatusDTO statusDTO = leaveApplicationService.processLeave(leaveDTO);
		doJsonize(statusDTO);	
	}
	
	private static void testAcceptLeave(AnnotationConfigApplicationContext ctx) {
		LeaveApplicationService leaveApplicationService = ctx.getBean(LeaveApplicationService.class); 
		LeaveDTO leaveDTO = new LeaveDTO();
		leaveDTO.setEmployeeId("1011");
		leaveDTO.setOperation("Accept");
		leaveDTO.setSendTo("");
		leaveDTO.setDocNumber("101");
		leaveDTO.setRequestorId("2054");
		leaveDTO.setRemarks("Accepted");
		StatusDTO statusDTO = leaveApplicationService.processLeave(leaveDTO);
		doJsonize(statusDTO);	
	}
	
	private static void testCancelLeave(AnnotationConfigApplicationContext ctx) {
		LeaveApplicationService leaveApplicationService = ctx.getBean(LeaveApplicationService.class); 
		LeaveDTO leaveDTO = new LeaveDTO();
		leaveDTO.setEmployeeId("1011");
		leaveDTO.setOperation("Cancel");
		leaveDTO.setLeaveType("AL");
		String fromDate="2020-03-17";  
		String toDate="2020-03-21";  
		try {
			Date fromD=new SimpleDateFormat("yyyy-mm-dd").parse(fromDate);
			Date toD=new SimpleDateFormat("yyyy-mm-dd").parse(toDate);
			leaveDTO.setFromDate(fromD);
			leaveDTO.setToDate(toD);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		leaveDTO.setSendTo("");
		leaveDTO.setLeaveFlag(1);
		leaveDTO.setLeaveStatus("P");
		leaveDTO.setDocNumber("104");
		leaveDTO.setRequestorId("1011");
		leaveDTO.setRemarks("Withdrawn");
		StatusDTO statusDTO = leaveApplicationService.processLeave(leaveDTO);
		doJsonize(statusDTO);	
	}
	
	private static void testRejectLeave(AnnotationConfigApplicationContext ctx) {
		LeaveApplicationService leaveApplicationService = ctx.getBean(LeaveApplicationService.class); 
		LeaveDTO leaveDTO = new LeaveDTO();
		leaveDTO.setEmployeeId("1011");
		leaveDTO.setOperation("Reject");
		leaveDTO.setLeaveType("AL");
		leaveDTO.setLeaveFlag(1);
		String fromDate="2020-03-19";  
		String toDate="2020-03-22";  
		try {
			Date fromD=new SimpleDateFormat("yyyy-mm-dd").parse(fromDate);
			Date toD=new SimpleDateFormat("yyyy-mm-dd").parse(toDate);
			leaveDTO.setFromDate(fromD);
			leaveDTO.setToDate(toD);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		leaveDTO.setSendTo("");
		leaveDTO.setDocNumber("101");
		leaveDTO.setRequestorId("2054");
		leaveDTO.setRemarks("Rejected");
		StatusDTO statusDTO = leaveApplicationService.processLeave(leaveDTO);
		doJsonize(statusDTO);	
	}
	
	private static void testGetLeaveDetails(AnnotationConfigApplicationContext ctx) {
		LeaveApplicationService leaveApplicationService = ctx.getBean(LeaveApplicationService.class); 
		LeaveDTO leaveDTO = leaveApplicationService.getLeaveDetails("101");
		doJsonize(leaveDTO);	
	}
	
	private static Date getNextDate(Date curDate) {
		Date nextDate = null;
		try {
            Calendar today = Calendar.getInstance();
            today.setTime(curDate);
            today.add(Calendar.DAY_OF_YEAR, 1);
            nextDate = today.getTime();
        } catch (Exception e) {
            return nextDate;
        }
		return nextDate;
	}


	private static void doJsonize(Object object){
		if(object == null) return;
		try{
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
			System.out.println(json);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
