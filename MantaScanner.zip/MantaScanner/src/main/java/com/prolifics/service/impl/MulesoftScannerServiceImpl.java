package com.prolifics.service.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.prolifics.service.MantaScannerCoreService;
import com.prolifics.util.BasicUtil;
import com.prolifics.util.HttpUtil;

/**
 * ReferenceServiceImpl : Implementation class of FuntimeService.
 * 
 * @author Prolifics
 *
 */
public class MulesoftScannerServiceImpl extends MantaScannerCoreService {

	private String currentTimestamp = new SimpleDateFormat(TIMESTAMP_FORMAT).format(new Date());
	private String filelocation = EMPTY;
	private List<String> downloadLinks = new ArrayList<String>();
	/**
	 * init method is intended to perform the necessary
	 * initialization activities of the process flow.   
	 */
	@Override
	protected void init() {
		System.out.println("Entering init....");
		filelocation = businessDataMap.get(CSV_LOCATION)+"/"+businessDataMap.get(SELECTED_SYSTEM)+currentTimestamp;
		Path path = Paths.get(filelocation);
		//if directory exists?
        if (!Files.exists(path)) {
            try {
                Files.createDirectories(path);
            } catch (IOException e) {
                //fail to create directory
                e.printStackTrace();
            }
        }
	}

	/**
	 * readMetaData reads the base meta data from a configuration
	 * file which will be utilized to create the necessary CSV file.
	 */
	@Override
	protected void readMetaData() {
		System.out.println("Entering readMetaData....");
		try {
			InputStream inputStream = getClass()
					.getClassLoader().getResourceAsStream("application.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			for (final String name: properties.stringPropertyNames())
				businessDataMap.put(name, properties.getProperty(name));
			
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}
		System.out.println(businessDataMap);
	}

	/**
	 * createCSV creates the CSV file using the meta data
	 * and the desired business logic.
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void createCSV() {
		System.out.println("Entering createCSV....");
		/*try {
			HttpUtil.sendGetRequest(businessDataMap.get(SERVICE_URL));
			String yamlString = HttpUtil.readMultipleLinesRespone();
            boolean isValidYaml = BasicUtil.hasValidStructure(yamlString,YAML);
            System.out.println("isValidYAML -> "+isValidYaml);
            if(isValidYaml) {
            	ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
				Map<String,Object> map = new HashMap<>();	
				JsonNode params = mapper.readTree(yamlString);
				map = mapper.convertValue(params, Map.class);
				businessDataMap.put(DOWNLOADS_LOCATION, filelocation);
				
				ArrayList<Map<String,Object>> layerArray = (ArrayList<Map<String,Object>>) map.get(LAYER);
				String completeFilePath = filelocation+SLASH+LAYER_CSV;
				char delimeter = businessDataMap.get("csv.delimeter").charAt(0);
				BasicUtil.generateJsonToCSV(layerArray,completeFilePath,delimeter);
				downloadLinks.add(completeFilePath);
				
				ArrayList<Map<String,Object>> resourceArray = (ArrayList<Map<String,Object>>) map.get(RESOURCE);
				completeFilePath = filelocation+SLASH+RESOURCE_CSV;
				BasicUtil.generateJsonToCSV(resourceArray,completeFilePath,delimeter);
				downloadLinks.add(completeFilePath);
				
				ArrayList<Map<String,Object>> nodeArray = (ArrayList<Map<String,Object>>) map.get(NODE);
				completeFilePath = filelocation+SLASH+NODE_CSV;
				BasicUtil.generateJsonToCSV(nodeArray,completeFilePath,delimeter);
				downloadLinks.add(completeFilePath);
				
				ArrayList<Map<String,Object>> nodeAttributeArray = (ArrayList<Map<String,Object>>) map.get(NODE_ATTRIBUTE);
				completeFilePath = filelocation+SLASH+NODE_ATTRIBUTE_CSV;
				BasicUtil.generateJsonToCSV(nodeAttributeArray,completeFilePath,delimeter);
				downloadLinks.add(completeFilePath);
				
				ArrayList<Map<String,Object>> edgeArray = (ArrayList<Map<String,Object>>) map.get(EDGE);
				completeFilePath = filelocation+SLASH+EDGE_CSV;
				BasicUtil.generateJsonToCSV(edgeArray,completeFilePath,delimeter);
				downloadLinks.add(completeFilePath);
				
				ArrayList<Map<String,Object>> edgeAttributeArray = (ArrayList<Map<String,Object>>) map.get(EDGE_ATTRIBUTE);
				completeFilePath = filelocation+SLASH+EDGE_ATTRIBUTE_CSV;
				BasicUtil.generateJsonToCSV(edgeAttributeArray,completeFilePath,delimeter);
				downloadLinks.add(completeFilePath);
				
            }
			 
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}*/
                	
	}
	
	/**
	 * augmentCSV is a hook to perform custom
	 * modifications to the raw CSV file created.
	 */
	@Override
	protected void augmentCSV() {
		System.out.println("Entering augmentCSV....");	
		try {
			String zipFileName = filelocation+SLASH+businessDataMap.get(SELECTED_SYSTEM)+ZIP_EXTENSION;
            FileOutputStream fos = new FileOutputStream(zipFileName);
            ZipOutputStream zos = new ZipOutputStream(fos);
 
            for (String file : downloadLinks) {
                zos.putNextEntry(new ZipEntry(new File(file).getName()));
 
                byte[] bytes = Files.readAllBytes(Paths.get(file));
                zos.write(bytes, 0, bytes.length);
                zos.closeEntry();
            }
            zos.close();
        } catch (FileNotFoundException ex) {
            System.err.println("A file does not exist: " + ex);
        } catch (IOException ex) {
            System.err.println("I/O error: " + ex);
        }
	}

	/**
	 * transferCSV transfers the CSV file to a location
	 * that is specified in the Configuration File.
	 */
	@Override
	protected void transferCSV() {
		System.out.println("Entering transferCSV....");
		System.out.println("Files created at "+filelocation);

	}
	/**
	 * cleanUp needs to clean any heavy objects that might
	 * have been created by this application so that they can
	 * be garbage collected.
	 */
	@Override
	protected void cleanUp() {
		System.out.println("Entering cleanUp....");
		//businessDataMap.clear();
		System.out.println("Cleanup finished.");
	}

}
