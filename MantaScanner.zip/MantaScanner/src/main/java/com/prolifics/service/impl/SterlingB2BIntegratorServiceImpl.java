package com.prolifics.service.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.prolifics.service.MantaScannerCoreService;
import com.prolifics.util.SterlingUtil;

/**
 * ReferenceServiceImpl : Implementation class of FuntimeService.
 * 
 * @author Prolifics
 *
 */
public class SterlingB2BIntegratorServiceImpl extends MantaScannerCoreService {

	private String currentTimestamp = new SimpleDateFormat(TIMESTAMP_FORMAT).format(new Date());
	private String filelocation = EMPTY;
	private List<String> downloadLinks = new ArrayList<String>();
	
	/**
	 * init method is intended to perform the necessary
	 * initialization activities of the process flow.   
	 */
	@Override
	protected void init() {
		System.out.println("Entering init....");
		filelocation = businessDataMap.get(CSV_LOCATION)+SLASH+businessDataMap.get(SELECTED_SYSTEM)+currentTimestamp;
		Path path = Paths.get(filelocation);
		//if directory exists?
        if (!Files.exists(path)) {
            try {
                Files.createDirectories(path);
            } catch (IOException e) {
                //fail to create directory
                e.printStackTrace();
            }
        }
	}

	/**
	 * readMetaData reads the base meta data from a configuration
	 * file which will be utilized to create the necessary CSV file.
	 */
	@Override
	protected void readMetaData() {
		System.out.println("Entering readMetaData....");
		try {
			InputStream inputStream = getClass()
					.getClassLoader().getResourceAsStream("application.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			for (final String name: properties.stringPropertyNames())
				businessDataMap.put(name, properties.getProperty(name));
			
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}
		System.out.println(businessDataMap);
	}

	/**
	 * createCSV creates the CSV file using the meta data
	 * and the desired business logic.
	 */
	@Override
	protected void createCSV() {
		System.out.println("Entering createCSV....");
		try {
			List<String> validXmlList = new LinkedList<String>();
			List<String> xmlLocations = new LinkedList<String>();
			businessDataMap.put(DOWNLOADS_LOCATION, filelocation);
			
			String xmlLocation_1 = businessDataMap.get(BUSINESS_PROCESS_XML_1);
			SterlingUtil.prepareXmlList(validXmlList, xmlLocations, xmlLocation_1);
			
			String xmlLocation_2 = businessDataMap.get(BUSINESS_PROCESS_XML_2);
			SterlingUtil.prepareXmlList(validXmlList, xmlLocations, xmlLocation_2);
			
			String xmlLocation_3 = businessDataMap.get(BUSINESS_PROCESS_XML_3);
			SterlingUtil.prepareXmlList(validXmlList, xmlLocations, xmlLocation_3);
			
			String xmlLocation_4 = businessDataMap.get(BUSINESS_PROCESS_XML_4);
			SterlingUtil.prepareXmlList(validXmlList, xmlLocations, xmlLocation_4);
			              
			parseBusinessProcessXML(validXmlList, xmlLocations);
		   
		}catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}	
                	
	}

	
	
	protected void parseBusinessProcessXML(List<String> validXmlList, List<String> xmlLocations){
		Map<String, String[]> layersMap = new LinkedHashMap<String, String[]>();
		Map<String, String[]> resourcesMap = new LinkedHashMap<String, String[]>();
		Map<String, String[]> nodeMap = new LinkedHashMap<String, String[]>();
		Map<String, String[]> nodeAttributeMap = new LinkedHashMap<String, String[]>();
		Map<String, String[]> edgeMap = new LinkedHashMap<String, String[]>();
		Map<String, String[]> edgeAttributeMap = new LinkedHashMap<String, String[]>();
		
		try {
	        /***********Layer*************/
			//Key: layerName, Value: layer data
	      
			String layerTypes = businessDataMap.get("layertypes").trim();
			SterlingUtil.prepareLayersData(layerTypes, layersMap, validXmlList);
			String completeFilePath = filelocation+SLASH+LAYER_CSV;
			SterlingUtil.writeDataToCsv(layersMap,completeFilePath);
			downloadLinks.add(completeFilePath);
			
			/***********Resource*************/
			//Key: resourceName, Value: resource data
			SterlingUtil.prepareResourceData(validXmlList, resourcesMap, layersMap, xmlLocations);
			completeFilePath = filelocation+SLASH+RESOURCE_CSV;
			SterlingUtil.writeDataToCsv(resourcesMap,completeFilePath);
			downloadLinks.add(completeFilePath);
			
			/***********Node*************/
			SterlingUtil.prepareNodeData(validXmlList, nodeMap, resourcesMap);
			completeFilePath = filelocation+SLASH+NODE_CSV;
			SterlingUtil.writeDataToCsv(nodeMap,completeFilePath);
			downloadLinks.add(completeFilePath);
			
			/***********Node_Attribute*************/
			SterlingUtil.prepareNodeAttributeData(validXmlList, nodeAttributeMap, nodeMap);
			completeFilePath = filelocation+SLASH+NODE_ATTRIBUTE_CSV;
			SterlingUtil.writeDataToCsv(nodeAttributeMap,completeFilePath);
			downloadLinks.add(completeFilePath);
			
			/***********Edge*************/
			//SterlingUtil.prepareEdgeData(validXmlList, nodeAttributeMap, nodeMap);
			completeFilePath = filelocation+SLASH+EDGE_CSV;
			SterlingUtil.writeDataToCsv(edgeMap,completeFilePath);
			downloadLinks.add(completeFilePath);
			
			/***********Edge_Attribute*************/
			//SterlingUtil.prepareEdgeAttributeData(validXmlList, nodeAttributeMap, nodeMap);
			completeFilePath = filelocation+SLASH+EDGE_ATTRIBUTE_CSV;
			SterlingUtil.writeDataToCsv(edgeAttributeMap,completeFilePath);
			downloadLinks.add(completeFilePath);
		}	
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	
	
	/**
	 * augmentCSV is a hook to perform custom
	 * modifications to the raw CSV file created.
	 */
	@Override
	protected void augmentCSV() {
		System.out.println("Entering augmentCSV....");	
		try {
			String zipFileName = filelocation+SLASH+businessDataMap.get(SELECTED_SYSTEM)+ZIP_EXTENSION;
            FileOutputStream fos = new FileOutputStream(zipFileName);
            ZipOutputStream zos = new ZipOutputStream(fos);
 
            for (String file : downloadLinks) {
                zos.putNextEntry(new ZipEntry(new File(file).getName()));
 
                byte[] bytes = Files.readAllBytes(Paths.get(file));
                zos.write(bytes, 0, bytes.length);
                zos.closeEntry();
            }
 
            zos.close();
        } catch (FileNotFoundException ex) {
            System.err.println("A file does not exist: " + ex);
        } catch (IOException ex) {
            System.err.println("I/O error: " + ex);
        }
	}

	/**
	 * transferCSV transfers the CSV file to a location
	 * that is specified in the Configuration File.
	 */
	@Override
	protected void transferCSV() {
		System.out.println("Entering transferCSV....");
		System.out.println("Files created at: "+filelocation);
	}
	/**
	 * cleanUp needs to clean any heavy objects that might
	 * have been created by this application so that they can
	 * be garbage collected.
	 */
	@Override
	protected void cleanUp() {
		System.out.println("Entering cleanUp....");
		//businessDataMap.clear();
		System.out.println("Cleanup finished.");
	}

}
