package com.prolifics.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.prolifics.service.MantaScannerCoreService;
import com.prolifics.util.BasicUtil;
import com.prolifics.util.FtpUtil;
import com.prolifics.util.HttpUtil;

/**
 * ReferenceServiceImpl : Implementation class of FuntimeService.
 * 
 * @author Prolifics
 *
 */
public class OneTrustScannerServiceImpl extends MantaScannerCoreService {

	private String currentTimestamp = new SimpleDateFormat(TIMESTAMP_FORMAT).format(new Date());
	private String filelocation = EMPTY;
	private List<String> downloadLinks = new ArrayList<String>();
	/**
	 * init method is intended to perform the necessary
	 * initialization activities of the process flow.   
	 */
	@Override
	protected void init() {
		System.out.println("Entering init....");
		filelocation = businessDataMap.get(CSV_LOCATION)+SLASH+businessDataMap.get(SELECTED_SYSTEM)+currentTimestamp;
		Path path = Paths.get(filelocation);
		//if directory exists?
		if (!Files.exists(path)) {
			try {
				Files.createDirectories(path);
			} catch (IOException e) {
				//fail to create directory
				e.printStackTrace();
			}
		}
	}

	/**
	 * readMetaData reads the base meta data from a configuration
	 * file which will be utilized to create the necessary CSV file.
	 */
	@Override
	protected void readMetaData() {
		System.out.println("Entering readMetaData....");
		try {
			InputStream inputStream = getClass()
					.getClassLoader().getResourceAsStream("application.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			for (final String name: properties.stringPropertyNames())
				businessDataMap.put(name, properties.getProperty(name));

		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}
		System.out.println(businessDataMap);
	}

	/**
	 * createCSV creates the CSV file using the meta data
	 * and the desired business logic.
	 */
	@Override
	protected void createCSV() {
		System.out.println("Entering createCSV....");
		try {
			
			String assetExcelLocation = businessDataMap.get(ASSET_URL);
			String processingActivitiesLocation = businessDataMap.get(PROCESSING_ACTIVITIES_URL);
			businessDataMap.put(DOWNLOADS_LOCATION, filelocation);
			Workbook assetsWorkbook = null;
			Sheet assetAttributeSheet = null, personalDataSheet =null;
			if(assetExcelLocation!=null && !assetExcelLocation.isEmpty()) {
				InputStream assetsInputStream = getExcelAsInputStream(assetExcelLocation);
				assetsWorkbook = new XSSFWorkbook(assetsInputStream);
				String assetFileName = assetExcelLocation.substring((assetExcelLocation.lastIndexOf("/")+1), assetExcelLocation.length());
				System.out.println("assetFileName: "+assetFileName);
				//Get sheet by name
				assetAttributeSheet = assetsWorkbook.getSheet("Asset Attributes");
				personalDataSheet = assetsWorkbook.getSheet("Asset - Personal Data");
			}
			
			Workbook processingActivitiesWorkbook = null;
			Sheet paAttributeSheet = null, paPersonalDataSheet =null, paToAssetSheet=null;
			if(processingActivitiesLocation!=null && !processingActivitiesLocation.isEmpty()) {
				InputStream paInputStream = getExcelAsInputStream(processingActivitiesLocation);
				processingActivitiesWorkbook = new XSSFWorkbook(paInputStream);
				String paFileName = processingActivitiesLocation.substring((processingActivitiesLocation.lastIndexOf("/")+1), processingActivitiesLocation.length());
				System.out.println("paFileName: "+paFileName);
				//Get sheet by name
				paAttributeSheet = processingActivitiesWorkbook.getSheet("Processing Activity Attributes");
				paPersonalDataSheet = processingActivitiesWorkbook.getSheet("PA - Personal Data");
				paToAssetSheet = processingActivitiesWorkbook.getSheet("PA to Asset");
			}
			

			/***********Layer*************/
			//Key: layerName, Value: layer data
			Map<String, String[]> layersMap = new LinkedHashMap<String, String[]>();
			String layerTypes = businessDataMap.get("layertypes").trim();
			BasicUtil.prepareLayersData(layerTypes, layersMap);
			String completeFilePath = filelocation+SLASH+LAYER_CSV;
			BasicUtil.writeDataToCsv(layersMap,completeFilePath);
			downloadLinks.add(completeFilePath);

			/***********Resource*************/
			//Key: resourceName, Value: resource data
			Map<String, String[]> resourcesMap = new LinkedHashMap<String, String[]>();
			List<Sheet> resourceSheets = new LinkedList<Sheet>();
			if(assetAttributeSheet!=null)
				resourceSheets.add(assetAttributeSheet);
			if(paAttributeSheet!=null)
				resourceSheets.add(paAttributeSheet);
			BasicUtil.prepareResourceData(resourceSheets, resourcesMap, layersMap);
			completeFilePath = filelocation+SLASH+RESOURCE_CSV;
			BasicUtil.writeDataToCsv(resourcesMap,completeFilePath);
			downloadLinks.add(completeFilePath);
			
			/***********Node*************/
			//Key: resourceName, Value: resource data
			Map<String, String[]> nodeMap = new LinkedHashMap<String, String[]>();
			List<Sheet> nodeSheets = new LinkedList<Sheet>();
			if(assetAttributeSheet!=null)
				nodeSheets.add(assetAttributeSheet);
			if(personalDataSheet!=null)
				nodeSheets.add(personalDataSheet);
			if(paAttributeSheet!=null)
				nodeSheets.add(paAttributeSheet);
			if(paPersonalDataSheet!=null)
				nodeSheets.add(paPersonalDataSheet);
			BasicUtil.prepareNodeData(nodeSheets, nodeMap);
			completeFilePath = filelocation+SLASH+NODE_CSV;
			BasicUtil.writeDataToCsv(nodeMap,completeFilePath);
			downloadLinks.add(completeFilePath);
			
			/***********Node_Attribute*************/
			//Key: resourceName, Value: resource data
			Map<String, String[]> nodeAttributeMap = new LinkedHashMap<String, String[]>();
			List<Sheet> nodeAttributeSheets = new LinkedList<Sheet>();
			if(assetAttributeSheet!=null)
				nodeAttributeSheets.add(assetAttributeSheet);
			if(personalDataSheet!=null)
				nodeAttributeSheets.add(personalDataSheet);
			if(paAttributeSheet!=null)
				nodeAttributeSheets.add(paAttributeSheet);
			if(paPersonalDataSheet!=null)
				nodeAttributeSheets.add(paPersonalDataSheet);
			BasicUtil.prepareNodeAttributeData(nodeAttributeSheets, nodeAttributeMap);
			completeFilePath = filelocation+SLASH+NODE_ATTRIBUTE_CSV;
			BasicUtil.writeDataToCsv(nodeAttributeMap,completeFilePath);
			downloadLinks.add(completeFilePath);
			
			/***********Edge*************/
			Map<String, String[]> edgeMap = new LinkedHashMap<String, String[]>();
			if(paToAssetSheet!=null)
				BasicUtil.prepareEdgeData(paToAssetSheet, edgeMap);
			completeFilePath = filelocation+SLASH+EDGE_CSV;
			BasicUtil.writeDataToCsv(edgeMap,completeFilePath);
			downloadLinks.add(completeFilePath);
			
			/***********Edge_Attribute*************/
			Map<String, String[]> edgeAttributeMap = new LinkedHashMap<String, String[]>();
			if(paToAssetSheet!=null)
				BasicUtil.prepareEdgeAttributeData(paToAssetSheet, edgeAttributeMap);
			completeFilePath = filelocation+SLASH+EDGE_ATTRIBUTE_CSV;
			BasicUtil.writeDataToCsv(edgeAttributeMap,completeFilePath);
			downloadLinks.add(completeFilePath);

			if(assetsWorkbook!=null)
				assetsWorkbook.close();
			if(processingActivitiesWorkbook!=null)
				processingActivitiesWorkbook.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private InputStream getExcelAsInputStream(String excelLocation) {
		InputStream in = null;
		try {
			if(excelLocation.startsWith("http")) {
				HttpUtil.sendGetRequest(excelLocation);
				in = HttpUtil.readMultipleLinesRespone();
			}else if(excelLocation.startsWith("ftp")) {
				URL url=new URL(excelLocation);  
				String serverAddress = url.getHost();
				System.out.println(serverAddress);
			    String userId = businessDataMap.get("ftp.prolifics.userId").trim();
			    String password = businessDataMap.get("ftp.prolifics.password").trim();
			    String remoteDirectory = url.getPath();
			    System.out.println(userId +"  <--->  "+password);
			    in = FtpUtil.readFileFromFTP(serverAddress, userId, password, remoteDirectory);
			}else {
				in = new FileInputStream(new File(excelLocation));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return in;
	}

	/**
	 * augmentCSV is a hook to perform custom
	 * modifications to the raw CSV file created.
	 */
	@Override
	protected void augmentCSV() {
		System.out.println("Entering augmentCSV....");
		try {
			String zipFileName = filelocation+SLASH+businessDataMap.get(SELECTED_SYSTEM)+ZIP_EXTENSION;
			FileOutputStream fos = new FileOutputStream(zipFileName);
			ZipOutputStream zos = new ZipOutputStream(fos);

			for (String file : downloadLinks) {
				zos.putNextEntry(new ZipEntry(new File(file).getName()));

				byte[] bytes = Files.readAllBytes(Paths.get(file));
				zos.write(bytes, 0, bytes.length);
				zos.closeEntry();
			}

			zos.close();
		} catch (FileNotFoundException ex) {
			System.err.println("A file does not exist: " + ex);
		} catch (IOException ex) {
			System.err.println("I/O error: " + ex);
		}
	}

	/**
	 * transferCSV transfers the CSV file to a location
	 * that is specified in the Configuration File.
	 */
	@Override
	protected void transferCSV() {
		System.out.println("Entering transferCSV....");
		System.out.println("Files created at: "+filelocation);
	}
	/**
	 * cleanUp needs to clean any heavy objects that might
	 * have been created by this application so that they can
	 * be garbage collected.
	 */
	@Override
	protected void cleanUp() {
		System.out.println("Entering cleanUp....");
		//businessDataMap.clear();
		System.out.println("Cleanup finished.");
	}

}
