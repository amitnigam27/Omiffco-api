package com.prolifics.service;

import java.util.HashMap;
import java.util.Map;

import com.prolifics.constants.MantaConstants;

/**
 * FuntimeService is the core service contract which
 * do have business methods of managing CSV file
 * life cycle.
 * 
 * @author Prolifics
 *
 */
public abstract class MantaScannerCoreService extends MantaConstants {
	/**
	 * businessDataMap to store the contextual data
	 * of the Program flow.
	 */
	protected Map<String, String> businessDataMap = new HashMap<>();
	/**
	 * init method is intended to perform the necessary
	 * initialization activities of the process flow.   
	 */
	protected abstract void init();
	/**
	 * readMetaData reads the base meta data from a configuration
	 * file which will be utilized to create the necessary CSV file.
	 */
	protected abstract void readMetaData();
	/**
	 * createCSV creates the CSV file using the meta data
	 * and the desired business logic.
	 */
	protected abstract void createCSV();
	/**
	 * augmentCSV is a hook to perform custom
	 * modifications to the raw CSV file created.
	 */
	protected abstract void augmentCSV();
	/**
	 * transferCSV transfers the CSV file to a location
	 * that is specified in the Configuration File.
	 */
	protected abstract void transferCSV();
	/**
	 * cleanUp needs to clean any heavy objects that might
	 * have been created by this application so that they can
	 * be garbage collected.
	 */
	protected abstract void cleanUp();
	/**
	 * process is the primary method which will be accessible to external caller
	 * and this will wrap all business methods in template pattern.
	 */
	public void process(){
		init();
		try{
			readMetaData();
			createCSV();
			augmentCSV();
			transferCSV();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			cleanUp();
		}
	}
	
	public void addContextualData(String key, String value) {
		this.businessDataMap.put(key, value);
	}
	
	/**
	 * @param businessDataMap the businessDataMap to set
	 */
	public void setBusinessDataMap(Map<String, String> businessDataMap) {
		this.businessDataMap = businessDataMap;
	}
	
	

}
