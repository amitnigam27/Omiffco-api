package com.prolifics.app;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.prolifics.constants.MantaConstants;
import com.prolifics.exception.MantaBusinessException;
import com.prolifics.model.DynamicFields;
import com.prolifics.model.JSONResponse;
import com.prolifics.service.MantaScannerCoreService;
import com.prolifics.service.impl.MulesoftScannerServiceImpl;
import com.prolifics.service.impl.OneTrustScannerServiceImpl;
import com.prolifics.service.impl.SterlingB2BIntegratorServiceImpl;

@CrossOrigin(origins = "*")
@RestController
public class MantaScannerController extends MantaConstants {

	@RequestMapping(value="/health-check", method=RequestMethod.GET)
	public @ResponseBody String ping(){
		return "API is up and running at end point /api";
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getCreateView() {
		Map<String, String> businessDataMap = new HashMap<String,String>();
		try {
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream("application.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			for (final String name: properties.stringPropertyNames())
				businessDataMap.put(name, properties.getProperty(name));

		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}

		DynamicFields fields = new DynamicFields();
		String dhs = businessDataMap.get("data.handling.system");
		fields.setDhsList(getListFromCommaSepratedString(dhs));

		Map<String,String> serviceUrlMap = new HashMap<String,String>();
		serviceUrlMap.put(STERLING,businessDataMap.get("sterling.webservice.url"));
		serviceUrlMap.put(ONETRUST,businessDataMap.get("onetrust.webservice.url"));
		serviceUrlMap.put(MULESOFT,businessDataMap.get("mulesoft.webservice.url"));
		fields.setServiceUrlMap(serviceUrlMap);

		Map<String,List<String>> additionalFieldsMap = new HashMap<String,List<String>>();
		additionalFieldsMap.put(STERLING,getListFromCommaSepratedString(businessDataMap.get("sterling.additional.fields")));
		additionalFieldsMap.put(ONETRUST,getListFromCommaSepratedString(businessDataMap.get("onetrust.additional.fields")));
		additionalFieldsMap.put(MULESOFT,getListFromCommaSepratedString(businessDataMap.get("mulesoft.additional.fields")));
		fields.setAdditionalFieldsMap(additionalFieldsMap);

		ModelAndView model = new ModelAndView(SCANNER_VIEW);
		model.addObject(VIEW_DATA, fields);
		return model;
	}

	/**
	 * @param dhs
	 * @param dhsList
	 */
	private List<String> getListFromCommaSepratedString(String commaSepratedString) {
		List<String> additionalList = new ArrayList<String>();
		if(commaSepratedString!=null && commaSepratedString.contains(COMMA)) {
			for (String item : commaSepratedString.split(COMMA)) {
				additionalList.add(item.toLowerCase());
			}
		}else if(commaSepratedString!=null && !commaSepratedString.isEmpty()) {
			additionalList.add(commaSepratedString);
		}
		return additionalList;
	}

	@RequestMapping(value="/process", method=RequestMethod.POST)
	public @ResponseBody Object process(HttpServletRequest request, HttpServletResponse response, @RequestBody String requestBody) throws UnsupportedEncodingException{
		System.out.println(requestBody);		
		Map<String, String> businessDataMap = formatDataInKeyValuePairs(requestBody);
		businessDataMap.forEach((key,value) -> System.out.println("Key: "+key+" Value: "+value));
		
		JSONResponse res = new JSONResponse();
		if(businessDataMap.get(CSV_LOCATION).isEmpty()){
			res.setErrorMessage("Please provide CSV Location");
		} 

		switch (businessDataMap.get(SELECTED_SYSTEM)) {
		case ONETRUST:
			if(businessDataMap.get(ASSET_URL).isEmpty() && businessDataMap.get(PROCESSING_ACTIVITIES_URL).isEmpty()) {
				res.setErrorMessage("Please provide either Asset URL or Processing Activities URL");
				break;
			}
			if(businessDataMap.get("layertypes").isEmpty()){
				res.setErrorMessage("Please provide Layer Type");
				break;
			} 
			if(res.getErrorMessage() == null) {
				MantaScannerCoreService oneTrustService = new OneTrustScannerServiceImpl();
				oneTrustService.setBusinessDataMap(businessDataMap);
				oneTrustService.process();
			}
			break;
		case STERLING:
			if(businessDataMap.get(BUSINESS_PROCESS_XML_1).isEmpty() && businessDataMap.get(BUSINESS_PROCESS_XML_2).isEmpty() && businessDataMap.get(BUSINESS_PROCESS_XML_3).isEmpty() && businessDataMap.get(BUSINESS_PROCESS_XML_4).isEmpty()) {
				res.setErrorMessage("Please provide at least one Business Process XML URL");
				break;
			}
			if(businessDataMap.get("layertypes").isEmpty()){
				res.setErrorMessage("Please provide Layer Type");
				break;
			} 
			if(res.getErrorMessage() == null) {
				MantaScannerCoreService sterlingService = new SterlingB2BIntegratorServiceImpl();
				sterlingService.setBusinessDataMap(businessDataMap);
				sterlingService.process();
			}
			break;
		case MULESOFT:
			MantaScannerCoreService mulesoftService = new MulesoftScannerServiceImpl();
			mulesoftService.setBusinessDataMap(businessDataMap);
			mulesoftService.process();
			break;
		default:
			System.out.println("Unsupported Data Handling system...");
			break;
		}

		

		Map<String,String> downloadsMap = new LinkedHashMap<String,String>();
		downloadsMap.put(LAYER,LAYER_CSV);
		downloadsMap.put(RESOURCE,RESOURCE_CSV);
		downloadsMap.put(NODE,NODE_CSV);
		downloadsMap.put(NODE_ATTRIBUTE,NODE_ATTRIBUTE_CSV);
		downloadsMap.put(EDGE,EDGE_CSV);
		downloadsMap.put(EDGE_ATTRIBUTE,EDGE_ATTRIBUTE_CSV);
		res.setDownloadZipLink(businessDataMap.get(SELECTED_SYSTEM)+ZIP_EXTENSION);
		res.setDownloadsMap(downloadsMap);
		res.setSelectedDHSSystem(businessDataMap.get(SELECTED_SYSTEM));

		HttpSession session = request.getSession();
		session.setAttribute(DOWNLOADS_LOCATION, businessDataMap.get(DOWNLOADS_LOCATION));

		if(res.getErrorMessage() == null) {
	        return new ResponseEntity<Object>(res, HttpStatus.OK);
	    } else {
	        return new ResponseEntity<MantaBusinessException>(new MantaBusinessException("ERR_001",res.getErrorMessage()),HttpStatus.BAD_REQUEST);
	    }
	}
	
	public static Map<String, String> formatDataInKeyValuePairs(String serializedData) throws UnsupportedEncodingException {
	    Map<String, String> data_pairs = new LinkedHashMap<String, String>();
	    String[] pairs = serializedData.split("&");
	    for (String pair : pairs) {
	        int idx = pair.indexOf("=");
	        data_pairs.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"), URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
	    }
	    return data_pairs;
	}

}
