package com.prolifics.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

@SpringBootApplication
public class MantaScannerApplication extends SpringBootServletInitializer {

	/**
	 * 
	 * Constant to hold the resource bundle file.
	 */
	private static final String PROPERTY_NAME_MESSAGE_SOURCE_BASENAME = "i18n/messages";
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(MantaScannerApplication.class);
	}
	
	public static void main(String[] args) {
		SpringApplication.run(MantaScannerApplication.class, args);
	}
	
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**").addResourceLocations("/static/");
    }
	
	/**
	 * ResourceBundleMessageSource bean configuration.
	 * 
	 */
	@Bean
	public ResourceBundleMessageSource messageSource() {
		ResourceBundleMessageSource source = new ResourceBundleMessageSource();
		source.setBasename(PROPERTY_NAME_MESSAGE_SOURCE_BASENAME);
		source.setUseCodeAsDefaultMessage(true);
		return source;
	}
}
