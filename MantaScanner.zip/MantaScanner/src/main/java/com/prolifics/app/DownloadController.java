package com.prolifics.app;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/download")
public class DownloadController {
	
	@RequestMapping("/{fileName:.+}")
    public void downloadPDFResource( HttpServletRequest request, HttpServletResponse response, @PathVariable("fileName") String fileName) 
    {
		HttpSession session = request.getSession();
		String dataDirectory = (String) session.getAttribute("downloadsLocation");
        Path file = Paths.get(dataDirectory, fileName);
        if (Files.exists(file)) 
        {
            response.setContentType("application/octet-stream");
            response.addHeader("Content-Disposition", "attachment; filename="+fileName);
            try
            {
                Files.copy(file, response.getOutputStream());
                response.getOutputStream().flush();
            } 
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
	
	@RequestMapping(value = "/clean-up", method=RequestMethod.GET)
	public @ResponseBody String cleanDownloadsDirectory(HttpServletRequest request, HttpServletResponse response){
		String dataDirectory = "/home/ec2-user/manta";
		try {
			File file = new File(dataDirectory);
			FileUtils.cleanDirectory(file); 
		}catch (Exception e) {
			e.printStackTrace();
		}
		return "Successfully cleaned all CSV files.";
	}

}
