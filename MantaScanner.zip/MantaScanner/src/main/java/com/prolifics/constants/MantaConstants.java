package com.prolifics.constants;

public class MantaConstants {
	
	//CSV file names
	public static final String LAYER_CSV = "layer.csv";
	public static final String RESOURCE_CSV = "resource.csv";
	public static final String NODE_CSV = "node.csv";
	public static final String NODE_ATTRIBUTE_CSV = "node_attribute.csv";
	public static final String EDGE_CSV = "edge.csv";
	public static final String EDGE_ATTRIBUTE_CSV = "edge_attribute.csv";
	
	//CSV specific keys
	public static final String LAYER = "layer";
	public static final String RESOURCE = "resource";
	public static final String NODE = "node";
	public static final String NODE_ATTRIBUTE = "nodeAttribute";
	public static final String EDGE = "edge";
	public static final String EDGE_ATTRIBUTE = "edgeAttribute";
	
	//Data Handling System
	public static final String STERLING = "sterling";
	public static final String ONETRUST = "onetrust";
	public static final String MULESOFT = "mulesoft";
	
	//Data Formats
	public static final String JSON = "json";
	public static final String XML = "xml";
	public static final String YAML = "yml";
	
	//View names
	public static final String SCANNER_VIEW = "scanner";
	
	//Misc
	public static final String VIEW_DATA = "viewData";
	public static final String COMMA = ",";
	public static final String SELECTED_SYSTEM = "dataHandlingSystem";
	public static final String SERVICE_URL = "serviceUrl";
	public static final String ASSET_URL = "asseturl";
	public static final String PROCESSING_ACTIVITIES_URL = "processingactivitiesurl";
	public static final String BUSINESS_PROCESS_XML_1 = "businessprocessxml_1";
	public static final String BUSINESS_PROCESS_XML_2 = "businessprocessxml_2";
	public static final String BUSINESS_PROCESS_XML_3 = "businessprocessxml_3";
	public static final String BUSINESS_PROCESS_XML_4 = "businessprocessxml_4";
	public static final String CSV_LOCATION = "csvLocation";
	public static final String ZIP_EXTENSION = ".zip";
	public static final String TIMESTAMP_FORMAT = "yyyyMMddHHmmss";
	public static final String EMPTY = "";
	public static final String SLASH = "/";
	public static final String DOWNLOADS_LOCATION = "downloadsLocation";

}
