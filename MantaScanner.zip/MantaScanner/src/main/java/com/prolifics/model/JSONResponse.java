package com.prolifics.model;

import java.util.Map;

public class JSONResponse {
	
	private String selectedDHSSystem;
	
	private Map<String,String> downloadsMap;
	
	private String downloadZipLink;
	
	private String errorMessage;

	/**
	 * @return the selectedDHSSystem
	 */
	public String getSelectedDHSSystem() {
		return selectedDHSSystem;
	}

	/**
	 * @param selectedDHSSystem the selectedDHSSystem to set
	 */
	public void setSelectedDHSSystem(String selectedDHSSystem) {
		this.selectedDHSSystem = selectedDHSSystem;
	}

	/**
	 * @return the downloadsMap
	 */
	public Map<String, String> getDownloadsMap() {
		return downloadsMap;
	}

	/**
	 * @param downloadsMap the downloadsMap to set
	 */
	public void setDownloadsMap(Map<String, String> downloadsMap) {
		this.downloadsMap = downloadsMap;
	}

	/**
	 * @return the downloadZipLink
	 */
	public String getDownloadZipLink() {
		return downloadZipLink;
	}

	/**
	 * @param downloadZipLink the downloadZipLink to set
	 */
	public void setDownloadZipLink(String downloadZipLink) {
		this.downloadZipLink = downloadZipLink;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "JSONResponse [selectedDHSSystem=" + selectedDHSSystem + ", downloadsMap=" + downloadsMap
				+ ", downloadZipLink=" + downloadZipLink + ", errorMessage=" + errorMessage + "]";
	}

}
