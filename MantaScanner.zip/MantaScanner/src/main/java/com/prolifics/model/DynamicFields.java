package com.prolifics.model;

import java.util.List;
import java.util.Map;

public class DynamicFields {
	
	private List<String> dhsList;
	
	//key: DHS, value: serviceURL
	private Map<String,String> serviceUrlMap;
	
	//key: DHS, value: fieldName
	private Map<String,List<String>> additionalFieldsMap;

	/**
	 * @return the dhsList
	 */
	public List<String> getDhsList() {
		return dhsList;
	}

	/**
	 * @param dhsList the dhsList to set
	 */
	public void setDhsList(List<String> dhsList) {
		this.dhsList = dhsList;
	}

	/**
	 * @return the serviceUrlMap
	 */
	public Map<String, String> getServiceUrlMap() {
		return serviceUrlMap;
	}

	/**
	 * @param serviceUrlMap the serviceUrlMap to set
	 */
	public void setServiceUrlMap(Map<String, String> serviceUrlMap) {
		this.serviceUrlMap = serviceUrlMap;
	}

	/**
	 * @return the additionalFieldsMap
	 */
	public Map<String, List<String>> getAdditionalFieldsMap() {
		return additionalFieldsMap;
	}

	/**
	 * @param additionalFieldsMap the additionalFieldsMap to set
	 */
	public void setAdditionalFieldsMap(Map<String, List<String>> additionalFieldsMap) {
		this.additionalFieldsMap = additionalFieldsMap;
	}

	@Override
	public String toString() {
		return "DynamicFields [dhsList=" + dhsList + ", serviceUrlMap=" + serviceUrlMap + ", additionalFieldsMap="
				+ additionalFieldsMap + "]";
	}

}
