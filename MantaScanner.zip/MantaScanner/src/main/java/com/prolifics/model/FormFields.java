package com.prolifics.model;

public class FormFields {
	
	private String dataHandlingSystem;
	
	private String serviceUrl;
	
	private String csvLocation;

	/**
	 * @return the dataHandlingSystem
	 */
	public String getDataHandlingSystem() {
		return dataHandlingSystem;
	}

	/**
	 * @param dataHandlingSystem the dataHandlingSystem to set
	 */
	public void setDataHandlingSystem(String dataHandlingSystem) {
		this.dataHandlingSystem = dataHandlingSystem;
	}

	/**
	 * @return the serviceUrl
	 */
	public String getServiceUrl() {
		return serviceUrl;
	}

	/**
	 * @param serviceUrl the serviceUrl to set
	 */
	public void setServiceUrl(String serviceUrl) {
		this.serviceUrl = serviceUrl;
	}

	/**
	 * @return the csvLocation
	 */
	public String getCsvLocation() {
		return csvLocation;
	}

	/**
	 * @param csvLocation the csvLocation to set
	 */
	public void setCsvLocation(String csvLocation) {
		this.csvLocation = csvLocation;
	}

	@Override
	public String toString() {
		return "FormFields [dataHandlingSystem=" + dataHandlingSystem + ", serviceUrl=" + serviceUrl + ", csvLocation="
				+ csvLocation + "]";
	}

}
