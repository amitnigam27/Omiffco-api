package com.prolifics.util;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.prolifics.constants.MantaConstants;

import au.com.bytecode.opencsv.CSVWriter;

public class BasicUtil extends MantaConstants {

	//Key: Organization , Value : Resource
	private static Map<String,String> orgAndResourceMap = new HashMap<String,String>();
	//Key: Organization , Value = Array of RowNumbers belongs to that particular Organization.
	private static Map<String,List<Integer>> mapOfIndiciesForRes = new LinkedHashMap<String,List<Integer>>();

	//Key: Organization , Value : Resource
	private static Map<String,String> processOrgAndResourceMap = new HashMap<String,String>();
	//Key: Organization , Value = Array of RowNumbers belongs to that particular Organization.
	private static Map<String,List<Integer>> processMapOfIndiciesForRes = new LinkedHashMap<String,List<Integer>>();

	/**
	 * Check if the string passed is a valid JSON/YAML/XML or not.
	 * 
	 * @param responseString
	 * @return
	 */
	public static boolean hasValidStructure(String responseString ,String structureType) {
		try {
			switch (structureType.toLowerCase()) {
			case JSON:
				final ObjectMapper jsonMapper = new ObjectMapper();
				jsonMapper.readTree(responseString);
				break;
			case XML:
				XmlMapper xmlMapper = new XmlMapper();
				xmlMapper.readTree(responseString);
				break;
			case YAML:
				final ObjectMapper yamlmapper = new ObjectMapper(new YAMLFactory());
				yamlmapper.readTree(responseString);
				break;
			default:
				System.out.println("Unsupported format...");
				break;
			}

			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @param layerArray
	 * @throws IOException
	 */
	public static void generateJsonToCSV(ArrayList<Map<String, Object>> arrayList,String filelocation,char delimeter) throws IOException {
		FileWriter writer = new FileWriter(filelocation);
		CSVWriter csvWriter = new CSVWriter(writer,delimeter, '"' );
		for (Map<String, Object> itemMap : arrayList) {
			ArrayList<String> stringArray = new ArrayList<String>();
			for (Object value : itemMap.values()) {
				stringArray.add(value.toString());
			}
			String data[]=stringArray.toArray(new String[stringArray.size()]);
			csvWriter.writeNext(data);
		}
		csvWriter.close();
	}

	/**
	 * @param node
	 * @throws IOException
	 */
	public static void writeXMLToCSV(Node node,String csvPath) throws IOException {
		FileWriter writer = new FileWriter(csvPath);
		CSVWriter csvWriter = new CSVWriter(writer);
		NodeList childNodeList = node.getChildNodes();
		for (int j = 0; j < childNodeList.getLength(); j++) {
			Node childNode = childNodeList.item(j);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				String text = childNode.getTextContent();
				String[] data = text.trim().split("\n");
				for (int k = 0; k < data.length; k++)
					data[k] = data[k].trim();
				csvWriter.writeNext(data);
			}
		}
		csvWriter.close();
	}

	/**
	 * @param layersMap
	 * @throws IOException
	 */
	public static void writeDataToCsv(Map<String, String[]> layersMap,String filelocation) throws IOException {
		FileWriter writer = new FileWriter(filelocation);
		CSVWriter csvWriter = new CSVWriter(writer);
		for (String[] data : layersMap.values()) {
			csvWriter.writeNext(data);
		}
		csvWriter.close();
	}

	/**
	 * @param rowIterator
	 * @param layerUniqueId
	 * @param formatter
	 * @param indexOfLayerNameCol
	 * @param indexOfLayerTypeCol
	 * @param layersMap
	 */
	public static void prepareResourceData(List<Sheet> sheets, Map<String, String[]> resourcesMap, Map<String, String[]> layersMap) {

		int uniqueId = 1;
		DecimalFormat formatter = new DecimalFormat("00");

		String inventoryType ="";
		String inventoryTypeAbb ="";
		String inventoryGroup ="";

		//TODO: It's hardcode as of now but in coming days might be changed in case of multiple layers
		String layer = layersMap.get("OTlayer01")[0];

		for (Sheet sheet : sheets) {
			if(sheet.getSheetName().trim().startsWith("A")) {
				inventoryType = "Assets";
				inventoryTypeAbb = "Assets";
				inventoryGroup ="Asset";	
			}else if(sheet.getSheetName().trim().startsWith("P")){
				inventoryType = "Processing Activities";
				inventoryTypeAbb = "Process";
				inventoryGroup ="Process";
				uniqueId = 11;
			}
			int indexOfOrganizationCol=-1, indexOfTypeCol=-1, indexOfBusinessProcessOwnerCol=-1;
			HashSet<String> organizationsSet=new HashSet<String>();
			Iterator<Row> rowIterator = sheet.rowIterator();
			while (rowIterator.hasNext()) {
				Row currentRow = rowIterator.next();
				//Header Row at Index 0
				if(currentRow.getRowNum() == 0) {
					Iterator<Cell> cellIterator = currentRow.iterator();
					//Iterating over columns to get index of particular column, using column name.
					while (cellIterator.hasNext()) {
						Cell currentCell = cellIterator.next();
						if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Managing Organization")) {
							indexOfOrganizationCol = currentCell.getColumnIndex();
						}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Type")) {
							indexOfTypeCol = currentCell.getColumnIndex();
						}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Business Process Owner")) {
							indexOfBusinessProcessOwnerCol = currentCell.getColumnIndex();
						}
					}
					System.out.println("Organization Index: "+indexOfOrganizationCol+" Type Index: "+indexOfTypeCol+" Business Process Owner Index: "+indexOfBusinessProcessOwnerCol);
				}else {

					Cell orgCell = indexOfOrganizationCol > -1 ?currentRow.getCell(indexOfOrganizationCol):null;
					Cell typeCell = indexOfTypeCol > -1 ? currentRow.getCell(indexOfTypeCol):null;
					Cell businessProcessOwnerCell = indexOfBusinessProcessOwnerCol > -1 ? currentRow.getCell(indexOfBusinessProcessOwnerCol):null;

					if((typeCell!=null && (typeCell.getStringCellValue().trim().equalsIgnoreCase("Database") ||
							typeCell.getStringCellValue().trim().equalsIgnoreCase("Application") ||
							typeCell.getStringCellValue().trim().equalsIgnoreCase("Website") ||
							typeCell.getStringCellValue().trim().equalsIgnoreCase("Physical Storage"))) || 
							(businessProcessOwnerCell!=null && !businessProcessOwnerCell.getStringCellValue().isEmpty())) {


						if(organizationsSet.size() == 0 || (orgCell!=null && !organizationsSet.contains(orgCell.getStringCellValue().trim()))) {
							String resourceData[]= new String[5];
							resourceData[0] = "OT"+"resrc"+formatter.format(uniqueId);
							resourceData[1] = "OT-"+orgCell.getStringCellValue().trim()+" "+inventoryTypeAbb;
							resourceData[2] = "OneTrust-"+inventoryGroup;
							resourceData[3] = orgCell.getStringCellValue().trim()+" "+inventoryType;
							resourceData[4] = layer;
							resourcesMap.put(resourceData[0], resourceData);
							if(businessProcessOwnerCell==null)
								orgAndResourceMap.put(orgCell.getStringCellValue().trim(),resourceData[0]);
							else
								processOrgAndResourceMap.put(orgCell.getStringCellValue().trim(),resourceData[0]);
							organizationsSet.add(orgCell.getStringCellValue().trim());
							uniqueId++;
						}

						if(businessProcessOwnerCell==null) {
							if(mapOfIndiciesForRes.size() > 0 && orgCell!=null && mapOfIndiciesForRes.keySet().contains(orgCell.getStringCellValue().trim())){
								List<Integer> listOfIndicies = mapOfIndiciesForRes.get(orgCell.getStringCellValue().trim());
								listOfIndicies.add(currentRow.getRowNum());
								mapOfIndiciesForRes.put(orgCell.getStringCellValue().trim(), listOfIndicies);
							}else if(orgCell!=null) {
								List<Integer> listOfIndicies = new ArrayList<Integer>();
								listOfIndicies.add(currentRow.getRowNum());
								mapOfIndiciesForRes.put(orgCell.getStringCellValue().trim(), listOfIndicies);
							}
						}else {
							if(processMapOfIndiciesForRes.size() > 0 && orgCell!=null && processMapOfIndiciesForRes.keySet().contains(orgCell.getStringCellValue().trim())){
								List<Integer> listOfIndicies = processMapOfIndiciesForRes.get(orgCell.getStringCellValue().trim());
								listOfIndicies.add(currentRow.getRowNum());
								processMapOfIndiciesForRes.put(orgCell.getStringCellValue().trim(), listOfIndicies);
							}else if(orgCell!=null) {
								List<Integer> listOfIndicies = new ArrayList<Integer>();
								listOfIndicies.add(currentRow.getRowNum());
								processMapOfIndiciesForRes.put(orgCell.getStringCellValue().trim(), listOfIndicies);
							}
						}

					}
				}
			}
		}		
	}

	public static void prepareLayersData(String layerTypes, Map<String, String[]> layersMap) {
		int layerUniqueId = 1;
		DecimalFormat formatter = new DecimalFormat("00");
		String[] layers = null;

		if(layerTypes.contains(COMMA)) {
			layers = layerTypes.split(COMMA);
		}else {
			layers = new String[1];
			layers[0] = layerTypes;
		}

		for (String layer : layers) {
			String layerData[]= new String[3];
			layerData[0] = "OT"+"layer"+formatter.format(layerUniqueId);
			layerData[1] = layer;
			layerData[2] = layer;
			layersMap.put(layerData[0], layerData);
			layerUniqueId++;
		}


	}

	public static void prepareNodeData(List<Sheet> sheets, Map<String, String[]> nodeMap) {

		int uniqueId = 1;
		DecimalFormat formatter = new DecimalFormat("00");

		String nodeParentId = EMPTY;
		String prevKey=EMPTY;
		//Key: AssetId, Value: Resource
		Map<String,String> assetIdAndResMap = new HashMap<String, String>();
		for (Sheet sheet : sheets) {
			int indexOfInventoryIdCol=-1, indexOfNameCol=-1, indexOfTypeCol=-1,indexOfBusinessProcessOwnerCol=-1;
			if(sheet.getSheetName().trim().equalsIgnoreCase("Asset Attributes") ||
					sheet.getSheetName().trim().equalsIgnoreCase("Processing Activity Attributes")) {
				Row headerRow = sheet.getRow(0);
				Iterator<Cell> cellIter = headerRow.iterator();
				while (cellIter.hasNext()) {
					Cell currentCell = cellIter.next();
					if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Inventory Id")) {
						indexOfInventoryIdCol = currentCell.getColumnIndex();
					}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Name")) {
						indexOfNameCol = currentCell.getColumnIndex();
					}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Type")) {
						indexOfTypeCol = currentCell.getColumnIndex();
					}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Business Process Owner")) {
						indexOfBusinessProcessOwnerCol = currentCell.getColumnIndex();
					}
				}

				if(sheet.getSheetName().trim().equalsIgnoreCase("Asset Attributes")) {
					for (String key : mapOfIndiciesForRes.keySet()) {
						for (int rownum : mapOfIndiciesForRes.get(key)) {
							Row currentRow = sheet.getRow(rownum);
							Cell inventoryIdCell = currentRow.getCell(indexOfInventoryIdCol);
							Cell nameCell = currentRow.getCell(indexOfNameCol);
							Cell typeCell = currentRow.getCell(indexOfTypeCol);
							
							if(typeCell!=null && (typeCell.getStringCellValue().trim().equalsIgnoreCase("Database") ||
									typeCell.getStringCellValue().trim().equalsIgnoreCase("Application") ||
									typeCell.getStringCellValue().trim().equalsIgnoreCase("Website") ||
									typeCell.getStringCellValue().trim().equalsIgnoreCase("Physical Storage") )) {

								if(prevKey.isEmpty() || !prevKey.equals(key)) {
									String nodeData[]= new String[5];
									nodeData[0] = "OT"+"inventory"+formatter.format(uniqueId);
									nodeData[1] = "";
									nodeData[2] = "OneTrust "+key+" Asset Inventory";
									nodeData[3] = "Directory";
									nodeData[4] = orgAndResourceMap.get(key);
									prevKey = key;
									nodeParentId = nodeData[0];
									uniqueId++;
									nodeMap.put(nodeData[0], nodeData);
								}

								String nodeData[]= new String[5];
								if(inventoryIdCell.getStringCellValue()!=null && nameCell.getStringCellValue() !=null && typeCell.getStringCellValue()!=null) {
									nodeData[0] = inventoryIdCell.getStringCellValue().trim();
									nodeData[1] = nodeParentId;
									nodeData[2] = nameCell.getStringCellValue().trim();
									nodeData[3] = typeCell.getStringCellValue().trim();
									nodeData[4] = orgAndResourceMap.get(key);
									assetIdAndResMap.put(nodeData[0],nodeData[4]);
									nodeMap.put(nodeData[0], nodeData);
								}
							}
						}
					}
				}else {
					for (String key : processMapOfIndiciesForRes.keySet()) {
						for (int rownum : processMapOfIndiciesForRes.get(key)) {
							Row currentRow = sheet.getRow(rownum);
							Cell inventoryIdCell = currentRow.getCell(indexOfInventoryIdCol);
							Cell nameCell = currentRow.getCell(indexOfNameCol);
							Cell businessProcessOwnerCell = currentRow.getCell(indexOfBusinessProcessOwnerCol);
							
							if(businessProcessOwnerCell!=null && !businessProcessOwnerCell.getStringCellValue().isEmpty()) {

								if(prevKey.isEmpty() || !prevKey.equals(key)) {
									String nodeData[]= new String[5];
									nodeData[0] = "OT"+"inventory"+formatter.format(uniqueId);
									nodeData[1] = "";
									nodeData[2] = "OneTrust "+key+" Process Inventory";
									nodeData[3] = "Directory";
									nodeData[4] = processOrgAndResourceMap.get(key);
									prevKey = key;
									nodeParentId = nodeData[0];
									uniqueId++;
									nodeMap.put(nodeData[0], nodeData);
								}

								String nodeData[]= new String[5];
								if(inventoryIdCell.getStringCellValue()!=null && nameCell.getStringCellValue() !=null) {
									nodeData[0] = inventoryIdCell.getStringCellValue().trim();
									nodeData[1] = nodeParentId;
									nodeData[2] = nameCell.getStringCellValue().trim();
									nodeData[3] = "Process";
									nodeData[4] = processOrgAndResourceMap.get(key);
									assetIdAndResMap.put(nodeData[0],nodeData[4]);
									nodeMap.put(nodeData[0], nodeData);
								}
							}
						}
					}
				}
				
			}else if(sheet.getSheetName().trim().equalsIgnoreCase("Asset - Personal Data")||
					sheet.getSheetName().trim().equalsIgnoreCase("PA - Personal Data")) {
				//PersonalData-Sheet
				int indexOfAssetIdCol=-1, indexOfDataElemCol=-1, indexOfProcessActivityIDCol=-1;
				int uniqueSuffix = 1;
				DecimalFormat threeDigitformatter = new DecimalFormat("000");
				Iterator<Row> rowIterator = sheet.rowIterator();
				System.out.println("Last Row Num: "+sheet.getLastRowNum());
				while (rowIterator.hasNext()) {
					Row currentRow = rowIterator.next();
					//Header Row at Index 0
					if(currentRow.getRowNum() == 0) {
						Iterator<Cell> cellIterator = currentRow.iterator();
						//Iterating over columns to get index of particular column, using column name.
						while (cellIterator.hasNext()) {
							Cell currentCell = cellIterator.next();
							if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Asset ID")) {
								indexOfAssetIdCol = currentCell.getColumnIndex();
							}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Data Element Name")) {
								indexOfDataElemCol = currentCell.getColumnIndex();
							}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Processing Activity ID")) {
								indexOfProcessActivityIDCol = currentCell.getColumnIndex();
							}
						}
						System.out.println("Asset Id Index: "+indexOfAssetIdCol +" Data Element Index: "+ indexOfDataElemCol+" Processing Activity Id: "+indexOfProcessActivityIDCol);
					}else {

						Cell assetIdCell = indexOfAssetIdCol > -1 ? currentRow.getCell(indexOfAssetIdCol):null;
						Cell dataElemCell = indexOfDataElemCol > -1 ? currentRow.getCell(indexOfDataElemCol):null;
						Cell processingActivityIdCell = indexOfProcessActivityIDCol > -1 ? currentRow.getCell(indexOfProcessActivityIDCol):null;

						String nodeData[]= new String[5];
						if(assetIdCell!=null && dataElemCell!=null) {
							nodeData[0] = assetIdCell.getStringCellValue().trim()+"-"+threeDigitformatter.format(uniqueSuffix);
							nodeData[1] = assetIdCell.getStringCellValue().trim();
							nodeData[2] = dataElemCell.getStringCellValue().trim();
							nodeData[3] = "Column";
							nodeData[4] = assetIdAndResMap.get(nodeData[1]);
							nodeMap.put(nodeData[0], nodeData);
							uniqueSuffix++;
						}else if(processingActivityIdCell!=null && dataElemCell!=null) {
							nodeData[0] = processingActivityIdCell.getStringCellValue().trim()+"-"+threeDigitformatter.format(uniqueSuffix);
							nodeData[1] = processingActivityIdCell.getStringCellValue().trim();
							nodeData[2] = dataElemCell.getStringCellValue().trim();
							nodeData[3] = "Column";
							nodeData[4] = assetIdAndResMap.get(nodeData[1]);
							nodeMap.put(nodeData[0], nodeData);
							uniqueSuffix++;
						}
					}	
				}
			}
		}
	}

	public static void prepareNodeAttributeData(List<Sheet> sheets, Map<String, String[]> nodeAttributeMap) {

		
		String descriptionColHeader ="";
		for (Sheet sheet : sheets) {
			if(sheet.getSheetName().trim().equalsIgnoreCase("Asset Attributes") ||
					sheet.getSheetName().trim().equalsIgnoreCase("Processing Activity Attributes")) {
				int indexOfInventoryIdCol=-1, indexOfDescriptionCol=-1, indexOfTypeCol=-1, indexOfPurposeCol=-1, indexOfTransferFromCol=-1, indexOfTransferToCol=-1;
				Iterator<Row> rowIterator = sheet.rowIterator();
				while (rowIterator.hasNext()) {
					Row currentRow = rowIterator.next();
					//Header Row at Index 0
					if(currentRow.getRowNum() == 0) {
						Iterator<Cell> cellIterator = currentRow.iterator();
						//Iterating over columns to get index of particular column, using column name.
						while (cellIterator.hasNext()) {
							Cell currentCell = cellIterator.next();
							if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Inventory Id")) {
								indexOfInventoryIdCol = currentCell.getColumnIndex();
							}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Description")) {
								indexOfDescriptionCol = currentCell.getColumnIndex();
								descriptionColHeader = currentCell.getStringCellValue().trim();
							}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Type")) {
								indexOfTypeCol = currentCell.getColumnIndex();
							}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Purpose of Processing")) {
								indexOfPurposeCol = currentCell.getColumnIndex();
							}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Transfer Method (From Sources)")) {
								indexOfTransferFromCol = currentCell.getColumnIndex();
							}else if(currentCell!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Transfer Method (To Destinations)")) {
								indexOfTransferToCol = currentCell.getColumnIndex();
							}
						}
						System.out.println("Inventory Id: "+indexOfInventoryIdCol+" Description Index: "+indexOfDescriptionCol);
					}else {

						Cell inventoryIdCell = indexOfInventoryIdCol > -1 ? currentRow.getCell(indexOfInventoryIdCol):null;
						Cell descriptionCell = indexOfDescriptionCol > -1 ? currentRow.getCell(indexOfDescriptionCol):null;
						Cell typeCell = indexOfTypeCol > -1 ? currentRow.getCell(indexOfTypeCol):null;
						Cell purposeCell = indexOfPurposeCol > -1 ? currentRow.getCell(indexOfPurposeCol):null;
						Cell transferFromCell = indexOfTransferFromCol > -1 ? currentRow.getCell(indexOfTransferFromCol):null;
						Cell transferToCell = indexOfTransferToCol > -1 ? currentRow.getCell(indexOfTransferToCol):null;
						
						
						if(typeCell!=null && (typeCell.getStringCellValue().trim().equalsIgnoreCase("Database") ||
								typeCell.getStringCellValue().trim().equalsIgnoreCase("Application") ||
								typeCell.getStringCellValue().trim().equalsIgnoreCase("Website") ||
								typeCell.getStringCellValue().trim().equalsIgnoreCase("Physical Storage")) ) {

							String nodeAttrData[]= new String[3];
							if(inventoryIdCell!=null && descriptionCell!=null) {
								nodeAttrData[0] = inventoryIdCell.getStringCellValue().trim();
								nodeAttrData[1] = descriptionColHeader;
								nodeAttrData[2] = descriptionCell.getStringCellValue().trim();
								nodeAttributeMap.put(nodeAttrData[0], nodeAttrData);
							}
						}else if(inventoryIdCell!=null && descriptionCell!=null && purposeCell!=null && transferFromCell!=null && transferToCell!=null) {
							Map<String,Cell> cellMap = new LinkedHashMap<String,Cell>();
							cellMap.put("Description",descriptionCell);
							cellMap.put("Purpose",purposeCell);
							cellMap.put("Transfer Method from Source",transferFromCell);
							cellMap.put("Transfer Method to Target",transferToCell);
							int index = 1;
							for(String key: cellMap.keySet()) {
								String nodeAttrData[]= new String[3];
								if(key.equals("Description")) {
									nodeAttrData[0] = inventoryIdCell.getStringCellValue().trim();
									nodeAttrData[1] = key;
									nodeAttrData[2] = cellMap.get(key).getStringCellValue().trim();
									nodeAttributeMap.put(nodeAttrData[0]+index, nodeAttrData);
									index++;
								}else if(inventoryIdCell!=null && cellMap.get(key)!=null && !cellMap.get(key).getStringCellValue().trim().isEmpty()) {
									nodeAttrData[0] = inventoryIdCell.getStringCellValue().trim();
									nodeAttrData[1] = key;
									nodeAttrData[2] = cellMap.get(key).getStringCellValue().trim();
									nodeAttributeMap.put(nodeAttrData[0]+index, nodeAttrData);
									index++;
								}
							}
						}
					}  
				}
			}else if(sheet.getSheetName().trim().equalsIgnoreCase("Asset - Personal Data")||
					sheet.getSheetName().trim().equalsIgnoreCase("PA - Personal Data")) {
				//PersonalData-Sheet
				int indexOfCategoryCol=-1, indexOfClassificationCol=-1, indexOfSubjectCol=-1, indexOfAssetIdCol=-1, indexOfProcessingActivityIDCol=-1;
				int uniqueSuffix = 1;
				DecimalFormat threeDigitformatter = new DecimalFormat("000");
				Iterator<Row> rowIter = sheet.rowIterator();
				while (rowIter.hasNext()) {
					Row currentRow = rowIter.next();
					//Header Row at Index 0
					if(currentRow.getRowNum() == 0) {
						Iterator<Cell> cellIterator = currentRow.iterator();
						//Iterating over columns to get index of particular column, using column name.
						while (cellIterator.hasNext()) {
							Cell currentCell = cellIterator.next();
							if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Data Category Name")) {
								indexOfCategoryCol = currentCell.getColumnIndex();
							}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Data Classification Name")) {
								indexOfClassificationCol = currentCell.getColumnIndex();
							}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Data Subject Type Name")) {
								indexOfSubjectCol = currentCell.getColumnIndex();
							}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Asset ID")) {
								indexOfAssetIdCol = currentCell.getColumnIndex();
							}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Processing Activity ID")) {
								indexOfProcessingActivityIDCol = currentCell.getColumnIndex();
							}
						}
						System.out.println(indexOfCategoryCol +" "+ indexOfClassificationCol+" "+indexOfSubjectCol);
					}else {

						Cell subjectIdCell = indexOfSubjectCol > -1 ? currentRow.getCell(indexOfSubjectCol):null;
						Cell categoryCell = indexOfCategoryCol > -1 ? currentRow.getCell(indexOfCategoryCol):null;
						Cell classificationCell = indexOfClassificationCol > -1 ? currentRow.getCell(indexOfClassificationCol):null;
						Cell assetIdCell = indexOfAssetIdCol > -1 ? currentRow.getCell(indexOfAssetIdCol):null;
						Cell processingActivityIdCell = indexOfProcessingActivityIDCol > -1 ? currentRow.getCell(indexOfProcessingActivityIDCol):null;
						
						Map<String,Cell> cellMap = new LinkedHashMap<String,Cell>();
						cellMap.put("Data Subject",subjectIdCell);
						cellMap.put("Data Category",categoryCell);
						cellMap.put("Data Classification",classificationCell);

						int index = 1;
						for (String key : cellMap.keySet()) {
							if(assetIdCell!=null || processingActivityIdCell!=null) {
								String nodeAttrData[]= new String[3];
								if(indexOfAssetIdCol > -1 && assetIdCell!=null)
									nodeAttrData[0] = assetIdCell.getStringCellValue().trim()+"-"+threeDigitformatter.format(uniqueSuffix);
								else if(indexOfProcessingActivityIDCol > -1 && processingActivityIdCell!=null)
									nodeAttrData[0] = processingActivityIdCell.getStringCellValue().trim()+"-"+threeDigitformatter.format(uniqueSuffix);
								nodeAttrData[1] = key;
								nodeAttrData[2] = cellMap.get(key) == null ? "" : cellMap.get(key).getStringCellValue().trim();
								nodeAttributeMap.put(nodeAttrData[0]+index, nodeAttrData);
								index++;
							}	
						}
						uniqueSuffix++;
					}	
				}
			}
		}
		
		
	}

	/**
	 * Sorts (A-Z) rows by String column
	 * @param sheet - sheet to sort
	 * @param column - String column to sort by
	 * @param rowStart - sorting from this row down
	 */
	@SuppressWarnings("unused")
	private static void sortSheet(Sheet sheet, int column, int rowStart) {
		boolean sorting = true;
		int lastRow = sheet.getLastRowNum();
		while (sorting == true) {
			sorting = false;
			for (Row row : sheet) {
				// skip if this row is before first to sort
				if (row.getRowNum()<rowStart) continue;
				// end if this is last row
				if (lastRow==row.getRowNum()) break;
				Row row2 = sheet.getRow(row.getRowNum()+1);
				if (row2 == null) continue;
				String firstValue = (row.getCell(column) != null) ? row.getCell(column).getStringCellValue() : "";
				String secondValue = (row2.getCell(column) != null) ? row2.getCell(column).getStringCellValue() : "";
				System.out.println(firstValue +"  "+ secondValue);
				//compare cell from current row and next row - and switch if secondValue should be before first
				System.out.println(secondValue.compareToIgnoreCase(firstValue));
				if (secondValue.compareToIgnoreCase(firstValue)<0) {                    
					sheet.shiftRows(row2.getRowNum(), row2.getRowNum(), -1);
					sheet.shiftRows(row.getRowNum(), row.getRowNum(), 1);
					sorting = true;
				}
			}
		}
	}

	public static void prepareEdgeData(Sheet paToAssetSheet, Map<String, String[]> edgeMap) {
		int indexOfAssetIdCol=-1, indexOfRelationshipCol=-1, indexOfProcessingActivityIdCol=-1, indexOfOrgCol=-1;
		int uniqueId = 1;
		DecimalFormat formatter = new DecimalFormat("00");
		Iterator<Row> rowIterator = paToAssetSheet.rowIterator();
		while (rowIterator.hasNext()) {
			Row currentRow = rowIterator.next();
			//Header Row at Index 0
			if(currentRow.getRowNum() == 0) {
				Iterator<Cell> cellIterator = currentRow.iterator();
				//Iterating over columns to get index of particular column, using column name.
				while (cellIterator.hasNext()) {
					Cell currentCell = cellIterator.next();
					if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Asset ID")) {
						indexOfAssetIdCol = currentCell.getColumnIndex();
					}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Relationship Type")) {
						indexOfRelationshipCol = currentCell.getColumnIndex();
					}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Processing Activity ID")) {
						indexOfProcessingActivityIdCol = currentCell.getColumnIndex();
					}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Processing Activity Organization")) {
						indexOfOrgCol = currentCell.getColumnIndex();
					}
				}
				System.out.println(indexOfAssetIdCol +" "+ indexOfRelationshipCol+" "+indexOfProcessingActivityIdCol);
			}else {

				Cell assetIdCell = indexOfAssetIdCol > -1 ? currentRow.getCell(indexOfAssetIdCol):null;
				Cell relationshipCell = indexOfRelationshipCol > -1 ? currentRow.getCell(indexOfRelationshipCol):null;
				Cell processingActivityIdCell = indexOfProcessingActivityIdCol > -1 ? currentRow.getCell(indexOfProcessingActivityIdCol):null;
				Cell orgCell = indexOfOrgCol > -1 ? currentRow.getCell(indexOfOrgCol):null;
				
				String edgeData[]= new String[5];
				if(assetIdCell!=null && relationshipCell!=null && processingActivityIdCell!=null && orgCell!=null && processOrgAndResourceMap.get(orgCell.getStringCellValue())!=null) {
					if(relationshipCell.getStringCellValue().trim().equalsIgnoreCase("Source/Collection")) {
						edgeData[0] = processingActivityIdCell.getStringCellValue().trim()+"-eo"+formatter.format(uniqueId);
						edgeData[1] = assetIdCell.getStringCellValue().trim();
						edgeData[2] = processingActivityIdCell.getStringCellValue().trim();
						edgeData[3] = "DIRECT";
					}else if(relationshipCell.getStringCellValue().trim().equalsIgnoreCase("Storage/Processing")) {
						edgeData[0] = processingActivityIdCell.getStringCellValue().trim()+"-ep"+formatter.format(uniqueId);
						edgeData[1] = processingActivityIdCell.getStringCellValue().trim();
						edgeData[2] = assetIdCell.getStringCellValue().trim();
						edgeData[3] = "FILTER";
					}else if(relationshipCell.getStringCellValue().trim().equalsIgnoreCase("Destination/Access")) {
						edgeData[0] = processingActivityIdCell.getStringCellValue().trim()+"-et"+formatter.format(uniqueId);
						edgeData[1] = processingActivityIdCell.getStringCellValue().trim();
						edgeData[2] = assetIdCell.getStringCellValue().trim();
						edgeData[3] = "DIRECT";
					}
					edgeData[4] = processOrgAndResourceMap.get(orgCell.getStringCellValue().trim());
					edgeMap.put(edgeData[0], edgeData);
					uniqueId++;
				}
			}
		}
		
	}

	public static void prepareEdgeAttributeData(Sheet paToAssetSheet, Map<String, String[]> edgeAttributeMap) {
		int indexOfRelationshipCol=-1, indexOfProcessingActivityIdCol=-1, indexOfOrgCol=-1;
		int uniqueId = 1;
		DecimalFormat formatter = new DecimalFormat("00");
		Iterator<Row> rowIterator = paToAssetSheet.rowIterator();
		while (rowIterator.hasNext()) {
			Row currentRow = rowIterator.next();
			//Header Row at Index 0
			if(currentRow.getRowNum() == 0) {
				Iterator<Cell> cellIterator = currentRow.iterator();
				//Iterating over columns to get index of particular column, using column name.
				while (cellIterator.hasNext()) {
					Cell currentCell = cellIterator.next();
					if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Relationship Type")) {
						indexOfRelationshipCol = currentCell.getColumnIndex();
					}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Processing Activity ID")) {
						indexOfProcessingActivityIdCol = currentCell.getColumnIndex();
					}else if(currentCell.getStringCellValue()!=null && currentCell.getStringCellValue().trim().equalsIgnoreCase("Processing Activity Organization")) {
						indexOfOrgCol = currentCell.getColumnIndex();
					}
				}
				System.out.println(indexOfRelationshipCol+" "+indexOfProcessingActivityIdCol);
			}else {

				Cell relationshipCell = indexOfRelationshipCol > -1 ? currentRow.getCell(indexOfRelationshipCol):null;
				Cell processingActivityIdCell = indexOfProcessingActivityIdCol > -1 ? currentRow.getCell(indexOfProcessingActivityIdCol):null;
				Cell orgCell = indexOfOrgCol > -1 ? currentRow.getCell(indexOfOrgCol):null;
				
				String edgeData[]= new String[3];
				if(relationshipCell!=null && processingActivityIdCell!=null && orgCell!=null && processOrgAndResourceMap.get(orgCell.getStringCellValue())!=null) {
					if(relationshipCell.getStringCellValue().trim().equalsIgnoreCase("Source/Collection")) {
						edgeData[0] = processingActivityIdCell.getStringCellValue().trim()+"-eo"+formatter.format(uniqueId);
					}else if(relationshipCell.getStringCellValue().trim().equalsIgnoreCase("Storage/Processing")) {
						edgeData[0] = processingActivityIdCell.getStringCellValue().trim()+"-ep"+formatter.format(uniqueId);
					}else if(relationshipCell.getStringCellValue().trim().equalsIgnoreCase("Destination/Access")) {
						edgeData[0] = processingActivityIdCell.getStringCellValue().trim()+"-et"+formatter.format(uniqueId);
					}
					edgeData[1] = "type";
					edgeData[2] = relationshipCell.getStringCellValue().trim();
					edgeAttributeMap.put(edgeData[0], edgeData);
					uniqueId++;
				}
			}
		}
		
	}


}
