package com.prolifics.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.prolifics.constants.MantaConstants;

import au.com.bytecode.opencsv.CSVWriter;

public class SterlingUtil extends MantaConstants {

	private static int elementDepth =1;
	//Key:Parent "name"+elementDepth value: UniqueNodeId
	private static Map<String,String> nodeParentIdMap = new LinkedHashMap<String, String>();
	//Key: parentNodeId - holds for nodeAttribute count logic Value: Doesn't matter keeping all values NULL
	private static Map<String,String[]> tempNodeMap = new HashMap<String, String[]>();
	/**
	 * @param validXmlList
	 * @param xmlLocations
	 * @param xmlLocation
	 * @throws IOException
	 */
	public static void prepareXmlList(List<String> validXmlList, List<String> xmlLocations, String xmlLocation)
			throws IOException {
		if(xmlLocation!=null && !xmlLocation.isEmpty()){
			HttpUtil.sendGetRequest(xmlLocation);
			String xmlString = HttpUtil.readMultipleLinesResponeAsString();
			if(xmlString.trim() != null){
				boolean isValidXML = BasicUtil.hasValidStructure(xmlString, XML);
				if(isValidXML){
					validXmlList.add(xmlString);
					xmlLocations.add(xmlLocation);
				}
			}
		}
	}

	public static void prepareLayersData(String layerTypes, Map<String, String[]> layersMap, List<String> validXmlList) {
		int layerUniqueId = 1;
		DecimalFormat formatter = new DecimalFormat("00");
		String[] layers = null;

		if(layerTypes.contains(COMMA)) {
			layers = layerTypes.split(COMMA);
		}else {
			layers = new String[1];
			layers[0] = layerTypes;
		}
		for(int i=0 ; i < validXmlList.size(); i++){
			for (String layer : layers) {	
				String layerData[]= new String[3];
				layerData[0] = "StB2B"+"layer"+formatter.format(layerUniqueId);
				layerData[1] = layer;
				layerData[2] = layer;
				layersMap.put(layerData[0], layerData);
				layerUniqueId++;
			}
		}

	}

	public static void prepareResourceData(List<String> validXmlList, Map<String, String[]> resourcesMap, Map<String, String[]> layersMap, List<String> xmlLocations) {
		int resourceUniqueId = 1;
		DecimalFormat formatter = new DecimalFormat("00");

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			for (int i =0 ; i < validXmlList.size(); i++){
				Document document = builder.parse(new InputSource(new StringReader(validXmlList.get(i))));
				NodeList processNodeList = document.getElementsByTagName("process");
				Element processElement = (Element) processNodeList.item(0);
				String resourceFileName = URLDecoder.decode(
						xmlLocations.get(i).substring(xmlLocations.get(i).lastIndexOf("/")+1, xmlLocations.get(i).length()), "UTF-8");
				String layer = layersMap.get("StB2Blayer01")[0];
				String processAttribute = processElement.getAttribute("name");
				String resourceData[]= new String[5];
				resourceData[0] = "B2B"+"resrc"+formatter.format(resourceUniqueId);
				resourceData[1] = "B2B-"+processAttribute;
				resourceData[2] = "Sterling B2B Business Process";
				resourceData[3] = resourceFileName  + " - " + processAttribute;
				resourceData[4] = layer;
				resourcesMap.put(processAttribute, resourceData);
				resourceUniqueId++;
			}

		}catch (ParserConfigurationException e) {
			e.printStackTrace();
		}	
		catch (SAXException e) {
			e.printStackTrace();
		}	
		catch (IOException e) {
			e.printStackTrace();
		}	

	}

	public static void prepareNodeData(List<String> validXmlList, Map<String, String[]> nodeMap, Map<String, String[]> resourcesMap){
			int nodeUniqueId = 1;
			DecimalFormat formatter = new DecimalFormat("00");
			DecimalFormat threeDigitFormatter = new DecimalFormat("000");
			try {
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		        DocumentBuilder builder = factory.newDocumentBuilder();
		        for (String xmlString : validXmlList) {
		        	Document document = builder.parse(new InputSource(new StringReader(xmlString)));
			        NodeList processNodeList = document.getElementsByTagName("process");
			        Element processElement = (Element) processNodeList.item(0);
			        String processAttrName = processElement.getAttribute("name");
			        String parentResource = resourcesMap.get(processAttrName)[0];
			        
			        //Top parent row
			        String nodeData[]= new String[5];
			        nodeData[0] = "B2B"+"process"+formatter.format(nodeUniqueId);
			        nodeData[1] = "";
			        nodeData[2] = processAttrName;
			        nodeData[3] = "Directory";
			        nodeData[4] = parentResource;
			        nodeMap.put(nodeData[0], nodeData);
			        String parentNode = nodeData[0];
			        System.out.println(Arrays.toString(nodeData));
			        nodeUniqueId++;

		        	int topCount = 1;
		        	NodeList childNodes = processElement.getChildNodes();
		        	for (int i = 0; i < childNodes.getLength(); i++) {
		        		if(childNodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
		        			Element childElement = (Element) childNodes.item(i);
		        			//Level 1 sequence Row
		        			if(childElement.getNodeName().equalsIgnoreCase("sequence")) {
			        			String childNodeData[]= new String[5];
			        			childNodeData[0] = "B2B"+"-n"+threeDigitFormatter.format(topCount);
			        			childNodeData[1] = parentNode;
			        			childNodeData[2] = childElement.getAttribute("name");
			        			childNodeData[3] = childElement.getTagName();
			        			childNodeData[4] = parentResource;
						        String parentNodeId = childNodeData[0];
						        nodeMap.put(childNodeData[0], childNodeData);
						        
						        int count = 1;
						        NodeList subChildNodes = childElement.getChildNodes();
						        for (int j = 0; j < subChildNodes.getLength(); j++) {
						        	if(subChildNodes.item(j).getNodeType() == Node.ELEMENT_NODE) {
						        		Element subChildElement = (Element) subChildNodes.item(j);
						        		if(subChildElement.getNodeName().equalsIgnoreCase("sequence") || subChildElement.getNodeName().equalsIgnoreCase("choice")) {
						        			traverseSequenceOrChoiceNode(subChildElement,parentNodeId,parentResource,nodeMap,count);
						        			count++;
						        		}else if(subChildElement.getNodeName().equalsIgnoreCase("operation")) {
						        			writeOperationNodetoCSV(subChildElement,parentNodeId,parentResource,nodeMap,count);
						        			count++;
						        		}
						        	}
						        }
						        topCount++;
			        		}else if(childElement.getNodeName().equalsIgnoreCase("operation")) {
			        			//Level 1 operation Row
			        			System.out.println("Never executed");
			        			writeOperationNodetoCSV(childElement,parentNode,parentResource,nodeMap,topCount);
			        			topCount++;
			        		}
		        		}
		        	}
				}
			}catch (ParserConfigurationException e) {
					e.printStackTrace();
			}	
			catch (SAXException e) {
				e.printStackTrace();
			}	
			catch (IOException e) {
				e.printStackTrace();
			}finally {
				elementDepth = 1;
			}		

	}
	
	protected static void traverseSequenceOrChoiceNode(Element element, String parentNodeId, String parentResource, Map<String, String[]> nodeMap, int count){
		elementDepth = 1;
		elementDepth = getElementDepth(element);
		DecimalFormat threeDigitFormatter = new DecimalFormat("000");
		String nodeData[]= new String[5];
		String keyPrefix = "B2B-"+elementDepth;
        nodeData[0] = keyPrefix+threeDigitFormatter.format(count);
        nodeData[1] = parentNodeId;
        nodeData[2] = element.getAttribute("name");
        nodeData[3] = element.getTagName();
        nodeData[4] = parentResource;
        if(nodeMap.containsKey(nodeData[0])) {
        	count++;
        	String newKey = checkKeyAlreadyExist(nodeMap,keyPrefix,count);
        	nodeData[0] = newKey;
        }
        nodeMap.put(nodeData[0], nodeData);
    	String number = nodeData[0].substring(nodeData[0].indexOf("-")+1, nodeData[0].length());
    	nodeParentIdMap.put(element.getAttribute("name").replaceAll("[0-9]", "")+number, nodeData[0]);
        parentNodeId = nodeData[0];
        
        int subCount = 1;
        NodeList subChildNodes = element.getChildNodes();
        for (int j = 0; j < subChildNodes.getLength(); j++) {
        	if(subChildNodes.item(j).getNodeType() == Node.ELEMENT_NODE) {
        		Element subChildElement = (Element) subChildNodes.item(j);
        		if(subChildElement.getNodeName().equalsIgnoreCase("sequence") || subChildElement.getNodeName().equalsIgnoreCase("choice")) {
        			traverseSequenceOrChoiceNode(subChildElement,parentNodeId,parentResource,nodeMap,subCount);
        			subCount++;
        		}else if(subChildElement.getNodeName().equalsIgnoreCase("operation")) {
        			writeOperationNodetoCSV(subChildElement,parentNodeId,parentResource,nodeMap,subCount);
        			subCount++;
				}
        	}
        }
	}
	
	protected static void writeOperationNodetoCSV(Element element, String parentNodeId, String parentResource,Map<String,String[]> nodeMap, int count){
		elementDepth = 1;
		elementDepth = getElementDepth(element);
		DecimalFormat threeDigitFormatter = new DecimalFormat("000");
		String nodeData[]= new String[5];
		String keyPrefix = "B2B-"+elementDepth;
        nodeData[0] = keyPrefix+threeDigitFormatter.format(count);
        nodeData[1] = parentNodeId;
        nodeData[2] = element.getAttribute("name");
        nodeData[3] = element.getTagName();
        nodeData[4] = parentResource;
        if(nodeMap.containsKey(nodeData[0])) {
        	count++;
        	String newKey = checkKeyAlreadyExist(nodeMap,keyPrefix,count);
        	nodeData[0] = newKey;
        }
        String number = nodeData[0].substring(nodeData[0].indexOf("-")+1, nodeData[0].length());
    	nodeParentIdMap.put(element.getAttribute("name").replaceAll("[0-9]", "")+number, nodeData[0]);
        nodeMap.put(nodeData[0], nodeData);
	}
	
	private static String checkKeyAlreadyExist(Map<String, String[]> nodeMap, String keyPrefix, int count) {
		DecimalFormat threeDigitFormatter = new DecimalFormat("000");
		String key = keyPrefix+threeDigitFormatter.format(count);
		if(nodeMap.containsKey(key)) {
			count++;
			key = checkKeyAlreadyExist(nodeMap,keyPrefix,count);
		}
		return key;
	}

	private static int getElementDepth(Node element) {
		Node node = element.getParentNode();
		if(node!=null) {
			elementDepth++;
			getElementDepth(node);
		}else {
			elementDepth = elementDepth-3;
		}
		return elementDepth;
	}
	
	public static void writeDataToCsv(Map<String, String[]> layersMap,String filelocation) throws IOException {
		FileWriter writer = new FileWriter(filelocation);
		CSVWriter csvWriter = new CSVWriter(writer);
		for (String[] data : layersMap.values()) {
			csvWriter.writeNext(data);
		}
		csvWriter.close();
	}

	public static void prepareNodeAttributeData(List<String> validXmlList, Map<String, String[]> nodeAttributeMap,
			Map<String, String[]> nodeMap) {
		
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
	        for (String xmlString : validXmlList) {
	        	Document document = builder.parse(new InputSource(new StringReader(xmlString)));
		        NodeList processNodeList = document.getElementsByTagName("process");
		        Element processElement = (Element) processNodeList.item(0);
		        
		        int count = 1;
	        	NodeList childNodes = processElement.getChildNodes();
	        	for (int i = 0; i < childNodes.getLength(); i++) {
	        		if(childNodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
	        			Element childElement = (Element) childNodes.item(i);
	        			if(childElement.getNodeName().equalsIgnoreCase("sequence") || childElement.getNodeName().equalsIgnoreCase("choice")) {
	            			traverseSelectNode(childElement,nodeAttributeMap,count);
	            			count++;
	            		}else if(childElement.getNodeName().equalsIgnoreCase("operation")) {
	            			writeParticipantNode(childElement,nodeAttributeMap,count);
	            			count++;
	    				}
	        		}
	        	}
			}
		}catch (ParserConfigurationException e) {
				e.printStackTrace();
		}	
		catch (SAXException e) {
			e.printStackTrace();
		}	
		catch (IOException e) {
			e.printStackTrace();
		}finally {
			elementDepth = 1;
			tempNodeMap.clear();
			nodeParentIdMap.clear();
		}
	}

	private static void writeParticipantNode(Element element, Map<String,String[]> nodeAttrMap, int count) {
		DecimalFormat threeDigitFormatter = new DecimalFormat("000");
		if(element.getNodeName().equalsIgnoreCase("operation")) {
			NodeList participantsList = element.getElementsByTagName("participant");
			for(int i=0; i<participantsList.getLength(); i++) {
				if(participantsList.item(i).getNodeType() == Node.ELEMENT_NODE) {
					Element participant = (Element) participantsList.item(i);
					String nodeAttrData[]= new String[3];
					
					//ParentNodeId check
					Node parentNode = participant.getParentNode();
					if(parentNode.getNodeType() == Node.ELEMENT_NODE) {
						Element parentElement = (Element) parentNode;
						elementDepth = 1;
						int level = getElementDepth(parentElement);
						String parentAttr = parentElement.getAttribute("name").replaceAll("[0-9]", "");
						if(parentElement.getTagName().equalsIgnoreCase("operation")) {
							String key = parentAttr+level+threeDigitFormatter.format(count);
							Set<String> keySet = new HashSet<String>();
							tempNodeMap.keySet().forEach((uniqueElem) -> {keySet.add(uniqueElem.replaceAll("[A-Za-z\\s]+", ""));});
							if(keySet.contains(level+threeDigitFormatter.format(count))) {
								count++;
								String number = checkIfNumberExist(keySet,level,count);
								key = parentAttr+number;
							}
							//System.out.println("KEY: "+ key+" OPERATION_PARENT_ATTR: "+ parentAttr);
							tempNodeMap.put(key,null);
							nodeAttrData[0] = nodeParentIdMap.get(key);
						}
					}
						
					nodeAttrData[1] = participant.getTagName();
					nodeAttrData[2] = participant.getAttribute("name");
					String newKey = nodeAttrData[0]+i+new Date().getTime();
					if(nodeAttrMap.containsKey(nodeAttrData[0])) {
			        	newKey = nodeAttrData[0]+i+new Date().getTime();
			        }
					nodeAttrMap.put(newKey, nodeAttrData);
				}
			}
		}
	}

	private static void traverseSelectNode(Element element, Map<String,String[]> nodeAttrMap, int count) {
		DecimalFormat threeDigitFormatter = new DecimalFormat("000");
		if(element.getNodeName().equalsIgnoreCase("choice")) {
			NodeList selectNodesList = element.getChildNodes();
			for(int i=0; i<selectNodesList.getLength(); i++) {
				if(selectNodesList.item(i).getNodeType() == Node.ELEMENT_NODE && selectNodesList.item(i).getNodeName().equalsIgnoreCase("select")) {
					Element selectNode = (Element) selectNodesList.item(i);
					NodeList caseList = selectNode.getChildNodes();
					int caseCount = 1;
					String previousParentId ="";
					for(int j=0;j<caseList.getLength();j++) {
						if(caseList.item(j).getNodeType() == Node.ELEMENT_NODE && caseList.item(j).getNodeName().equalsIgnoreCase("case")) { 
							Element caseItem = (Element) caseList.item(j);
							String nodeAttrData[]= new String[3];
							
							//ParentNodeId check
							Node parentNode = selectNode.getParentNode();
							if(parentNode.getNodeType() == Node.ELEMENT_NODE) {
								Element parentElement = (Element) parentNode;
								elementDepth = 1;
								int level = getElementDepth(parentElement);
								String parentAttr = parentElement.getAttribute("name").replaceAll("[0-9]", "");
								if(parentElement.getTagName().equalsIgnoreCase("choice")) {
									String key = parentAttr+level+threeDigitFormatter.format(count);
									Set<String> keySet = new HashSet<String>();
									tempNodeMap.keySet().forEach((uniqueElem) -> {keySet.add(uniqueElem.replaceAll("[A-Za-z\\s]+", ""));});
									
									if(keySet.contains(level+threeDigitFormatter.format(count)) && caseCount==1) {
										count++;
										String number = checkIfNumberExist(keySet,level,count);
										key = parentAttr+number;
									}
									tempNodeMap.put(key,null);
									//System.out.println("KEY: "+ key+" SELECT_PARENT_ATTR: "+ parentAttr);
									if(caseCount==1) {
										previousParentId = nodeParentIdMap.get(key);
									}
									nodeAttrData[0] = previousParentId;
								}
							}
							
							nodeAttrData[1] = "select "+caseItem.getTagName()+"-"+caseCount;
							NamedNodeMap allAttributes = caseItem.getAttributes();
							String attributes = "";
							for (int k = 0; k < allAttributes.getLength(); k++)
							{
							    Node attr = allAttributes.item(k);
							    attributes = attributes+attr.getNodeName() + "=" + attr.getNodeValue()+" ";
							}
							nodeAttrData[2] = attributes;
							nodeAttrMap.put(nodeAttrData[0]+j+new Date().getTime(), nodeAttrData);
							caseCount++;
						}
					}
					
				}
			}
		}else if(element.getNodeName().equalsIgnoreCase("sequence")){
			elementDepth = 1;
			int level = getElementDepth(element);
			String elementAttr = element.getAttribute("name").replaceAll("[0-9]", "");
			String key = elementAttr+level+threeDigitFormatter.format(count);
			Set<String> keySet = new HashSet<String>();
			tempNodeMap.keySet().forEach((uniqueElem) -> {keySet.add(uniqueElem.replaceAll("[A-Za-z\\s]+", ""));});
			
			if(keySet.contains(level+threeDigitFormatter.format(count))) {
				count++;
				String number = checkIfNumberExist(keySet,level,count);
				key = elementAttr+number;
			}
			tempNodeMap.put(key,null);
		}
		
		int subCount = 1;
		NodeList childNodes = element.getChildNodes();
    	for (int i = 0; i < childNodes.getLength(); i++) {
    		if(childNodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
    			Element childElement = (Element) childNodes.item(i);
    			if(childElement.getNodeName().equalsIgnoreCase("sequence") || childElement.getNodeName().equalsIgnoreCase("choice")) {
        			traverseSelectNode(childElement,nodeAttrMap,subCount);
        			subCount++;
        		}else if(childElement.getNodeName().equalsIgnoreCase("operation")) {
        			writeParticipantNode(childElement,nodeAttrMap,subCount);
        			subCount++;
				}
    		}
    	}
	}

	private static String checkIfNumberExist(Set<String> keySet, int level, int count) {
		DecimalFormat threeDigitFormatter = new DecimalFormat("000");
		String number=level+threeDigitFormatter.format(count);
		if(keySet.contains(number)) {
			count++;
			number =checkIfNumberExist(keySet,level,count);
		}
		return number;
	}
}
