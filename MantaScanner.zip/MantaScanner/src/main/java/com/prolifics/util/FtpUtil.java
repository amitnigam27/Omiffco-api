package com.prolifics.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.vfs2.FileContent;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;

/**
 * This class encapsulates methods for requesting a server via FTP and
 * provides methods for parsing response from the server.
 *
 */
public class FtpUtil {

	public static InputStream readFileFromFTP(String serverAddress,String userId, String password, String remoteDirectory) {

		boolean connectionStatus = true;
		InputStream inputStream=null;
		FTPClient ftp = new FTPClient();

		try {
			//try to connect
			ftp.connect(serverAddress);
			//login to server
			if(!ftp.login(userId, password))
			{
				ftp.logout();
				connectionStatus = false;
			}
			int reply = ftp.getReplyCode();
			//FTPReply stores a set of constants for FTP reply codes. 
			if (!FTPReply.isPositiveCompletion(reply))
			{
				ftp.disconnect();
				connectionStatus = false;
			}

			if(connectionStatus) {
				//enter passive mode
				ftp.enterLocalPassiveMode();
				//get system name
				System.out.println("Remote system is " + ftp.getSystemType());
				//change current directory
				ftp.changeWorkingDirectory(remoteDirectory.substring(0, remoteDirectory.lastIndexOf("/")));
				System.out.println("Current directory is " + ftp.printWorkingDirectory());
				String fileName = remoteDirectory.substring(remoteDirectory.lastIndexOf("/")+1, remoteDirectory.length());
				System.out.println("FileName: "+fileName);
				inputStream = ftp.retrieveFileStream(fileName);

				ftp.logout();
				ftp.disconnect();
			}
		}catch(IOException e) {
			e.printStackTrace();
		}

		return inputStream;
	}

	@SuppressWarnings("deprecation")
	public static InputStream readFileFromSFTP(String serverAddress,String userId, String password, String remoteDirectory) {
		StandardFileSystemManager manager = new StandardFileSystemManager();
		InputStream in = null;
		try {
			//Initializes the file manager
			manager.init();
			//Setup our SFTP configuration
			FileSystemOptions opts = new FileSystemOptions();
			SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
			SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true);
			SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000);
			
			String sftpUri = "sftp://" + userId + ":" + password +  "@" + serverAddress + remoteDirectory;
			FileObject remoteFile = manager.resolveFile(sftpUri, opts);
			FileContent content = remoteFile.getContent();
			in = content.getInputStream();
			manager.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		return in;
	}

}