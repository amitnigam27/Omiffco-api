var ctx = window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));

$(document).ready(function () {
	$("#errorMsg").hide();
	//$("#surl").attr("disabled", "disabled");
	$(".csvListContainer").hide();
    $(".backBtn").click(function () {
      $(".formContainer").show();
      $(".csvListContainer").hide();
    });
    $("#dhForm").submit(function (event) {
        //stop submit the form, we will post it manually.
        event.preventDefault();
        fire_ajax_submit();
    });
    
    /*var surlMap = {};
    var serviceUrls = $("#serviceUrlMap").val().replace("{", "");
    serviceUrls = serviceUrls.replace("}","");
    var serviceUrlsArray = serviceUrls.split(',');
    serviceUrlsArray.forEach(createUrlMap);*/
  
    
    /*function createUrlMap(item, index) {
    	var temp = item.split('=');
    	if(temp[0].trim() == "sterling"){
    		surlMap["sterling"] = temp[1].trim();
    	}else if(temp[0].trim() == "onetrust"){
    		surlMap["onetrust"] = temp[1].trim();
    	}else if(temp[0].trim() == "mulesoft"){
    		surlMap["mulesoft"] = temp[1].trim();
    	}
	}*/
    
    $("#dhs").change(function(){
    	if($(this).val() == "sterling"){
    		//$("#surl").val(surlMap.sterling);
    		$("#sterlingAdditionalFields").removeClass("hide");
    		$("#onetrustAdditionalFields").addClass("hide");
    		$("#mulesoftAdditionalFields").addClass("hide");
    		
    		$("#sterlingAdditionalFields").find("input").each(function() {
    			  $( this ).removeClass("hide");
    		});
    		$("#onetrustAdditionalFields").find("input").each(function() {
    			  $( this ).addClass("hide");
      		});
    		$("#mulesoftAdditionalFields").find("input").each(function() {
  			  $( this ).addClass("hide");
    		});
    	}else if($(this).val() == "onetrust"){
    		//$("#surl").val(surlMap.onetrust);
    		$("#onetrustAdditionalFields").removeClass("hide");
    		$("#sterlingAdditionalFields").addClass("hide");
    		$("#mulesoftAdditionalFields").addClass("hide");
    		$("#onetrustAdditionalFields").find("input").each(function() {
  			  $( this ).removeClass("hide");
    		});
    		$("#sterlingAdditionalFields").find("input").each(function() {
  			  $( this ).addClass("hide");
    		});
    		$("#mulesoftAdditionalFields").find("input").each(function() {
    			  $( this ).addClass("hide");
      		});
    	}else if($(this).val() == "mulesoft"){
    		//$("#surl").val(surlMap.mulesoft);
    		$("#mulesoftAdditionalFields").removeClass("hide");
    		$("#sterlingAdditionalFields").addClass("hide");
    		$("#onetrustAdditionalFields").addClass("hide");
    		$("#mulesoftAdditionalFields").find("input").each(function() {
    			  $( this ).removeClass("hide");
      		});
    		$("#onetrustAdditionalFields").find("input").each(function() {
    			  $( this ).addClass("hide");
      		});
      		$("#sterlingAdditionalFields").find("input").each(function() {
    			  $( this ).addClass("hide");
      		});
    	}
    	//$("#surl").attr("disabled", "disabled");
    });
	$("#dhs").change();
	
	/*$('input').focusout(function() {                    
        if($(this).val()=='' ) {   
        	$(this).css("border","1px solid red");
        } 
        else { 
        	$(this).css("border","1px solid #d2e1ec");
        } 
    });*/
});

function fire_ajax_submit() {

	var formElement = $("#dhForm :visible");
	//var disabledFields = formElement.find(':input:disabled').removeAttr('disabled');
	var requestData = formElement.serialize();
	//disabledFields.attr('disabled','disabled');
    
    /*var isValid = true;
    $(".formContainer").find("input:not(:hidden)").each(function () {
        if($(this).val().length == 0){
        	console.log("Empty field found...");
        	$(this).css("border","1px solid red");
        	$(this).focus();
        	isValid = false;
        	return false;
    	}
    });*/
    
    //if(isValid){
    	$(".loader").toggleClass("hide");
        $(".formContainer").hide();
        $(".csvListContainer").show();
        
        console.log(requestData);

        $("#submit-btn").prop("disabled", true);
        var delay = 1000; //1*1000ms = 1sec
        $.ajax({
            type: "POST",
            contentType: "application/json",
            url: ctx+"/process",
            data: requestData,
            cache: false,
            timeout: 600000,
            success: function (data) {
            	setTimeout(function() {
                console.log("SUCCESS : ", data);
                $("#subTitle").html(data.selectedDHSSystem[0].toUpperCase() + data.selectedDHSSystem.slice(1)+" CSV's");
                $("#csvList").html("");
    			for (var key in data.downloadsMap) {
    				  if (data.downloadsMap.hasOwnProperty(key)) {
    					  var li_element="<li>"
    							+"<i class=\"icon-csv\"></i>"
    			                +"<span class=\"csvName capitalize\">"+key[0].toUpperCase() + key.slice(1)+".csv</span>"
    			                +"<a id=\"downloadBtn\" class=\"downloadBtn\" href=\""+ctx+"/download/"+data.downloadsMap[key]+"\"><i class=\"icon-download\"></i>"
    			                +"</li>";
    			          $("#csvList").append(li_element);
    				  }
    				}
    			$("#downloadAll").attr("href",""+ctx+"/download/"+data.downloadZipLink);
                $("#submit-btn").prop("disabled", false);
                $("#downloadAll").removeClass("hide");
                $(".loader").toggleClass("hide");
            	}, delay);
            },
            error: function (e) {
                console.log("ERROR : ", e);
                $(".loader").toggleClass("hide");
                $(".formContainer").show();
                $(".csvListContainer").hide();
                $("#errorMsg").show();
                $("#errorMsg").html(e.responseJSON.message);
                $("#submit-btn").prop("disabled", false);
            }
        });
    //}
    

}
