package com.prolifics.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MantaScannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
