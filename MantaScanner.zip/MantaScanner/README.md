# MantaCoreScanner
Manta Core Scanner is primarily intended to intended to create a set of Output CSV files. The files are generated via the meta data passed by various Data Handling Systems. Currently we are focusing on following data handling Systems, but the utility is extendible to add/remove any System down the line.

* Sterling B2B Integrator.
* One Trust.
* Mulesoft.

The solution is implemented using Java (JDK 8) and Spring Framework and it do have a primary core Scanner class which do have the necessary contract for the business flow. The Implementation classes represent each Data Handling System and have the neccesary business logic to create the CSV files.

The entire backend is developed as REST API's which are exposed via Spring MVC and we have a SPA application which have the presentation and the response data handling logic.


---

Execution Guidelines
-------------------
* Its a Maven Project, so ensure Maven is configured in your System and code is built successfully.
* MantaScannerApplication.java is the main class where you can change the main method to suite your requirement and run the Program as Java Application.
* Once .war file is build successfully deploy it in tomcat.

> In case of any queries or clarifications, reach out to Rajeev (rajeev.sharma@prolifics.com) or Akshay (akshay.balhara@prolifics.com).
